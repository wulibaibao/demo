var codropsEvents = {
    '06-05-2014': '<span>Submit day</span>',
    '06-23-2014': '<span>Deploy Night</span>',
    '06-31-2014': '<span>Party Night</span>',
    '07-05-2014': '<span>Submit day</span>',
    '07-23-2014': '<span>Deploy Night</span>',
    '07-31-2014': '<span>Party Night</span>',
    '08-05-2014': '<span>Submit day</span>',
    '08-23-2014': '<span>Deploy Night</span>',
    '08-31-2014': '<span>Party Night</span>'
};