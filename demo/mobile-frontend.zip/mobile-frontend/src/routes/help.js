export default function (router) {
    router.map({
        '/help': {
            name: 'help',
            title: '常见问题',
            component: function (resolve) {
                require(['components/Help/Index.vue'], resolve)
            }
        },
        '/help/order': {
            name: 'help_order',
            title: '订单问题',
            component: function (resolve) {
                require(['components/Help/Order.vue'], resolve)
            }
        },
        '/help/shopping': {
            name: 'help_shopping',
            title: '购物问题',
            component: function (resolve) {
                require(['components/Help/Shopping.vue'], resolve)
            }
        },
        '/help/others': {
            name: 'help_others',
            title: '其它问题',
            component: function (resolve) {
                require(['components/Help/Other.vue'], resolve)
            }
        }
    })
}