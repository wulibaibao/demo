export default function (router) {
    router.map({
        '/login': {
            name: 'login',
            component: function (resolve) {
                require(['components/Security/Login.vue'], resolve)
            }
        },
        '/register': {
            name: 'register',
            component: function (resolve) {
                require(['components/Security/Register.vue'], resolve)
            }
        },
        '/find-password/reset-success': {
            component: function (resolve) {
                require(['components/Security/ResetPasswordSuccess.vue'], resolve)
            }
        },
        '/find-password/reset': {
            name: 'password_reset',
            component: function (resolve) {
                require(['components/Security/ResetPassword.vue'], resolve)
            }
        },
        '/find-password': {
            name: 'find_password',
            component: function (resolve) {
                require(['components/Security/FindPassword.vue'], resolve)
            }
        }
    })
}