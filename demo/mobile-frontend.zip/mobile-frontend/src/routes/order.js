export default function (router) {
    router.map({
        '/order/address': {
            name: 'order-address',
            title: '选择收货地址',
            auth: true,
            component: function (resolve) {
                require(['components/Order/Address.vue'], resolve)
            }
        },
        '/order': {
            name: 'confirm-order',
            title: '确认订单',
            auth: true,
            component: function (resolve) {
                require(['components/Order/ConfirmOrder.vue'], resolve)
            }
        },
        '/order/pay/freight/:id': {
            name: 'pay-freight',
            title: '补缴运费',
            auth: true,
            component: function (resolve) {
                require(['components/Order/PayFreight.vue'], resolve)
            }
        },
        '/order/pay/tax/:id': {
            name: 'pay-tax',
            title: '补缴税费',
            auth: true,
            component: function (resolve) {
                require(['components/Order/PayTax.vue'], resolve)
            }
        },'/order/pay/price_diff/:id': {
            name: 'pay-price-diff',
            title: '补差价',
            auth: true,
            component: function (resolve) {
                require(['components/Order/PayPriceDiff.vue'], resolve)
            }
        }
    })
}