export default function (router) {
    router.map({
        '/account': {
            name: 'account',
            title: '个人中心',
            auth: true,
            component: function (resolve) {
                require(['components/Account/Index.vue'], resolve)
            }
        },
        '/settings': {
            name: 'setting',
            title: '个人设置',
            auth: true,
            component: function (resolve) {
                require(['components/Account/Setting.vue'], resolve)
            }
        },
        '/settings/password': {
            name: 'setting_password',
            title: '修改密码',
            auth: true,
            component: function (resolve) {
                require(['components/Account/EditPassword.vue'], resolve)
            }
        },
        '/account/orders': {
            name: 'account_orders',
            title: '我的订单',
            auth: true,
            component: function (resolve) {
                require(['components/Account/OrderList.vue'], resolve)
            }
        },
        '/account/orders/:orderId': {
            name: 'account_order_detail',
            title: '订单详情',
            auth: true,
            component: function (resolve) {
                require(['components/Account/OrderDetail.vue'], resolve)
            }
        },
        '/account/favorites': {
            name: 'account_favorites',
            title: '我的收藏',
            auth: true,
            component: function (resolve) {
                require(['components/Account/Favorites.vue'], resolve)
            }
        },
        '/account/coupons': {
            name: 'account_coupons',
            title: '我的优惠券',
            auth: true,
            component: function (resolve) {
                require(['components/Account/Coupons.vue'], resolve)
            }
        },
        '/account/refund/apply/:orderId': {
            name: 'account_refund_apply',
            title: '申请退款',
            auth: true,
            component: function (resolve) {
                require(['components/Account/ApplyRefund.vue'], resolve)
            }
        },
        '/account/refund': {
            name: 'account_refund',
            title: '退款列表',
            auth: true,
            component: function (resolve) {
                require(['components/Account/Refund.vue'], resolve)
            }
        },
        '/account/invite': {
            name: 'account_invite',
            title: '免代购费，EBUY海淘带你玩转黑色星期五！送你20元运费，还不来领？',
            auth: false,
            component: function (resolve) {
                require(['components/Account/FriendInvite.vue'], resolve)
            }
        },
        '/account/invited': {
            name: 'account_invited',
            title: '邀请有奖',
            auth: false,
            component: function (resolve) {
                require(['components/Account/InvitedFriend.vue'], resolve)
            }
        },
        '/account/bound': {
            name: 'bound_mobile',
            title: '绑定手机号',
            auth: false,
            component: function (resolve) {
                require(['components/Account/BoundMobile.vue'], resolve)
            }
        },
    })
}