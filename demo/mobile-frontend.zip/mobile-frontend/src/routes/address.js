export default function (router) {
    router.map({
        '/account/address': {
            name: 'account_address',
            title: '收货地址',
            auth: true,
            component: function (resolve) {
                require(['components/Address/List.vue'], resolve)
            }
        },
        '/account/address/add': {
            name: 'account_address_add',
            title: '添加新地址',
            auth: true,
            component: function (resolve) {
                require(['components/Address/Add.vue'], resolve)
            }
        },
        '/account/address/:id': {
            name: 'account_address_edit',
            title: '编辑地址',
            auth: true,
            component: function (resolve) {
                require(['components/Address/Edit.vue'], resolve)
            }
        }
    })
}