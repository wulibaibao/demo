export default function (router) {
    router.map({
        // 商品列表
        '/goods': {
            name: 'goods-list',
            component: function (resolve) {     
                require(['components/Goods/GoodsList.vue'], resolve)
            }
        },
        // 分类商品
        '/category/:categoryId/goods': {    
            name: 'category-goods-list',
            title: '商品列表',
            component: function (resolve) {
                require(['components/Goods/GoodsList.vue'], resolve)
            }
        },
        // 值得买(推荐)商品
        '/recommend': {
            name: 'commend-goods-list',
            title: '值得买',
            component: function (resolve) {
                require(['components/Goods/GoodsList.vue'], resolve)
            }
        },
        // 外网集合商品
        '/seller/:sellerId/goods': {    
            name: 'seller-goods-list',
            title: '商品列表',
            component: function (resolve) {
                require(['components/Goods/GoodsList.vue'], resolve)
            }
        },
        // 商品详情
        '/item/:goodsId': {
            name: 'goods-detail',
            title: '商品详情',
            component: function (resolve) {
                require(['components/Goods/Goods.vue'], resolve)
            }
        },
        // 分类页面
        '/category': {
            name: 'category',
            title: '商品分类',
            component: function (resolve) {
                require(['components/Common/Category.vue'], resolve)
            }
        },
        // 外网集合页面
        '/seller': {
            name: 'seller',
            title: '外网集合',
            component: function (resolve) {
                require(['components/Common/Outnet.vue'], resolve)
            }
        },
    })
}