export default function (router) {
    router.map({
        '/': {
            name: 'home',
            title: 'EBUY海淘',
            component: function (resolve) {
                require(['components/Common/Index.vue'], resolve)
            }
        },
        '/search/q/:query': {
            name: 'search_results',
            title: '搜索',
            component: function (resolve) {
                require(['components/Goods/GoodsList.vue'], resolve)
            }
        },
        '/service': {
            name: 'service',
            title: '客户服务',
            component: function (resolve) {
                require(['components/Common/Service.vue'], resolve)
            }
        },
        '/two-years': {
            name: 'two-years',
            title: 'EBUY海淘二周年专题活动',
            auth: true,
            component: function (resolve) {
                require(['components/Common/Twoyears_topic.vue'], resolve)
            }
        },
        '/two-years-draw': {
            name: 'two-years-draw',
            title: 'EBUY海淘二周年庆，海量奖品送送送！',
            component: function (resolve) {
                require(['components/Common/Twoyears_lottery.vue'], resolve)
            }
        },
        '/black-friday': {
            name: 'black_friday',
            title: 'EBUY海淘黑色星期五专题活动',
            auth: false,
            component: function (resolve) {
                require(['components/Common/Black_friday.vue'], resolve)
            }
        },
        '*': {
            name: 'not_found',
            component: function (resolve) {
                require(['components/Common/404.vue'], resolve)
            }
        }
    })
}