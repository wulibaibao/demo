export default function (router) {
    router.map({
        '/cart': {
            name: 'cart',
            title: '购物车',
            auth: true,
            component: function (resolve) {
                require(['components/Cart/Buycar.vue'], resolve)
            }
        }
    })
}