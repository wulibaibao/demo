export default function (router) {
    router.map({
        '/refund-empty': {
            component: function (resolve) {
                require(['components/Common/Refund_empty.vue'], resolve)
            }
        },
        '/floatlayer-noway': {
            component: function (resolve) {
                require(['components/Common/Floatlayer_noway.vue'], resolve)
            }
        },
        '/a': {
            component: function (resolve) {
                require(['components/Common/Twoyears_lottery.vue'], resolve)
            }
        },
        '/floatlayer-cancel-order': {
            component: function (resolve) {
                require(['components/Common/Floatlayer_cancel_order.vue'], resolve)
            }
        },
        '/floatlayer-whether-exit': {
            component: function (resolve) {
                require(['components/Common/Floatlayer_whether_exit.vue'], resolve)
            }
        },
        '/floatlayer-cheap-explain': {
            component: function (resolve) {
                require(['components/Common/FloatLayer_cheap_explain.vue'], resolve)
            }
        },
        '/swiper': {
            component: function (resolve) {
                require(['components/Common/Swiper.vue'], resolve)
            }
        },
        '/judge-order': {
            component: function (resolve) {
                require(['components/Common/Judge_order.vue'], resolve)
            }
        },
        '/user-rule': {
            component: function (resolve) {
                require(['components/Common/Userule.vue'], resolve)
            }
        }
    })
}