<style lang="less">
  @import '../../static/css/base.less';
</style>
<template>
	<div class="wrapper">
	    <router-view></router-view>
	</div>
</template>
<script>
module.exports={
  data:function(){
        return {
            msg:'Hello from vue-loader!!!',
            count2:0
        }
    },
  components: {
  }
}
</script>
