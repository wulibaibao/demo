<style lang="less">
	@import (reference) '../../../static/css/base.less';
	.jud-ord {
		background: @f;
		.pb(50px);
		.con {
			.rel;
			.flex;
			.m(0 9px);
			.p(10px 0 9px);
			border-bottom: 1px solid @e;
			.img {
				.w(74px);
				.h(74px);
				.mr(17px);
				border: 1px solid @e;
				box-sizing: border-box;
				.img;
			}
			.rule {
				flex: 1;
				h3 {
					.h(36px);
					font-size: 14px;
					color: @3;
					overflow: hidden;
				}
				&>p {
					.mt(2px);
					font-size: 12px;
					color: @6;
				}
				.sec {
					.mt(8px);
				}
				&>h4 {
					.abs;
					left: 188px;
					bottom: 3px;
	                color: @6s;
	                span {
	                    font-family: 'PingFangSC-Regular';
	                    font-size: 14px;
	                }
	                .pf {
	                    font-family: 'PingFangSC-Regular';
	                    font-size: 18px;
	                }
	            }
	            &>h6 {
	            	.abs;
	            	bottom: 8px;
	            	right: 2px;
	            	font-size: 12px;
	            	color: @6;  
	            }
			}
		}
		.agree {
			.h(35px);
			line-height: 35px;
			.m(0 9px);
			border-bottom: 1px solid @e;
			.agree-tit {
				float: left;
				.mr(8px);
				font-size: 14px;
				color: @3;
			}
			.agree-cont {
				.db;
				overflow: hidden;
				.pj-star-icon {
					.dbi;
					.w(20px);
					.h(20px);
					background: url(../../../static/images/star.png) center no-repeat;
					background-size: 20px;
					cursor: pointer;
				}
			}
		}
		.judge {
			.m(10px 9px 10px);
			.flex;
			.judge-tit {
				font-size: 14px;
				color: @3;
			}
			.judge-attr {
				flex: 1;
				.db;
				.w(320px);
				.h(100px);
				.p(6px 5px);
				font-size: 12px;
				color: @9;
				border-radius: 2px;
				resize: none;
				overflow: hidden;
				&:focus {
					border-color: @9;
				}
			}
		}
		.thi-img {
			.m(0 0 44px 9px);
			.thi-tit {
				font-size: 14px;
				color: @3;
				.mb(8px);
			}
			.upload-img {
				.rel;
				.dbi;
				.w(115px);
				.h(82px);
				.img;
				input[type="file"] {
					.abs;
					left:0;
					top:0;
					.w(100%);
					.h(100%);
					background:transparent;
					opacity:0;
				}
			}
			.del-img {
				.w(115px);
				.h(20px);
				line-height: 20px;
				font-size: 12px;
				color: @9;
				.tac;
				background:#f1f1f1;

			}
		}
		.pub-jud {
			.m(0 16px);
			.h(35px);
			line-height: 35px
		}
		.jud-exp {
			.m(0 16px);
			font-size: 10px;
			color: @9;
		}
	}
</style>
<template>
	<div class="empty-bg"></div>
	<div class="jud-ord">
		<div class="con"><!--v-for-->
			<div class="img">
				<img :src="">
			</div>
			<div class="rule">
				<h3>1</h3>
				<p>1</p>
				<p class="sec">1</p>
				<h4><span>￥</span><span class="pf">1</span><span>.</span><span>1</span></h4>
                <h6>x2</h6>	
			</div>
		</div>
		<div class="agree">
			<span class="agree-tit">满意度：</span>
			<span class="agree-cont">
				<input type="hidden" id="score_1" value="A1,A2,A3,A4,A5,">
				<span class="pj-star-icon" onclick="selSurvey(1,1)" id="style_1_1"></span>
				<span class="pj-star-icon" onclick="selSurvey(1,2)" id="style_1_2"></span>
				<span class="pj-star-icon" onclick="selSurvey(1,3)" id="style_1_3"></span>
				<span class="pj-star-icon" onclick="selSurvey(1,4)" id="style_1_4"></span>
				<span class="pj-star-icon" onclick="selSurvey(1,5)" id="style_1_5"></span>
			</span>
		</div>
		<div class="judge">
			<span class="judge-tit">评价：</span>
			<textarea v-model="data.write_judge" class="judge-attr" placeholder="商品晒单是您对本次海淘所购商品的质量，使用感受等进行评价！您公平公正的评价可以帮助其他的用户做出正确的选择！（不得少于15字）" rows="5" maxlength="100" onchange="this.value=this.value.substring(0, 100)" onkeydown="this.value=this.value.substring(0, 100)" onkeyup="this.value=this.value.substring(0, 100)"></textarea>
		</div>
		<div class="thi-img">
			<p class="thi-tit">商品图片：</p>
			<a href="javascript:void(0);" class="upload-img">
				<img src="">
				<form class="imgEditForm" method="post" enctype="multipart/form-data" action="">
                    <input accept="image/png,image/jpg" class="lieju-file-upload-btn" v-model="watchUpload3" type="file" class="upload-input" name="file">
                </form>
			</a>
			<p class="del-img">删除</p>
		</div>
		<div class="ebuy-pay-button">
			<a href="javascript:void(0);" class="ebuy-go-pay">发布晒单</a>
		</div>
		<p class="jud-exp">您发布的晒单会由Ebuy客服进行审核，审核通过即发布成功，您将有机会获得优惠券奖励！！</p>
	</div>
	<ebuy-footer></ebuy-footer>
</template>
<script>
	import EbuyFooter from './Footer.vue'
	module.exports = {
		components: {
			EbuyFooter
		},
		data:function() {
			return {
				data: {
					write_judge: '',
				}
			}
		}
	}
</script>