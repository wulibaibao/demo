<style lang="less">
	@import (reference) '../../../static/css/base.less';
	.floatlayer-cheap-explain {
		.fix;
		top: 0;
		right: 0;
		bottom: 0;
		left: 0;
		z-index: 11000;
		background: rgba(0,0,0,.4);
		.flexcenter;
		.ebuy-exit-tip {
			.w(80%);
			background:@f;
			border-radius: 2px;
			text-align: left;
			.explain-content {
				.pd(9px 10px 4px);
			}
			h4 {
				font-family: 'PingFangSC-Regular';
				font-size: 16px;
				font-weight: 700;
			}
			p {
				font-family: 'PingFangSC-Regular';
				font-size: 14px;
				line-height: 28px;
				color: @3;
				text-align: justify;
				span {
					font-size: 14px;
				}
			}
			a {
				.db;
				.h(48px);
				line-height: 48px;
				font-size: 16px;
				color: @6s;
				border-top: 2px solid @e;
				.tac;
			}
		}
	}
</style>
<template>
	<div class="floatlayer-cheap-explain">
		<div class="ebuy-exit-tip">
			<div class="explain-content">
				<h4>说明：</h4>
				<p><span>1.</span>优惠券是Ebuy海淘发行和认可的购物券，可在Ebuy海淘购物结算时使用，可抵扣相应金额；</p>
				<p><span>2.</span>优惠券可以通过参加平台活动、注册时填写邀请码及晒单等途径获得；</p>
				<p><span>3.</span>优惠券不找零、不兑换；</p>
				<p><span>4.</span>部分优惠券有相应的使用限制，例如某券仅限于美亚购物使用；</p>
				<p><span>5.</span>优惠券不可跨账号使用,每个订单仅限于使用一张Ebuy券；</p>
				<p><span>6.</span>优惠券使用最终解释权归Ebuy海淘所有！</p>
			</div>
			<a href="javascript:void(0);" class="noway-exit">关闭</a>
		</div>
	</div>
</template>