<style lang="less">
@import (reference) "../../../static/css/base.less";
@import "../../../node_modules/swiper/dist/css/swiper.min.css";
	.swiper-container {
        width: 100%;
        height: 100%;
        margin-left: auto;
        margin-right: auto;
    }
    .swiper .swiper-slide {
        text-align: center;
        background: #fff;
        display: -webkit-box;
        display: -ms-flexbox;
        display: -webkit-flex;
        display: flex;
        -webkit-box-pack: center;
        -ms-flex-pack: center;
        -webkit-justify-content: center;
        justify-content: center;
        -webkit-box-align: center;
        -ms-flex-align: center;
        -webkit-align-items: center;
        align-items: center;
        &>a {
        	.db;
        	width: 100%;
        	height: auto;
        	.img
        }
    }
    .swiper .swiper-pagination-bullet {
        width: 12px;
        height: 12px;
        opacity: 1;
        border: 2px solid @f;
        background: none
    }
    .swiper .swiper-pagination-bullet-active {
        background: @f;
    }
    .swiper-container-horizontal>.swiper-pagination-bullets .swiper-pagination-bullet {
        margin: 0 4px!important;
    }
</style>
<template>
	<div class="swiper swiper-container">
        <div class="swiper-wrapper">
            <div v-for="item in slide" class="swiper-slide">
                <a href="javascript:void(0)">
                    <img :src="item.url|thumb 500 300">
                </a>
            </div>
        </div>
        <div class="swiper-pagination"></div>
    </div>
</template>
<script>
	import swiper from '../../../node_modules/swiper/dist/js/swiper.min.js'
    module.exports = {
        ready () {
            let mySwiper = new Swiper ('.swiper', {
		        pagination: '.swiper-pagination',
		        slidesPerView: 1,
		        paginationClickable: true,
		        loop: true,
		        autoplay: 2500
          	})
        },
        props: {
            slide:
                [
                    {href:'1',src:'1'},
                    {href:'2',src:'2'}
                ]
        }
    }
</script>