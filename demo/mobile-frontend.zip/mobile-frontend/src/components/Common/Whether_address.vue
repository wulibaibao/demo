<style lang="less">
	@import (reference) '../../../static/css/base.less';
	.floatlayer-cancel-order {
		.fix;
		top: 0;
		right: 0;
		bottom: 0;
		left: 0;
		z-index: 11000;
		background: rgba(0,0,0,.4);
		.flexcenter;
		.con {
			.w(70%);
			background: @f;
			border-radius: 2px;
			.tac
		}
		h3 {
			font-family: 'PingFangSC-Regular';
			.h(90px);
			font-weight: 700;
			line-height: 90px;
			font-size: 16px;
			color: @3;
		}
		.pos {
			.flex;
			border-top: 2px solid @e;
			box-sizing: border-box;
			&>a {
				flex: 1;
				.h(48px);
				line-height: 48px;
				.tac;
				font-size: 14px;
				color: @6s;
				&:first-child{
					border-right:2px solid @e;
					box-sizing: border-box;
				}
			}
		}
	}
</style>
<template>
	<div class="floatlayer-cancel-order">
		<div class="con">
			<h3>是否设置该地址为默认地址？</h3>
			<div class="pos">
				<a href="javascript:void(0);">取消</a>
				<a href="javascript:void(0);">确认</a>
			</div>
		</div>
	</div>
</template>