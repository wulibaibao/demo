<style lang="less">
    @import (reference) "../../../static/css/base.less";
    .ebuy-goto-home {
        .db;
        .fix;
        bottom: 176px;
        right: 12px;
        width: 36px;
        height: 36px;
        background-image: url(../../../static/images/gohome.png);
        background-repeat: no-repeat;
        background-size: contain;
        background-position: center;
        z-index: 530;
    }
</style>
<template>
    <a href="javascript:void(0);" class="ebuy-goto-home" @click="goHome"></a>
</template>
<script>
    module.exports = {
        methods: {
            goHome: function () {
                window.$router.go({name: 'home'})
            }
        }
    }
</script>