<style lang="less">
    @import (reference) "../../../static/css/base.less";

    @main: #e72d2e;
    .ebuy-main-content {
        .abs;
        .w(100%);
        .pb(50px);
        z-index: 520;
    }

    .common-title {
        font-size: 0;
        .m(7px 0 10px 0);
        h2 {
            .dbi;
            font-size: 14px;
            color: @6;
            vertical-align: middle
        }
        span {
            .dbi;
            width: 4px;
            height: 14px;
            .m(0 4px 0 9px);
            background: @6s;
            vertical-align: middle;
            border-radius: 10px;
        }
    }

    .index-nav {
        display: flex;
        .mt(10px);
        background: @f;
        & > a {
            .db;
            flex: 1;
        }
        a:nth-child(1) {
            background: url(../../../static/images/intro.png) 105px 15px no-repeat;
            border-right: 1px solid @e;
            background-size: 72px 44px;
            box-sizing: border-box;
        }
        a:nth-child(2) {
            background: url(../../../static/images/half.png) 120px 9px no-repeat;
            background-size: 50px 63px
        }
        .text-show {
            .pd(12px 0 24px 12px);
        }
        h2 {
            font-size: 14px;
            color: @6s;
            .mb(13px);
        }
        h3 {
            font-size: 12px;
            color: @9;
        }
    }

    .goods-show {
        background: @f;
        .show-con {
            .rel;
            .db;
            padding: 10px 9px 9px;
            border-bottom: 1px solid @e;
        }
        .img-limit, .content-show {
            display: table-cell;
            vertical-align: top;
        }
        .img-limit {
            width: 74px;
            height: 74px;
            border: 1px solid @e;
            box-sizing: border-box;
            .img;
        }
        .content-show {
            .pl(15px);
            h2 {
                font-size: 14px;
                color: @3;
                height: 38px;
                line-height: 18px;
                .lh;
            }
            p {
                .mt(27px);
                font-size: 12px;
                color: @9;
            }
        }
        .price-show {
            .abs;
            right: 9px;
            bottom: 4px;
            text-align: right;
            h4 {
                color: @6s;
                .mb(4px);
                span {
                    font-family: 'PingFangSC-Regular';
                    font-size: 14px;
                }
                .pf {
                    font-family: 'PingFangSC-Regular';
                    font-size: 18px;
                }
            }
            p {
                color: @6;
                font-size: 10px;
            }
        }
    }

    .lot-series {
        .fix;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        background: rgba(0, 0, 0, .6);
        .flexcenter;
        z-index: 10000001;
        .join-ser {
            .rel;
            .w(85.3%);
            max-width: 350px;
            background-color: @main;
            border-radius: 2px;
            text-align: left;
            .ty-logo {
                .w(78%);
                .m(15px auto 10px);
                .pb(10px);
                border-bottom: 1px solid @f;
                .bbox;
                h2 {
                    .w(88px);
                    .h(112px);
                    .m(0 auto);
                    background: url(../../../static/images/ty_logo.png) center no-repeat;
                    background-size: 88px 112px;
                }
            }
            h3 {
                .mb(5px);
            }
            h3, h4 {
                font-size: 12px;
                color: @f;
                .tac;
                font-weight: 700
            }
            .lot-but {
                .m(35px auto 0);
                .pb(30px);
                .tac;
                a {
                    .db;
                    .w(68.8%);
                    .hl(25px);
                    font-size: 12px;
                    font-weight: 700;
                    color: @f;
                    .tac;
                    border: 1px solid @f;
                    border-radius: 3px;
                    .m(0 auto);
                    background-color: @main;
                    .bbox;
                }
            }
            .lot-exit {
                .abs;
                right: 0;
                top: 0;
                .w(20px);
                .h(20px);
                background: url(../../../static/images/lot_exit.png) center no-repeat;
                background-size: 9px;
                background-color: #000;
                border-radius: 2px;
                filter: alpha(opacity=50);
                -moz-opacity: 0.5;
                -khtml-opacity: 0.5;
                opacity: 0.5;
            }
        }
    }

    .floatlayer-black-friday {
        .fix;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        z-index: 10000001;
        background: rgba(0, 0, 0, .8);
        .flexcenter;
        .black-friday-cont {
            .rel;
            .w(86%);
            background: #B31C1D;
            border-radius: 5px;
            .tac;
            h3 {
                .w(88px);
                .h(17px);
                .m(28px auto 25px);
                .tac;
                background: url(../../../static/images/black_logo.png) center no-repeat;
                background-size: 100%;
            }
            h4 {
                .w(233px);
                .m(0 auto);
                .h(61px);
                background: url(../../../static/images/black_text.png) center no-repeat;
                background-size: 100%;
            }
            h5 {
                .w(81px);
                .h(30px);
                .m(19px auto 34px);
                background: url(../../../static/images/black_still.png) center no-repeat;
                background-size: 100%;
            }
            .bla-exit {
                .abs;
                right: 0;
                top: 0;
                .w(20px);
                .h(20px);
                background: url(../../../static/images/black_exit.png) center no-repeat;
                background-size: 10px;
            }
            .bla-init {
                .db;
                .w(230px);
                .m(0 auto 26px);
                .hl(24px);
                border: 1px solid @f;
                .bbox;
                font-size: 12px;
                color: @f;
                .tac;
                border-radius: 3px;
                background-color: transparent;
            }
        }
    }
</style>
<template>
    <!--马上参加弹窗-->
    <div class="lot-series" style="display:none">
        <div class="join-ser">
            <a href="javascript:void(0);" class="lot-exit" v-on:click='closeTwoYears()'></a>
            <div class="ty-logo">
                <h2></h2>
            </div>
            <h3>EBUY海淘2周年庆</h3>
            <h4>海量奖品送送送！</h4>
            <div class="lot-but"><a href="/two-years-draw" v-on:click="closeTwoYears()">马上参加</a></div>
        </div>
    </div>
    <!--黑五活动弹窗-->
    <div class="floatlayer-black-friday" v-show='showTwoYearsWindow'>
        <div class="black-friday-cont">
            <h3 class="black-logo"></h3>
            <h4 class="black-mark"></h4>
            <h5 class="black-still"></h5>
            <a href="javascript:void(0);" class="bla-exit" v-on:click="closeTwoYears()"></a>
            <a class="bla-init" href="javascript:void(0);" v-link="{ name:'black_friday'}" v-on:click="closeTwoYears()">马上参加</a>
        </div>
    </div>
    <ebuy-search></ebuy-search>
    <ebuy-top></ebuy-top>
    <ebuy-chat></ebuy-chat>
    <ebuy-footer></ebuy-footer>
    <div class="ebuy-main-content">
        <ebuy-slide v-if="slide.length>0" :slide="slide"></ebuy-slide>
        <div class="index-nav">
            <a href="javascript:void(0)" v-link="{ name: 'seller' }">
                <div class="text-show">
                    <h2>外网集合</h2>
                    <h3>全球好货任你挑</h3>
                </div>
            </a>
            <a href="javascript:void(0)" v-link="{ name: 'commend-goods-list', params: { commend: 'recommend' }}">
                <div class="text-show">
                    <h2>值得买</h2>
                    <h3>物美价廉就是任性</h3>
                </div>
            </a>
        </div>
        <div class="common-title">
            <span></span>
            <h2>热销商品</h2>
        </div>
        <div class="goods-show content">
            <a href="javascript:void(0);" v-link="{ name: 'goods-detail', params: { goodsId: item.real_id }}"
               class="show-con" v-for="item in goods">
                <div class="img-limit">
                    <img :src="item.img | thumb 74 74">
                </div>
                <div class="content-show">
                    <h2>{{ item.name }}</h2>
                    <p v-if="item.seller">{{ item.seller.server_num }}</p>
                </div>
                <div class="price-show">
                    <h4>{{{item.sell_price | priceFormatter}}}</h4>
                    <p>参考价￥<span>{{ item.market_price }}</span></p>
                </div>
            </a>
        </div>
        <infinite-loading :distance="distance" :on-infinite="onInfinite"></infinite-loading>
    </div>
</template>
<script>
    import Vue from 'vue'
    import EbuySlide from './Swiper.vue'
    import EbuyFooter from './Footer.vue'
    import EbuySearch from './SearchBar.vue'
    import EbuyTop from './GotopBubble.vue'
    import EbuyChat from './ChatBubble.vue'
    import zepto from 'webpack-zepto'
    import Service from '../../utils/service'
    import InfiniteLoading from '../InfiniteLoading.vue'
    import wx from 'weixin-js-sdk'

    module.exports = {
        components: {
            InfiniteLoading,
            EbuySlide,
            EbuyFooter,
            EbuySearch,
            EbuyTop,
            EbuyChat
        },
        data: function () {
            return {
                distance: 200,
                slide: [],//{data.href,data.src}
                goods: [],
                page: 1,
                showTwoYearsWindow: true
            }
        },
        ready: function () {
            this.getSlide();
            this.showTwoYears();
            if (this.isWechat()) {
                this.initWeChatShare();
            }
        },
        methods: {
            isWechat: function () {
                var me = this,
                        wac = window.navigator.userAgent.toLowerCase();
                if (wac.match(/MicroMessenger/i) == 'micromessenger') {
                    return true;
                } else {
                    return false;
                }
            },
            getSlide(){
                var me = this;
                Service.getAdvertisements(null, function (response) {
                    me.slide = response.data.data;
                });
            },
            onInfinite: function () {
                var me = this;
                console.log('loading');
                Service.getHotGoods(me.page, null, function (response) {
                    me.goods = me.goods.concat(response.data.data);

                    if (me.page >= response.data.meta.pagination.total_pages) {
                        me.$broadcast('$InfiniteLoading:noMore');
                    } else if (response.data.data.length == 0) {
                        me.$broadcast('$InfiniteLoading:noResults');
                    }
                    me.$broadcast('$InfiniteLoading:loaded');
                });

                me.page++;
            },
            showTwoYears(){ // 显示二周年活动入口

                var twoYearsStart = Date.parse('2016-11-21 00:00:00');
                var now = Date.now();
                var twoYearsEnd = Date.parse('2016-12-1 00:00:00');

                if ((now >= twoYearsStart) && (now <= twoYearsEnd)) {
                    this.showTwoYearsWindow = (sessionStorage.getItem('showTwoYears') == 'false') ? false : true;
                } else {
                    this.showTwoYearsWindow = false;
                }
            },
            closeTwoYears: function () { // 关闭二周年活动入口
                this.showTwoYearsWindow = false;
                sessionStorage.setItem('showTwoYears', false);
            },
            isLogged() {
                var accessToken = localStorage.getItem('access_token');

                return accessToken ? true : false;
            },
            initWeChatShare: function () {
                var self = this;
                var curUrl = location.href.split('#')[0];

                Service.getWechatJsConfig(encodeURIComponent(curUrl), null, function (res) {

                    var config = res.data.data;

                    wx.config({
                        debug: false,
                        appId: config.appId,
                        timestamp: config.timestamp,
                        nonceStr: config.nonceStr,
                        signature: config.signature,
                        jsApiList: config.jsApiList
                    });

                    wx.ready(function () {

                        wx.onMenuShareTimeline({
                            title: 'Ebuy海淘-免费的海淘代下单服务平台', // 分享标题
                            link: curUrl, // 分享链接
                            imgUrl: 'http://m.laidoulaile.com/static/images/logo.png', // 分享图标
                            success: function () {
                                self.$alert("分享成功 :)");
                            },
                            cancel: function () {
                            }
                        });

                        wx.onMenuShareAppMessage({
                            title: 'Ebuy海淘-免费的海淘代下单服务平台', // 分享标题
                            desc: 'Ebuy海淘提供专业的国外海淘代下单服务，提供国外亚马逊等海淘热销产品价格、评价，一键淘开启一站式自助海淘，体验全球海淘首选Ebuy365', // 分享描述
                            link: curUrl, // 分享链接
                            imgUrl: 'http://m.laidoulaile.com/static/images/logo.png', // 分享图标
                            type: '', // 分享类型,music、video或link，不填默认为link
                            dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
                            success: function () {
                                self.$alert("分享成功 :)");
                            },
                            cancel: function () {
                            }
                        });

                        wx.onMenuShareQQ({
                            title: 'Ebuy海淘-免费的海淘代下单服务平台', // 分享标题
                            desc: 'Ebuy海淘提供专业的国外海淘代下单服务，提供国外亚马逊等海淘热销产品价格、评价，一键淘开启一站式自助海淘，体验全球海淘首选Ebuy365', // 分享描述
                            link: curUrl, // 分享链接
                            imgUrl: 'http://m.laidoulaile.com/static/images/logo.png', // 分享图标
                            success: function () {
                                self.$alert("分享成功 :)");
                            },
                            cancel: function () {
                            }
                        });

                        wx.onMenuShareQZone({
                            title: 'Ebuy海淘-免费的海淘代下单服务平台', // 分享标题
                            desc: 'Ebuy海淘提供专业的国外海淘代下单服务，提供国外亚马逊等海淘热销产品价格、评价，一键淘开启一站式自助海淘，体验全球海淘首选Ebuy365', // 分享描述
                            link: curUrl, // 分享链接
                            imgUrl: 'http://m.laidoulaile.com/static/images/logo.png', // 分享图标
                            success: function () {
                                self.$alert("分享成功 :)");
                            },
                            cancel: function () {
                            }
                        });
                    });
                    wx.error(function (res) {
//                        self.$alert(res.data);
                    });
                });
            },
            hideBound: function () {
                $('.floatlayer-bound-mobile').addClass('none');
            },
            hideBlack: function () {
                $('.floatlayer-black-friday').addClass('none');
            },
            getUserInfo: function () {
                var self = this;
                Service.userInfo(function (response) {

                }, function (response) {
                    self.user = response.data.data;
                    if (!self.user.mobile_bind) {
                        self.showBindWindow = (sessionStorage.getItem('showBindWindow') == 'false') ? false : true;
                    } else {
                        self.showBindWindow = false;
                    }
                });
            }
        }
    }
</script>