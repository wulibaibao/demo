<style lang="less">
    @import (reference) '../../../static/css/base.less';
    @main: #e72d2e;
    .friday-instant-invite {
        .fix;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        background: rgba(0, 0, 0, .6);
        .flexcenter;
        z-index: 10000001;
        .cont {
            .rel;
            .w(85.33%);
            background-color: @f;
            border-radius: 2px;
            h3 {
                .p(36px 0 46px);
                font-size: 15px;
                color: #333;
                font-weight: 700;
                .tac;
            }
            h4 {
                .p(0 5%);
                font-size: 12px;
                font-weight: 600;
                color: #333;
                .tac;
            }
            .but-con {
                .db;
                .w(53.33%);
                .m(18px auto 24px);
                .hl(25px);
                font-size: 12px;
                color: @f;
                font-weight: 700;
                background-color: #B31C1D;
                border-radius: 2px;
                .tac;
            }
            .close {
                .abs;
                .db;
                right: 0;
                top: 0;
                .w(20px);
                .h(20px);
                background: url(../../../static/images/black_exit.png) center no-repeat;
                background-size: 10px;
            }
        }
    }

    .black-friday-holiday {
        background-color: #b31c1d;
        padding-bottom: 36px;
        .top-show {
            .w(100%);
            .h(200px);
            background: url(../../../static/images/black_top_banner.png) center no-repeat;
            background-size: cover;
        }
        .black-friday-rorate {
            .w(330px);
            max-width: 330px;
            .h(330px);
            .m(20px auto 15px);
            border-radius: 50%;
            border: 1px solid transparent;
            .bbox;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.16);
        }
        .friday-rorate-positon {
            .rel;
            .w(330px);
            max-width: 330px;
            .h(330px);
            z-index: 111;
        }
        #outer-cont {
            .abs;
            .w(100%);
            overflow: hidden;
        }
        #outer {
            .w(330px);
            max-width: 330px;
            .h(330px);
            .img;
            overflow: hidden;
            img {
                overflow: hidden;
            }
        }
        #inner-cont {
            .abs;
            .w(100%);
            left: 0;
            top: 24.24%;
        }
        #inner {
            .w(109px);
            max-width: 109px;
            .h(140px);
            .m(0 auto);
            .img;
            cursor: pointer;
        }
        .black-still-chance {
            font-size: 14px;
            font-weight: 600;
            color: @f;
            .tac;
            span {
                .dbi;
                vertical-align: baseline;
                font-size: 16px;
                color: #ffbe04;
            }
        }
        .black-friday-scroll {
            .w(88%);
            max-width: 88%;
            .m(16px auto 10px);
            .h(126px);
            background-color: #9F1718;
            border-radius: 2px;
            overflow: hidden;
            ul {
                .m(10px 25px);
                font-size: 0;
                overflow: hidden;
            }
            li {
                .hl(25px);
                overflow: hidden;
            }
            h2, h3 {
                .dbi;
                font-size: 12px;
                color: @f;
                vertical-align: middle;
                white-space: nowrap;
                text-overflow: ellipsis;
                overflow: hidden;
            }
            h2 {
                .w(27%);
                .mr(5%);
            }
            h3 {
                .w(68%);
            }
        }
        .scroll-cont {
            .mt(20px);
        }
        .black-friday-award {
            .w(88%);
            max-width: 88%;
            .m(16px auto 10px);
            background-color: #9F1718;
            border-radius: 2px;
            overflow: hidden;
        }
        .award-cont {
            .m(10px auto 15px);
            h3 {
                .w(88%);
                .m(0 auto);
                line-height: 22px;
                font-size: 12px;
                color: @f;
                font-weight: 700;
                white-space: nowrap;
                span {
                    .dbi;
                    font-size: 12px;
                    color: @f;
                    font-weight: 500;
                    vertical-align: middle;
                }
            }
            h4 {
                .mt(14px);
                font-size: 13px;
                color: #FFD048;
                .tac;
            }
        }
        .ins-int {
            .db;
            .w(66.7%);
            .m(17px auto 0);
            .hl(25px);
            border-radius: 2px;
            font-size: 12px;
            color: #CC1519;
            background-color: #FFD049;
            .tac;
        }
        .black-how-rorate {
            .w(88%);
            .m(0 auto);
            h3 {
                .mb(8px);
                font-size: 14px;
                font-weight: 600;
                color: @f;
            }
            h4 {
                line-height: 20px;
                font-size: 12px;
                color: @f;
                font-weight: 500;
            }
            .ins-shr {
                .dbi;
                .w(63px);
                .hl(15px);
                vertical-align: middle;
                font-size: 10px;
                color: #FFBE04;
                font-weight: 500;
                .tac;
                background: url(../../../static/images/black_instant_share.png) center no-repeat;
                background-size: cover;
            }
        }
        .black-friday-group {
            .w(88%);
            .m(20px auto);
            h2 {
                font-size: 14px;
                color: @f;
                font-weight: 600;
                .tac;
            }
            .group-code {
                .w(100%);
                .m(10px auto 0);
                & > p {
                    .w(100px);
                    .h(100px);
                    .m(0 auto);
                    overflow: hidden;
                    .img;
                }
            }
        }
        .mid-show {
            .w(100%);
            .h(80px);
            .mb(15px);
            background: url(../../../static/images/black_mid_banner.png) center no-repeat;
            background-size: cover;
        }
        .topic-cont {
            h2 {
                line-height: 18px;
                font-size: 12px;
                color: @f;
                font-weight: 800;
                .tac;
                border-bottom: 1px solid @f;
                .bbox
            }
            h3 {
                font-size: 12px;
                color: @f;
                font-weight: 700;
                .tac;
            }
            .worth-buy-sth {
                .m(8px 0 10px);
                .ebuy-worth-buy {
                    .pb(5px);
                    .special-zone {
                        .h(53px);
                        background: #f1f1f1
                    }
                }

                .worth-buy-img {
                    .w(120px);
                    .h(120px);
                    .img;
                    .m(0 auto);
                }
                .worth-buy-zone {
                    .rel;
                    float: left;
                    .w(50%);
                    background: @f;
                    border-radius: 5px;
                    border: 2px solid @main;
                    box-sizing: border-box;
                }
                .worth-buy-position {
                    .m(9px 9px 10px);
                    p {
                        font-size: 12px;
                        color: @3;
                        border-bottom: 1px solid @d;
                        height: 38px;
                        line-height: 18px;
                        .lh;
                    }
                    h5 {
                        .db;
                        text-align: left;
                        .pb(8px);
                        color: @6s;
                        span {
                            font-family: 'PingFangSC-Regular';
                            font-size: 14px;
                        }
                        .pf {
                            font-family: 'PingFangSC-Regular';
                            font-size: 18px;
                        }
                    }
                }
                .worth-buy-where {
                    .abs;
                    bottom: 4px;
                    font-size: 10px;
                    color: @6
                }
                .worth-buy-block {
                    .mb(5px);
                    clear: both;
                    overflow: hidden;
                }
            }
        }
    }

    .floatlayer-black-pc {
        .fix;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        z-index: 11000;
        background: rgba(0, 0, 0, .5);
        .flexcenter;
        .ebuy-pc-tip {
            .rel;
            .w(80%);
            background: @f;
            border-radius: 2px;
            .tac;
            p {
                font-family: 'PingFangSC-Regular';
                font-size: 16px;
                line-height: 24px;
                .p(59px 30px 52px);
                font-weight: 700;
                color: @3;
            }
            .pc-but {
                .db;
                .w(62%);
                .m(0 auto 30px);
                .h(38px);
                line-height: 38px;
                font-size: 16px;
                color: @f;
                background-color: #D90707;
                font-weight: 800;
                border-radius: 3px;
            }
            .pc-exit {
                .abs;
                right: 0;
                top: 0;
                .w(20px);
                .h(20px);
                background: url(../../../static/images/black_exit.png) center no-repeat;
                background-size: 9px;
            }
        }
    }

    .floatlayer-black-share {
        .fix;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        z-index: 11000;
        background: rgba(0, 0, 0, .9);
        .ebuy-share-tip {
            .rel;
            .w(100%);
            .tac;
            .invite-air {
                .abs;
                top: 85px;
                right: 5%;
                .w(187px);
                .h(118px);
                .m(0 auto);
                background: url(../../../static/images/invite_air.png) center no-repeat;
                background-size: contain;
            }
            h3 {
                .abs;
                top: 225px;
                right: 21%;
                font-size: 20px;
                color: @f;
            }
        }
    }

    @media screen and (max-width: 320px) {
        .black-friday-holiday {
            .black-friday-rorate {
                .w(300px);
                max-width: 300px;
                .h(300px);
                .m(20px auto 15px);
                border-radius: 50%;
                border: 1px solid transparent;
                .bbox;
                box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.16);
            }
            .friday-rorate-positon {
                .rel;
                .w(300px);
                max-width: 300px;
                .h(300px);
                z-index: 111;
            }
            #outer-cont {
                .abs;
                .w(100%);
                overflow: hidden;
            }
            #outer {
                .w(300px);
                max-width: 300px;
                .h(300px);
                .img;
                overflow: hidden;
                img {
                    overflow: hidden;
                }
            }
            #inner-cont {
                .abs;
                .w(100%);
                left: 0;
                top: 24.24%;
            }
            #inner {
                .w(109px);
                max-width: 109px;
                .h(140px);
                .m(0 auto);
                .img;
                cursor: pointer;
            }
            .award-cont {
                h3 {
                    white-space: pre-line;
                }
            }
        }
    }
</style>
<template>
    <ebuy-top></ebuy-top>
    <ebuy-chat></ebuy-chat>
    <ebuy-gohome></ebuy-gohome>
    <!--Floatlayer Common-->
    <div class="friday-instant-invite none invite_div">
        <div class="cont">
            <a href="javascript:void(0);" class="close" @click="hideFloat"></a>
            <h3>您今天的抽奖资格用完！</h3>
            <h4>邀请好友注册，最高可获得50次抽奖机会。</h4>
            <a href="/account/invite" class="but-con">立即邀请</a>
        </div>
    </div>
    <div class="floatlayer-black-pc none">
        <div class="ebuy-pc-tip">
            <p>请使用浏览器自带分享功能或直接复制网址链接发送给好友！</p>
            <a href="javascript:void(0);" class="pc-but" @click="shareTip">确定</a>
            <a href="javascript:void(0);" class="pc-exit" @click="hideTip"></a>
        </div>
    </div>

    <div class="friday-instant-invite  none  share_div ">
        <div class="cont">
            <a href="javascript:void(0);" class="close" @click="hideFloat"></a>
            <h3>您今天的抽奖资格用完！</h3>
            <h4>分享此页面至微信朋友圈，可再获得一次抽奖资格。</h4>
            <a href="javascript:;" class="but-con share_btn">立即分享</a>
        </div>
    </div>
    <div class="floatlayer-black-share none">
        <div class="ebuy-share-tip">
            <p class="invite-air"></p>
            <h3>使用微信直接分享至朋友圈</h3>
        </div>
    </div>
    <div class="black-friday-holiday">
        <h2 class="top-show"></h2>
        <div class="black-friday-rorate">
            <div class="friday-rorate-positon">
                <div id="outer-cont">
                    <div id="outer">
                        <img :src="rorate_bg"/>
                    </div>
                </div>
                <div id="inner-cont">
                    <div id="inner">
                        <img :src="rorate_indicator"/>
                    </div>
                </div>
            </div>
        </div>
        <h3 class="black-still-chance">您有<span id="lotter_chance_num">{{ total_chance_num }}</span>次抽奖机会！</h3>
        <div class="black-friday-scroll">
            <div class="scroll-cont">
                <ul>
                    <li v-for="winner in winnerarr">
                        <h2>用户{{ winner.username }}</h2>
                        <h3>{{ winner.remark }}</h3>
                    </li>
                </ul>
            </div>
        </div>
        <div class="black-friday-award">
            <div class="award-cont">
                <h3>一等奖：黑五免单资格<span>（限黑五期间10000元以内订单）</span></h3>
                <h3>二等奖：免运费券<span>（限黑五期间运费500元以内订单）</span></h3>
                <h3>三等奖：50元运费券</h3>
                <h3>四等奖：20元运费券</h3>
                <h3>五等奖：10元运费券</h3>
                <h4>邀请好友注册，最高可获得50次抽奖机会！</h4>
                <a class="ins-int" href="javascript:void(0);" v-link="{name:'account_invite'}">立刻邀请</a>
            </div>
        </div>
        <div class="black-how-rorate">
            <h3>如何参加抽奖活动：</h3>
            <h4>1.EBUY海淘注册用户均可参加本次活动；</h4>
            <h4>2.活动期间，每天登录EBUY海淘网站即可获得一次抽奖机会；</h4>
            <h4>3.活动期间，分享活动页面到朋友圈可再获得一次抽奖机会；<a href="javascript:void(0);" class="ins-shr" @click="showTip">立即分享</a></h4>
            <h4>4.活动期间，每成功邀请一名好友注册成为EBUY海淘用户，即可再次获得一次抽奖机会。每日邀请上限50名；</h4>
            <h4>5.活动期间，参与分享和邀请用户人数较多的用户将更大几率中大奖；</h4>
            <h4>6.一等奖说明：抽中一等奖的用户可以选择黑五活动期间已付款订单中金额最高的一个订单（不超过 1 万元）进行免单，不能用于中奖之后的订单；</h4>
            <h4>7.优惠券类奖品中奖后将直接发送到您的账户，购物时即可使用且无任何限制，特殊商品除外；</h4>
            <h4>活动时间：2016.11.21-2016.11.30；</h4>
            <h4>本活动最终解释权归EBUY海淘所有。</h4>
        </div>
        <div class="black-friday-group">
            <h2>扫码加入黑五直播群</h2>
            <div class="group-code">
                <p><img :src="black_wechat"></p>
            </div>
        </div>
        <h2 class="mid-show"></h2>
        <div class="topic-cont" v-for="item in activity.list">
            <h2>{{ item.name }}</h2>
            <h3>{{ item.title }}</h3>
            <div class="worth-buy-sth">
                <div class="worth-buy-block">
                    <a href="javascript:void(0);" class="worth-buy-zone"
                       v-link="{ name: 'goods-detail', params: { goodsId: goods.stock_id }}"
                       v-for="goods in item.goods">
                        <div class="worth-buy-position">
                            <div class="worth-buy-img">
                                <img :src="goods.img | thumb">
                            </div>
                            <p>{{ goods.name }}</p>
                            <h4 class="worth-buy-where">商家：{{ goods.seller.server_num }}</h4>
                            <h5>{{{goods.sell_price | priceFormatter}}}</h5>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
	import EbuyGohome from './ReturnhomeBubble.vue'
	import EbuyChat from './ChatBubble.vue'
	import EbuyTop from './GotopBubble.vue'
	import Service from '../../utils/service'
    import wx from 'weixin-js-sdk';
    jQuery(function() {
        window.requestAnimFrame = (function() {
            return window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || window.oRequestAnimationFrame || window.msRequestAnimationFrame || function(callback) {
                window.setTimeout(callback, 1000 / 60)
            }
        })();
        var wac = window.navigator.userAgent.toLowerCase();
        if (wac.match(/MicroMessenger/i) == 'micromessenger') {
           var isWechat=true;
        } else {
            var isWechat=false;
        }


        var totalDeg = 360 * 3 + 0;
        var steps = [];
        var prizeInfo={};
        var now = 0;
        var a = 0.01;
        var outter, inner, timer, running = false;
        function countSteps() {
            var t = Math.sqrt(2 * totalDeg / a);
            var v = a * t;
            for (var i = 0; i < t; i++) {
                steps.push((2 * v * i - a * i * i) / 2)
            }
            steps.push(totalDeg)
        }
        function step() {
            outter.style.webkitTransform = 'rotate(' + steps[now++] + 'deg)';
            outter.style.MozTransform = 'rotate(' + steps[now++] + 'deg)';
            if (now < steps.length) {
                requestAnimFrame(step)
            } else {
                running = false;
                setTimeout(function() {
                //表示中奖了
                    if(prizeInfo){
                            //2: 抽奖成功后提示分享活动到朋友圈可获得一次抽奖机会
//                    1: 抽奖成功后提示邀请好友可获得一次抽奖机会
                        var add_sub_msg='';

                        if ((prizeInfo.next == 1) || (prizeInfo.next == 2)) {

                            if (prizeInfo.next == 1) {
                                var element1 = jQuery(".invite_div .cont h3");
                                var element2 = jQuery(".invite_div .cont h4");
                            } else {
                                 if(isWechat==false){
                                    add_sub_msg='请使用浏览器自带分享功能分享至朋友圈！';
                                    jQuery('.share_div .share_btn').html("确定");
                                 }
                                var element1 = jQuery(".share_div .cont h3");
                                var element2 = jQuery(".share_div .cont h4");
                            }
                            //插入一条记录到中奖滚动的div种
                            jQuery(".scroll-cont ul").prepend("<li><h3>用户"+prizeInfo.username+"</h3><h4>"+prizeInfo.msg+"</h4></li>");
                            jQuery('.scroll-cont ul li:gt(9)').remove();
                            showTipWindow(element1, element2, prizeInfo,add_sub_msg);

                        }

                    }
                }, 200)
            }
        }
        function start(deg) {
            running = true;
            clearInterval(timer);
            totalDeg = 360 * 5 + deg*72;
            steps = [];
            now = 0;
            countSteps();
            requestAnimFrame(step)
        }
        window.start = start;
        outter = document.getElementById('outer');
        inner = document.getElementById('inner');
        var i = 10;
        //抽奖操作
        jQuery("#inner").click(function() {
            if (running) {
                return;
            }
            running = true;
            Service.getlotteryAct(null, function (response) {
                running = false;
                prizeInfo=response.data.data;
                var next=prizeInfo.next
//                    next备注：
//                    2: 抽奖成功后提示分享活动到朋友圈可获得一次抽奖机会
//                    1: 抽奖成功后提示邀请好友可获得一次抽奖机会
//                    -2: 没有可用的抽奖机会,邀请好友可获得抽奖机会
//                    -1: 没有可用的抽奖机会,分享活动到朋友圈可获得一次抽奖机会
                var index = prizeInfo.index;
                console.log(prizeInfo);
                if ((next == 2) || (next == 1)) {
                    var deg = index == 0 ? index : 5 - index;
                    jQuery('#lotter_chance_num').html(parseInt($('#lotter_chance_num').html()) - 1);
                    start(deg);
                } else if (next == -2) {
                    //邀请朋友
                    jQuery('.invite_div').removeClass('none');
                    var element1 = jQuery(".invite_div .cont h3");
                    var element2 = jQuery(".invite_div .cont h4");
                    showTipWindow(element1, element2, prizeInfo);
                    return false;
                } else if (next == -1) {
                    console.log(prizeInfo);
                    //分享朋友圈
                    //需要判断是否在微信打开
                    var add_sub_msg='';
                    if(isWechat==false){
                           add_sub_msg='请使用浏览器自带分享功能分享至朋友圈！';
                           jQuery('.share_div .share_btn').html("确定");
                    }
                    jQuery('.share_div').removeClass('none');
                    var element1 = jQuery(".share_div .cont h3");
                    var element2 = jQuery(".share_div .cont h4");
                    showTipWindow(element1, element2, prizeInfo,add_sub_msg);
                    return false;

                }
                console.log(prizeInfo.next);
            });
        });
        //显示弹窗
        function showTipWindow(element1, element2, data,add_sub_msg="") {
            element1.html(data.msg);
            element2.html(data.msg_sub+add_sub_msg);
            console.log(element1.parent());
            element1.parent().parent().removeClass('none');
        }
        //分享按钮进行点击操作
        jQuery('.share_btn').on('click',function(){
            if(isWechat==true){
                 $('.share_div').addClass('none');
                $('.floatlayer-black-share').removeClass('none');
            }else{
                $('.share_div').addClass('none');
            }
        });

    });

	module.exports = {
		data: function(){
			return {
				rorate_bg: require('static_file/images/black_rorate_bg.png'),
				rorate_indicator: require('static_file/images/black_rorate_indicator.png'),
				black_wechat: require('static_file/images/black_share_wechat.png'),
				activity: {},
				winnerarr:[],
				total_chance_num:0,
				wac:'',
			}
		},
		ready: function() {
			this.onTransform();
			this.getActivity();
			this.getRecentlyTenWinner();
			this.getUserLotterChanceNum();
			this.isWechat();
			if (this.isWechat()) {
                this.initWeChatShare();
            }
		},
		components: {
            EbuyTop,
            EbuyGohome,
            EbuyChat,
        },
        methods: {
             initWeChatShare: function () {

                var self = this;
                var curUrl = location.href.split('#')[0];

                Service.getWechatJsConfig(encodeURIComponent(curUrl), null, function (res) {

                    var config = res.data.data;

                    wx.config({
                        debug: false,
                        appId: config.appId,
                        timestamp: config.timestamp,
                        nonceStr: config.nonceStr,
                        signature: config.signature,
                        jsApiList: config.jsApiList
                    });

                    wx.ready(function () {

                        wx.onMenuShareTimeline({
                            title: 'EBUY海淘发黑五红包啦，海量免单资格等你来抢！100%有奖哦～', // 分享标题
                            desc:'黑五海外购物狂欢节，EBUY海淘为您免单！',
                            link: curUrl, // 分享链接
                            imgUrl: 'http://m.laidoulaile.com/static/images/logo.png', // 分享图标
                            success: function () {
                                // 用户确认分享后执行的回调函数
                                   Service.addchanceByShare(null, function (response) {
                                        var num=self.total_chance_num+1;
                                        self.total_chance_num=num;
                                       self.$alert("分享成功 :)");
                                   });
                            },
                            cancel: function () {
                                // 用户取消分享后执行的回调函数
//                                self.$alert("为啥取消了 :(");
                            }
                        });

                        wx.onMenuShareAppMessage({
                            title: 'EBUY海淘发黑五红包啦，海量免单资格等你来抢！100%有奖哦～', // 分享标题
                            desc: '黑五海外购物狂欢节，EBUY海淘为您免单！', // 分享描述
                            link: curUrl, // 分享链接
                            imgUrl: 'http://m.laidoulaile.com/static/images/logo.png', // 分享图标
                            type: '', // 分享类型,music、video或link，不填默认为link
                            dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
                            success: function () {
                                // 用户确认分享后执行的回调函数
                                self.$alert("分享成功 :)");
                            },
                            cancel: function () {
                                // 用户取消分享后执行的回调函数
//                                self.$alert("为啥取消了 :(");
                            }
                        });

                        wx.onMenuShareQQ({
                            title: 'EBUY海淘发黑五红包啦，海量免单资格等你来抢！100%有奖哦～', // 分享标题
                            desc: '黑五海外购物狂欢节，EBUY海淘为您免单！', // 分享描述
                            link: curUrl, // 分享链接
                            imgUrl: 'http://m.laidoulaile.com/static/images/logo.png', // 分享图标
                            success: function () {
                                // 用户确认分享后执行的回调函数
                                self.$alert("分享成功 :)");
                            },
                            cancel: function () {
                                // 用户取消分享后执行的回调函数
//                                self.$alert("为啥取消了 :(");
                            }
                        });

                        wx.onMenuShareQZone({
                            title: 'EBUY海淘发黑五红包啦，海量免单资格等你来抢！100%有奖哦～', // 分享标题
                            desc: '黑五海外购物狂欢节，EBUY海淘为您免单！', // 分享描述
                            link: curUrl, // 分享链接
                            imgUrl: 'http://m.laidoulaile.com/static/images/logo.png', // 分享图标
                            success: function () {
                                // 用户确认分享后执行的回调函数
                                self.$alert("分享成功 :)");
                            },
                            cancel: function () {
                                // 用户取消分享后执行的回调函数
//                                self.$alert("为啥取消了 :(");
                            }
                        });

                    });

                    wx.error(function (res) {
//                        self.$alert(res.data);
                    });

                });
            },
            //获取最近抽奖的10个用户
            getRecentlyTenWinner(){
                var me = this;
                Service.getRecentlyTenWinner(null, function (response) {
                    me.winnerarr = response.data.data;
                });
            },
            //获取抽奖次数
            getUserLotterChanceNum(){
                var me = this;
                Service.getUserLotterChanceNum(null, function (response) {
                    me.total_chance_num=response.data.data.times;
                });
            },
            isWechat: function () {
            var me = this;
                        me.wac = window.navigator.userAgent.toLowerCase();
                if (me.wac.match(/MicroMessenger/i) == 'micromessenger') {
                   return true;
                } else {
                    return false;
                }
            },
        	onTransform: function () {
               (function(jQuery){
                    jQuery.fn.myScroll = function(options){
                    //默认配置
                    var defaults = {
                        speed:70,  //滚动速度,值越大速度越慢
                        rowHeight:25 //每行的高度
                    };
                    var opts = jQuery.extend({}, defaults, options),intId = [];
                    function marquee(obj, step){
                        obj.find("ul").animate({
                            marginTop: '-=1'
                        },10,function(){
                                var s = Math.abs(parseInt(jQuery(this).css("margin-top")));
                                if(s >= step){
                                    jQuery(this).find("li").slice(0, 1).appendTo(jQuery(this));
                                    jQuery(this).css("margin-top", 0);
                                }
                            });
                        }
                        this.each(function(i){
                            var sh = opts["rowHeight"],speed = opts["speed"],_this = jQuery(this);
                            intId[i] = setInterval(function(){
                                if(_this.find("ul").height()<=_this.height()){
                                    clearInterval(intId[i]);
                                }else{
                                    marquee(_this, sh);
                                }
                            }, speed);
                            _this.hover(function(){
                                clearInterval(intId[i]);
                            },function(){
                                intId[i] = setInterval(function(){
                                    if(_this.find("ul").height()<=_this.height()){
                                        clearInterval(intId[i]);
                                    }else{
                                        marquee(_this, sh);
                                    }
                                }, speed);
                            });
                            setInterval(function(){
                                    if(_this.find("ul").height()<=_this.height()){
                                        clearInterval(intId[i]);
                                    }else{
                                        marquee(_this, sh);
                                    }
                            }, speed);
                        });
                    }
            })(jQuery);
            jQuery('.black-friday-scroll').myScroll();
            },
            getActivity(){
                var me = this;
                Service.getActivityInfo(2, null, function (response) {
                    me.activity = response.data.data;
                });
            },
            hideFloat : function() {
            	$('.friday-instant-invite').addClass('none');
            },
            showTip: function() {
				if (this.isWechat() == true) {
					$('.floatlayer-black-share').removeClass('none');
				}
				else {
					$('.floatlayer-black-pc').removeClass('none');
				}
			},
			shareTip: function() {
				$('.floatlayer-black-pc').addClass('none');
			},
			hideTip: function() {
				$('.floatlayer-black-pc').addClass('none');
			},
        }
	}
</script>