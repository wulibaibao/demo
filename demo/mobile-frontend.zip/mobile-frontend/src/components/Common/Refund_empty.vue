<style lang="less">
    @import (reference) '../../../static/css/base.less';
    .empty-img {
        .w(114px);
        .h(114px);
        .img;
        .m(78px auto 10px)
    }
    .empty-h3 {
        .mb(44px);
        font-size: 16px;
        color: @9;
        .tac
    }   
    .empty-gosky {
        font-family: 'PingFangSC-Regular';
        .db;
        .w(94%);
        .h(40px);
        .m(0 auto);
        line-height: 40px;
        font-size: 16px;
        background:@6s;
        border-radius: 2px;
        .tac;
        color: @f;
        letter-spacing: 1px
    }
    .empty-refund{
        display:none;
    }
</style>
<template>
    <ebuy-footer></ebuy-footer>
    <div class="empty-bg empty-refund"></div>
    <div class="empty-img empty-refund">
        <img :src="refund_empty_img">
    </div>
    <h3 class="empty-h3 empty-refund">暂无退款</h3>
</template>
<script>
    import EbuyFooter from './Footer.vue'
    module.exports = {
        components: {
            EbuyFooter
        },
        data:function(){
            return {
                refund_empty_img:require('static_file/images/refund_empty.png')
            }
        }

    }
</script>