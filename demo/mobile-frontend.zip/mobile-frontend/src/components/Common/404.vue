<style lang="less">
	@import (reference) '../../../static/css/base.less';
	.empty-img {
		.w(100%);
		.h(100%);
		.img;
		.m(78px auto 10px);
	}
	.empty-gosky {
		font-family: 'PingFangSC-Regular';
		.db;
		.w(94%);
		.h(40px);
		.m(0 auto);
		line-height: 40px;
		font-size: 16px;
		background:@6s;
		border-radius: 2px;
		.tac;
		color: @f;
		letter-spacing: 1px
	}
</style>
<template>
	<div class="empty-bg"></div>
	<div class="empty-img">
		<img :src="unfind">
	</div>
	<a href="javascript:void(0);" class="empty-gosky" @click="goBack">返回</a>
</template>
<script>
	module.exports = {
		data:function(){
			return {
				unfind:require('static_file/images/404.png')
			}
		},
		methods: {
			goBack: function () {
				window.$router.go(window.history.back());
			}
		}
	}
</script>