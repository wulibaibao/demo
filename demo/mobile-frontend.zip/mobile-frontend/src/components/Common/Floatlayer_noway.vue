<style lang="less">
	@import (reference) '../../../static/css/base.less';
	.floatlayer-noway {
		.fix;
		top: 0;
		right: 0;
		bottom: 0;
		left: 0;
		z-index: 11000;
		background: rgba(0,0,0,.4);
		.flexcenter;
		.ebuy-exit-tip {
			.w(80%);
			background:@f;
			border-radius: 2px;
			.tac;
			p {
				font-family: 'PingFangSC-Regular';
				font-size: 16px;
				.pd(20px 36px 15px);
				font-weight: 700;
				color: @3;
			}
			a {
				.db;
				.h(48px);
				line-height: 48px;
				font-size: 16px;
				color: @6s;
				border-top: 2px solid @e;
			}
		}
	}
</style>
<template>
	<div class="floatlayer-noway">
		<div class="ebuy-exit-tip">
			<p>您选择了无法一起有购物品，请查看购物车</p>
			<a href="javascript:void(0);" class="noway-exit">关闭</a>
		</div>
	</div>
</template>