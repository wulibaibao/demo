<style lang="less">
  @import (reference) "../../../static/css/base.less";
  @fa: #fafafa;
  .bottom-fixed {
    .w(100%);
    .fix;
    background-color: @fa;
    left: 0;
    bottom: 0;
    display: flex;
    .tac;
    border-top: 1px solid @e;
    z-index: 110111;
    &>a{
      .db;
      flex:1;
      .pd(2px 0 1px 0);
      &:first-child .ebuy-tab-icon{
        background: url(../../../static/images/home.png) center no-repeat;
        background-size: 26px;
      }
      &.alive:first-child .ebuy-tab-icon{
        background: url(../../../static/images/home_active.png) center no-repeat;
        background-size: 26px;
      }
      &:nth-child(2) .ebuy-tab-icon{
        background: url(../../../static/images/sort.png) center no-repeat;
        background-size: 26px;
      }
      &.alive:nth-child(2) .ebuy-tab-icon{
        background: url(../../../static/images/sort_active.png) center no-repeat;
        background-size: 26px;
      }
      &:nth-child(3) .ebuy-tab-icon{
        background: url(../../../static/images/buycar.png) center no-repeat;
        background-size: 26px;
      }
      &.alive:nth-child(3) .ebuy-tab-icon{
        background: url(../../../static/images/buycar_active.png) center no-repeat;
        background-size: 26px;
      }
      &:last-child .ebuy-tab-icon{
        background: url(../../../static/images/personal.png) center no-repeat;
        background-size: 26px;
      }
      &.alive:last-child .ebuy-tab-icon{
        background: url(../../../static/images/personal_active.png) center no-repeat;
        background-size: 26px;
      }
      &.alive .ebuy-tab-label {
        color: @6s;
      }
    }
  }
  .ebuy-tab-icon {
    width: 26px;
    height:26px;
    margin: 3px auto 3px;
    .img
  }
  .ebuy-tab-label {
    color: @6;
    font-size: 14px;
  }
</style>  
<template>
  <div class="bottom-fixed">
    <a v-link="{name:'home',activeClass:'alive', exact: true}">
      <div class="ebuy-tab-icon"></div>
      <div class="ebuy-tab-label">首页</div>
    </a>
    <a v-link="{path:'/category',activeClass:'alive', exact: true}">
      <div class="ebuy-tab-icon"></div>
      <div class="ebuy-tab-label">分类</div>
    </a>
    <a v-link="{path:'/cart',activeClass:'alive', exact: true}">
      <div class="ebuy-tab-icon"></div>
      <div class="ebuy-tab-label">购物车</div>
    </a>
    <a v-link="{name:'account', activeClass:'alive', exact: true}">
      <div class="ebuy-tab-icon"></div>
      <div class="ebuy-tab-label">个人中心</div>
    </a>
  </div>
</template>
<script>
  module.exports = {
    data:function() {
    	return {
    		
    	}
    }
	}
</script>