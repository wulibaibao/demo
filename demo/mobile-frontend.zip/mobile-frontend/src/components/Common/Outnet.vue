<style lang="less">
	@import (reference) '../../../static/css/base.less';
	.ebuy-out-net {
		.pt(52px);
		font-size: 0;
		clear: both;
		overflow: hidden;
		a {
			.dbi;
			float: left;
			.w(50%);
			.h(100%);
			.img;
			box-sizing: border-box
		}
	}
</style>
<template>
	<ebuy-search></ebuy-search>
	<ebuy-gohome></ebuy-gohome>
	<ebuy-chat></ebuy-chat>
 	<div class="ebuy-out-net">
		<a href="javascript:void(0);"  v-link="{ name: 'seller-goods-list', params: { sellerId: 1 }}"><img :src="my"></a>
		<a href="javascript:void(0);" v-link="{ name: 'seller-goods-list', params: { sellerId: 5 }}"><img :src="ry"></a>
		<a href="javascript:void(0);" v-link="{ name: 'seller-goods-list', params: { sellerId: 4 }}"><img :src="pm"></a>
		<a href="javascript:void(0);" v-link="{ name: 'seller-goods-list', params: { sellerId: 10 }}"><img :src="zappos"></a>
		<a href="javascript:void(0);" v-link="{ name: 'seller-goods-list', params: { sellerId: 3 }}"><img :src="jomashop"></a>
		<a href="javascript:void(0);" v-link="{ name: 'seller-goods-list', params: { sellerId: 7 }}"><img :src="jimmy"></a>
		<a href="javascript:void(0);" v-link="{ name: 'seller-goods-list', params: { sellerId: 9 }}"><img :src="levis"></a>
		<a href="javascript:void(0);" v-link="{ name: 'seller-goods-list', params: { sellerId: 13 }}"><img :src="nb"></a>
		<a href="javascript:void(0);" v-link="{ name: 'seller-goods-list', params: { sellerId: 14 }}"><img :src="gnc"></a>
		<a href="javascript:void(0);" v-link="{ name: 'seller-goods-list', params: { sellerId: 12 }}"><img :src="drug"></a>
		<a href="javascript:void(0);" v-link="{ name: 'seller-goods-list', params: { sellerId: 15 }}"><img :src="ysld"></a>
		<a href="javascript:void(0);" v-link="{ name: 'seller-goods-list', params: { sellerId: 17 }}"><img :src="rebecca"></a>
		<a href="javascript:void(0);" v-link="{ name: 'seller-goods-list', params: { sellerId: 18 }}"><img :src="uy"></a>
		<a href="javascript:void(0);"><img :src="expect"></a>
	</div>
</template>
<script>
	import EbuySearch from './SearchBar.vue'
	import EbuyGohome from './ReturnhomeBubble.vue'
	import EbuyChat from './ChatBubble.vue'
	module.exports = {
		components: {
            EbuySearch,
            EbuyGohome,
            EbuyChat
		},
		data:function(){
			return {
				my:require('static_file/images/my.png'),
				ry:require('static_file/images/ry.png'),
				dy:require('static_file/images/dy.png'),
				uy:require('static_file/images/uy.png'),
				pm:require('static_file/images/6pm.png'),
				zappos:require('static_file/images/zappos.png'),
				jomashop:require('static_file/images/jomashop.png'),
				jimmy:require('static_file/images/jimmy.png'),
				levis:require('static_file/images/levis.png'),
				nb:require('static_file/images/nb.png'),
				gnc:require('static_file/images/gnc.png'),
				drug:require('static_file/images/drug.png'),
				ysld:require('static_file/images/ysld.png'),
				rebecca:require('static_file/images/Rebecca.png'),
				expect:require('static_file/images/expect.png')
			}
		}
	}
</script>