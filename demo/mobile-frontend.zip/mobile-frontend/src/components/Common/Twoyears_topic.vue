<style lang="less" scoped>
    @import (reference) "../../../static/css/base.less";
    @main: #e72d2e;
    .twoyears-topic {
        background-color: @main;
        .pb(36px);
    }

    .topic-pic {
        .w(100%);
        .h(200px);
        img {
            .w(100%);
        }
    }

    .topic-cont {
        h2 {
            line-height: 18px;
            font-size: 12px;
            color: @f;
            font-weight: 800;
            .tac;
            border-bottom: 1px solid @f;
            .bbox
        }
        h3 {
            font-size: 12px;
            color: @f;
            font-weight: 700;
            .tac;
        }
        .worth-buy-sth {
            .m(8px 0 10px);
            .ebuy-worth-buy {
                .pb(5px);
                .special-zone {
                    .h(53px);
                    background: #f1f1f1
                }
            }

            .worth-buy-img {
                .w(120px);
                .h(120px);
                .img;
                .m(0 auto);
            }
            .worth-buy-zone {
                .rel;
                float: left;
                .w(50%);
                background: @f;
                border-radius: 5px;
                border: 2px solid @main;
                box-sizing: border-box;
            }
            .worth-buy-position {
                .m(9px 9px 10px);
                p {
                    font-size: 12px;
                    color: @3;
                    border-bottom: 1px solid @d;
                    height: 38px;
                    line-height: 18px;
                    .lh;
                }
                h5 {
                    .db;
                    text-align: left;
                    .pb(8px);
                    color: @6s;
                    span {
                        font-family: 'PingFangSC-Regular';
                        font-size: 14px;
                    }
                    .pf {
                        font-family: 'PingFangSC-Regular';
                        font-size: 18px;
                    }
                }
            }
            .worth-buy-where {
                .abs;
                bottom: 4px;
                font-size: 10px;
                color: @6
            }
            .worth-buy-block {
                .mb(5px);
                clear: both;
                overflow: hidden;
            }
        }
    }
</style>
<template>
    <ebuy-top></ebuy-top>
    <ebuy-chat></ebuy-chat>
    <ebuy-gohome></ebuy-gohome>
    <div class="twoyears-topic">
        <a class="topic-pic" href="/two-years-draw">
            <img :src="activity.image"/>
        </a>
        <div class="topic-cont" v-for="item in activity.list">
            <h2>{{ item.name }}</h2>
            <h3>{{ item.title }}</h3>
            <div class="worth-buy-sth">
                <div class="worth-buy-block">
                    <a href="javascript:void(0);" class="worth-buy-zone" v-link="{ name: 'goods-detail', params: { goodsId: goods.stock_id }}" v-for="goods in item.goods">
                        <div class="worth-buy-position">
                            <div class="worth-buy-img">
                                <img :src="goods.img | thumb">
                            </div>
                            <p>{{ goods.name }}</p>
                            <h4 class="worth-buy-where">商家：{{ goods.seller.server_num }}</h4>
                            <h5>{{{goods.sell_price | priceFormatter}}}</h5>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import EbuyTop from './GotopBubble.vue'
    import EbuyChat from './ChatBubble.vue'
    import EbuyGohome from './ReturnhomeBubble.vue'
    import Service from '../../utils/service'




    module.exports = {
        components: {
            EbuyTop,
            EbuyChat,
            EbuyGohome
        },
        data: function () {
            return {
                activity: {}
            }
        },
        ready: function () {
            this.getActivity();
        },
        methods: {
            getActivity(){
                var me = this;
                Service.getActivityInfo(1, null, function (response) {
                    me.activity = response.data.data;
                });
            }
        }

    }
</script>