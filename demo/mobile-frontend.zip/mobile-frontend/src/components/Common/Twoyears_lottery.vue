<style lang="less" scoped>
    @import (reference) "../../../static/css/base.less";
    @main: #e72d2e;
    .clear {
        content: '';
        display: table;
        clear: both
    }

    .twoyears-lottery {
        background-color: @main;
        .pb(36px);
    }

    .lot-pic {
        .w(100%);
        .h(200px);
        background: url(../../../static/images/lottery_top.png) center no-repeat;
        background-size: cover;
    }

    .lot-rotate {
        .w(90%);
        max-width: 300px;
        .h(300px);
        .m(18px auto 24px);
        .banner {
            display: block;
            width: 95%;
            margin-left: auto;
            margin-right: auto;
            margin-bottom: 20px;
        }
        .banner .turnplate {
            display: block;
            width: 100%;
            position: relative;
            background-image: url(../../../static/images/turnplate-bg.png);
            background-size: 100% 100%;
            height: 285px;
        }
        .banner .turnplate canvas.item {
            width: 100%;
        }
        .banner .turnplate img.pointer {
            position: absolute;
            width: 43.5%;
            height: 42.5%;
            left: 28.6%;
            top: 26%;
        }
    }

    .lot-scroll {
        .w(90%);
        .m(24px auto);
        .h(140px);
        background-color: #D52627;
        box-shadow: 2px 3px 5px rgba(0, 0, 0, 0.16);
        overflow: hidden;
        border-radius: 2px;
        .lot-animate {
            -webkit-transition: all .3s ease-out;
            transition: all .3s ease-out;
            -moz-transition: all .3s ease-out;
        }
        ul {
            .m(2% 16px);
            overflow: hidden;
            li {
                .hl(32px);
                overflow: hidden;
                &:after {
                    .clear
                }
                h2, h3 {
                    float: left;
                    font-size: 12px;
                    color: #333;
                }
                h2 {
                    .w(40%);
                    .mr(3px);
                    white-space: nowrap;
                    word-break: break-all;
                    text-overflow: ellipsis;
                    overflow: hidden;
                }
                h3 {
                    .w(57%);
                    white-space: nowrap;
                    word-break: break-all;
                    text-overflow: ellipsis;
                    overflow: hidden;
                }
            }
        }
    }

    .lot-rule {
        .w(90%);
        .m(0 auto);
        text-align: left;
        h2, h3 {
            white-space: pre-line;
            word-break: break-all;
        }
        h2 {
            .mb(8px);
            font-size: 14px;
            color: @f;
        }
        h3 {
            line-height: 22px;
            font-size: 12px;
            color: @f;
        }
    }

    .lot-view {
        .p(38px 0 12px);
        a {
            .db;
            .w(50%);
            .m(0 auto);
            .hl(30px);
            font-size: 14px;
            font-weight: 800;
            color: #333;
            background-color: @f;
            .tac;
            border-radius: 3px;
            &:hover {
                .op8
            }
        }
    }

    .lot-series {
        .fix;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        z-index: 11000;
        background: rgba(0, 0, 0, .6);
        .flexcenter;
        .join-ser {
            .rel;
            .w(80%);
            background-color: @f;
            border-radius: 2px;
            text-align: left;
            h2 {
                .m(55px auto 12px);
                font-size: 14px;
                font-weight: 800;
                white-space: nowrap;
                word-break: break-all;
                color: #333;
                .tac;
            }
            h3 {
                font-size: 12px;
                color: #333;
                font-weight: 700;
                .tac;
            }
            .lot-but {
                .m(35px auto 0);
                .pb(30px);
                .tac;
                a {
                    .db;
                    .w(62.5%);
                    .hl(25px);
                    font-size: 12px;
                    font-weight: 700;
                    color: @f;
                    .tac;
                    border-radius: 3px;
                    .m(0 auto);
                    background-color: @main;
                }
            }
            .lot-exit {
                .abs;
                right: 0;
                top: 0;
                .w(20px);
                .h(20px);
                background: url(../../../static/images/lot_exit.png) center no-repeat;
                background-size: 9px;
                background-color: #000;
                border-radius: 2px;
                filter: alpha(opacity=60);
                -moz-opacity: 0.6;
                -khtml-opacity: 0.6;
                opacity: 0.6;
            }
            input[type=text] {
                .db;
                .w(70%);
                .m(0 auto);
                margin-bottom: 20px;
                padding: 6px 10px;
                line-height: 12px;
                font-size: 12px;
                color: #999;
                border: none;
                background-color: #f1f1f1;
                border-radius: 2px;
            }
        }
    }

    .lot-scroll ul li {
        height: 32px;
        line-height: 32px;
        overflow: hidden;
    }

    .lot-scroll ul li h2 {
        width: 40%;
        margin-right: 3px;
        white-space: nowrap;
        word-break: break-all;
        text-overflow: ellipsis;
        color: white;
        overflow: hidden;
    }

    .lot-scroll ul li h3 {
        width: 50%;
        margin-right: 3px;
        white-space: nowrap;
        word-break: break-all;
        text-overflow: ellipsis;
        overflow: hidden;
        float: left;
        font-size: 12px;
        color: white;
    }

    @media screen and (max-width: 320px) {
        .lot-rotate .banner .turnplate img.pointer {
            top: 24%
        }
    }
</style>
<template>
    <ebuy-top></ebuy-top>
    <ebuy-chat></ebuy-chat>
    <ebuy-gohome></ebuy-gohome>
    <div class="twoyears-lottery">
        <p class="lot-pic"></p>
        <!--转盘位置-->
        <div class="lot-rotate">
            <div class="banner">
                <div class="turnplate">
                    <canvas class="item" id="wheelcanvas" width="422px" height="422px"></canvas>
                    <img :src="turnplatepointer" class="pointer"/>
                </div>
            </div>
        </div>
        <!--end-->
        <div class="lot-scroll" id="winner_least">
            <ul>
                <li v-for="winner in winnerarr"><h2>用户{{ winner.username }}</h2>
                    <h3>{{ winner.remark }}</h3></li>
            </ul>
        </div>
        <div class="lot-rule">
            <h2>活动规则：</h2>
            <h3>EBUY海淘注册用户均可参加本次活动；</h3>
            <h3>每人每天可免费抽奖一次，活动期间每天均可以参加活动；</h3>
            <h3>实物类奖品中奖后请填写手机号用于客服电话通知，否则视为自行弃奖；</h3>
            <h3>优惠券类奖品中奖后将直接发送到您的账户，购物时即可使用且无任何限制，特殊商品除外；</h3>
            <h3>活动时间：2016.10.24－2016.10.30；</h3>
            <h3>本活动最终解释权归EBUY海淘所有。</h3>
        </div>
        <div class="lot-view">
            <a href="/two-years">查看二周年活动专题</a>
        </div>
    </div>

    <div class="lot-series floatlayer-done" style="display:none;">
        <div class="join-ser">
            <a href="javascript:void(0);" class="lot-exit"></a>
            <h2></h2>
            <div class="lot-but"><a href="/two-years">查看二周年活动专题</a></div>
        </div>
    </div>
    <!--恭喜您获得优惠券-->
    <div class="lot-series  floatlayer" style="display:none;">
        <div class="join-ser">
            <a href="javascript:void(0);" class="lot-exit"></a>
            <h2>恭喜您获得十元优惠券！</h2>
            <div class="lot-but"><a href="/two-years">快去买买买吧</a></div>
        </div>
    </div>
    <!--恭喜您获得实物奖励-->
    <div class="lot-series  floatlayer-true" style="display:none;">
        <div class="join-ser">
            <a href="javascript:void(0);" class="lot-exit"></a>
            <h2>恭喜您获得实物奖励！</h2>
            <form action="" autocomplete="off">
                <input type="text" placeholder="姓名" class="ebuy-name" name='realname'/>
                <input type="text" placeholder="电话" class="ebuy-mobile" name='mobile'/>
            </form>
            <div class="lot-but"><a href="#" id="add_winner_info">确定</a></div>
        </div>
    </div>

</template>
<script>
    import EbuyTop from './GotopBubble.vue'
    import EbuyChat from './ChatBubble.vue'
    import EbuyGohome from './ReturnhomeBubble.vue'
    require('../../../static/js/awardRotate.js')
    import Service from '../../utils/service'

    var turnplate = {
        restaraunts: [],				//大转盘奖品名称
        colors: [],					//大转盘奖品区块对应背景颜色
        outsideRadius: 195,			//大转盘外圆的半径
        textRadius: 145,				//大转盘奖品位置距离圆心的距离
        insideRadius: 60,			//大转盘内圆的半径
        startAngle: 0,				//开始角度
        bRotate: false				//false:停止;ture:旋转
    };

    jQuery(document).ready(function () {
        //动态添加大转盘的奖品与奖品区域背景颜色
        turnplate.restaraunts = ["iPhone 7 Plus 32g", "DW手表", "飞利浦电动牙刷", "40元运费券", "20元运费券", "10元运费劵"];
        turnplate.colors = ["#FFFFFF", "#FFF1D7", "#FFFFFF", "#FFF1D7", "#FFFFFF", "#FFF1D7"];


        var rotateTimeOut = function () {
            jQuery('#wheelcanvas').rotate({
                angle: 0,
                animateTo: 2160,
                duration: 8000,
                callback: function () {
                    alert('网络超时，请检查您的网络设置！');
                }
            });
        };

        //旋转转盘 item:奖品位置; txt：提示语;
        var rotateFn = function (item, txt, username) {
            var angles = item * (360 / turnplate.restaraunts.length) - (360 / (turnplate.restaraunts.length * 2));
            if (angles < 270) {
                angles = 270 - angles;
            } else {
                angles = 360 - angles + 270;
            }
            jQuery('#wheelcanvas').stopRotate();
            jQuery('#wheelcanvas').rotate({
                angle: 0,
                animateTo: angles + 1800,
                duration: 8000,
                callback: function () {
                    turnplate.bRotate = false;
                    if (item < 4) {
                        //说明获取实物奖励
                        jQuery('.floatlayer-true').show();
                    } else {
                        jQuery(".floatlayer h2").html(txt);
                        jQuery(".floatlayer").show();
                    }
//                    jQuery(".lot-scroll ul").prepend("<li><h2>用户" + username + "</h2><h3>" + txt + "</h3></li>");
//                    jQuery('.lot-scroll ul li:gt(9)').remove();
                }
            });
        };

        jQuery('.pointer').click(function () {
            if (turnplate.bRotate)
                return;
            turnplate.bRotate = true;
            Service.getlotteryInfo(null, function (response) {
                var data = response.data;
                var status = response.data.status;
                var index = response.data.index;
                var msg = response.data.msg;
                var username = response.data.username;
                if (status > 0) {
                    rotateFn(index + 1, "恭喜您" + msg, username);
                } else {
                    turnplate.bRotate = false;
                    jQuery(".floatlayer-done h2").html(msg);
                    jQuery(".floatlayer-done").show();
                    return false;
                }
            });
        });
        jQuery('.lot-exit').on('click', function () {
            $('.lot-series').hide();
        });

        jQuery('#add_winner_info').on('click', function () {
            var realname = $('form input[name=realname]').val();
            var mobile = $('form input[name=mobile]').val();
            if (!(realname && mobile)) {
                return false;
            }

            if (!((mobile.length == 11) && (!isNaN(mobile)))) {
                alert("请填写正确的电话号码");
                return false;
            }
            ;
            var data = {
                realname: realname,
                mobile: mobile
            };
            Service.addwinnerInfo(data, null, function (response) {
                if (response.data.success) {
                    alert("信息填写成功");
                    $('.floatlayer-true').hide();
                    return false;
                } else {
                    alert(response.data.errmsg);
                }
            });


        });

    });

    function rnd(n, m) {
        var random = Math.floor(Math.random() * (m - n + 1) + n);
        return random;

    }

    jQuery(function () {
        drawRouletteWheel();
    })

    function drawRouletteWheel() {
        var canvas = document.getElementById("wheelcanvas");
        if (canvas.getContext) {
            //根据奖品个数计算圆周角度
            var arc = Math.PI / (turnplate.restaraunts.length / 2);
            var ctx = canvas.getContext("2d");
            //在给定矩形内清空一个矩形
            ctx.clearRect(0, 0, 422, 422);
            //strokeStyle 属性设置或返回用于笔触的颜色、渐变或模式
            ctx.strokeStyle = "#FFBE04";
            //font 属性设置或返回画布上文本内容的当前字体属性
            ctx.font = 'bold 16px Microsoft YaHei';
            for (var i = 0; i < turnplate.restaraunts.length; i++) {
                var angle = turnplate.startAngle + i * arc;
                ctx.fillStyle = turnplate.colors[i];
                ctx.beginPath();
                //arc(x,y,r,起始角,结束角,绘制方向) 方法创建弧/曲线（用于创建圆或部分圆）
                ctx.arc(211, 211, turnplate.outsideRadius, angle, angle + arc, false);
                ctx.arc(211, 211, turnplate.insideRadius, angle + arc, angle, true);
                ctx.stroke();
                ctx.fill();
                //锁画布(为了保存之前的画布状态)
                ctx.save();

                //----绘制奖品开始----
                ctx.fillStyle = "#e72d2e";
                var text = turnplate.restaraunts[i];
                var line_height = 17;
                //translate方法重新映射画布上的 (0,0) 位置
                ctx.translate(211 + Math.cos(angle + arc / 2) * turnplate.textRadius, 211 + Math.sin(angle + arc / 2) * turnplate.textRadius);

                //rotate方法旋转当前的绘图
                ctx.rotate(angle + arc / 2 + Math.PI / 2);

                /** 下面代码根据奖品类型、奖品名称长度渲染不同效果，如字体、颜色、图片效果。(具体根据实际情况改变) **/
                if (text.indexOf("M") > 0) {//流量包
                    var texts = text.split("M");
                    for (var j = 0; j < texts.length; j++) {
                        ctx.font = j == 0 ? 'bold 22px Microsoft YaHei' : '16px Microsoft YaHei';
                        if (j == 0) {
                            ctx.fillText(texts[j] + "M", -ctx.measureText(texts[j] + "M").width / 2, j * line_height);
                        } else {
                            ctx.fillText(texts[j], -ctx.measureText(texts[j]).width / 2, j * line_height);
                        }
                    }
                } else if (text.indexOf("M") == -1 && text.length > 6) {//奖品名称长度超过一定范围
                    text = text.substring(0, 6) + "||" + text.substring(6);
                    var texts = text.split("||");
                    for (var j = 0; j < texts.length; j++) {
                        ctx.fillText(texts[j], -ctx.measureText(texts[j]).width / 2, j * line_height);
                    }
                } else {
                    //在画布上绘制填色的文本。文本的默认颜色是黑色
                    //measureText()方法返回包含一个对象，该对象包含以像素计的指定字体宽度
                    ctx.fillText(text, -ctx.measureText(text).width / 2, 0);
                }


                //把当前画布返回（调整）到上一个save()状态之前
                ctx.restore();
                //----绘制奖品结束----
            }
        }
    }

    module.exports = {
        components: {
            EbuyTop,
            EbuyChat,
            EbuyGohome
        },
        data: function () {
            return {
                turnplatepointer: require('static_file/images/turnplate-pointer.png'),
                winnerarr: []
            }
        },
        ready: function () {
            this.getWinnerLatestInfo();
            this.onTransform();
        },
        methods: {
            getWinnerLatestInfo(){
                var me = this;
                Service.getwinnerlatestInfo(null, function (response) {
                    me.winnerarr = response.data;
                });
            },
            onTransform: function () {
               (function($){
                    $.fn.myScroll = function(options){
                    //默认配置
                    var defaults = {
                        speed:40,  //滚动速度,值越大速度越慢
                        rowHeight:32 //每行的高度
                    };

                    var opts = $.extend({}, defaults, options),intId = [];

                    function marquee(obj, step){

                        obj.find("ul").animate({
                            marginTop: '-=1'
                        },0,function(){
                                var s = Math.abs(parseInt($(this).css("margin-top")));
                                if(s >= step){
                                    $(this).find("li").slice(0, 1).appendTo($(this));
                                    $(this).css("margin-top", 0);
                                }
                            });
                        }

                        this.each(function(i){
                            var sh = opts["rowHeight"],speed = opts["speed"],_this = $(this);
                            intId[i] = setInterval(function(){
                                if(_this.find("ul").height()<=_this.height()){
                                    clearInterval(intId[i]);
                                }else{
                                    marquee(_this, sh);
                                }
                            }, speed);

                            _this.hover(function(){
                                clearInterval(intId[i]);
                            },function(){
                                intId[i] = setInterval(function(){
                                    if(_this.find("ul").height()<=_this.height()){
                                        clearInterval(intId[i]);
                                    }else{
                                        marquee(_this, sh);
                                    }
                                }, speed);
                            });

                            setInterval(function(){
                                    if(_this.find("ul").height()<=_this.height()){
                                        clearInterval(intId[i]);
                                    }else{
                                        marquee(_this, sh);
                                    }
                            }, speed);


                        });

                    }

            })(jQuery);

            jQuery('.lot-scroll').myScroll();
            }
        }
    };
</script>