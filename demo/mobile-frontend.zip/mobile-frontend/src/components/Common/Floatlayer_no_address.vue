<style lang="less">
	@import (reference) '../../../static/css/base.less';
	.empty-img {
		.w(114px);
		.h(114px);
		.img;
		.m(78px auto 10px)
	}
	.empty-h3 {
		.mb(44px);
		font-size: 15px;
		color: @9;
		.tac
	}	
	.empty-gosky {
		font-family: 'PingFangSC-Regular';
		.db;
		.w(94%);
		.h(40px);
		.m(0 auto);
		line-height: 40px;
		font-size: 16px;
		background: @6s;
		border-radius: 2px;
		.tac;
		color: @f;
		letter-spacing: 1px
	}
</style>
<template>
	<ebuy-footer></ebuy-footer>
	<div class="empty-bg"></div>
	<div class="empty-img">
		<img :src="no_address_img">
	</div>
	<h3 class="empty-h3">暂无记录</h3>
	<a href="javascript:void(0);" class="empty-gosky">添加新地址</a>
</template>
<script>
	import EbuyFooter from './Footer.vue'
	module.exports = {
		components: {
			EbuyFooter
		},
		data:function(){
			return {
				no_address_img:require('static_file/images/no_address.png')
			}
		}

	}
</script>