<style lang="less">
	@import (reference) '../../../static/css/base.less';
	.ebuy-sort-show {
		.pd(52px 0 50px 0);
	}
	.show-block {
		font-size: 0;
		clear: both;
		overflow: hidden;
		&>a,&>.ebuy-special-show {
			.dbi;
			float: left;
			.w(50%);
			box-sizing: border-box;
		}
		&>a {
			.img
		}
	}
	.ebuy-special-show {
		a {
			.db;
			.img;
		}
	}
</style>
<template>
	<ebuy-search></ebuy-search>
	<ebuy-chat></ebuy-chat>
	<div class="ebuy-sort-show">
		<div class="show-block">
			<a href="javascript:void(0);" v-link="{ name: 'category-goods-list', params: { categoryId: 5 }}"><img :src="dress"></a>
			<div class="ebuy-special-show">
				<a href="javascript:void(0);" v-link="{ name: 'category-goods-list', params: { categoryId: 6 }}"><img :src="bag"></a>
				<a href="javascript:void(0);" v-link="{ name: 'category-goods-list', params: { categoryId: 9 }}"><img :src="sports"></a>
			</div>
		</div>
		<div class="show-block">
			<div class="ebuy-special-show">
				<a href="javascript:void(0);" v-link="{ name: 'category-goods-list', params: { categoryId: 8 }}"><img :src="camera"></a>
				<a href="javascript:void(0);" v-link="{ name: 'category-goods-list', params: { categoryId: 1 }}"><img :src="watch"></a>
			</div>
			<a href="javascript:void(0);" v-link="{ name: 'category-goods-list', params: { categoryId: 3 }}"><img :src="beautiful"></a>
		</div>
		<div class="show-block">
			<a href="javascript:void(0);" v-link="{ name: 'category-goods-list', params: { categoryId: 2 }}"><img :src="baby"></a>
			<div class="ebuy-special-show">
				<a href="javascript:void(0);" v-link="{ name: 'category-goods-list', params: { categoryId: 4 }}"><img :src="medicine"></a>
				<a href="javascript:void(0);" v-link="{ name: 'category-goods-list', params: { categoryId: 7 }}"><img :src="family"></a>
			</div>
		</div>
	</div>
	<ebuy-footer></ebuy-footer>
</template>
<script>
    import EbuySearch from './SearchBar.vue'
    import EbuyFooter from './Footer.vue'
    import EbuyChat from './ChatBubble.vue'
	module.exports = {
		components: {
			EbuySearch,
			EbuyFooter,
			EbuyChat
		},
		data:function() {
			return {
				baby:require('static_file/images/sort_baby.png'),
				bag:require('static_file/images/sort_bag.png'),
				beautiful:require('static_file/images/sort_beautiful.png'),
				camera:require('static_file/images/sort_camera.png'),
				dress:require('static_file/images/sort_dress.png'),
				family:require('static_file/images/sort_family.png'),
				medicine:require('static_file/images/sort_medicine.png'),
				sports:require('static_file/images/sort_sports.png'),
				watch:require('static_file/images/sort_watch.png')							
			}
		}
	}
</script>