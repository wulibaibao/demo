<style lang="less">
    @import (reference) "../../../static/css/base.less";
    .ebuy-goto-top {
        .db;
        .fix;
        .op0;
        bottom: 72px;
        right: 12px;
        width: 36px;
        height: 36px;
        background-image: url(../../../static/images/top.png);
        background-repeat: no-repeat;
        background-size: contain;
        background-position: center;
        z-index: 530;
    }
</style>
<template>
    <a href="javascript:void(0);" class="ebuy-goto-top" @click="goTop"></a>
</template>

<script>
    $(window).on('scroll', function () {
        var position = window.pageYOffset;
        var height = $(window).height();
        var opacity = position / (height + 214); // 幻灯片的高度

        if (position >= height + 214) {
            $('.ebuy-goto-top').css({opacity: 1});
        } else {
            $('.ebuy-goto-top').css({opacity: 0});
        }
    });

    module.exports = {
        methods: {
            goTop: function () {
                window.scrollTo(0, 0)
            }
        }
    }
</script>