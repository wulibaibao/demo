<style lang="less">
    @import (reference) '../../../static/css/base.less';
    .customer-service {
        & > p {
            line-height: 20px;
            .mt(15px);
            .p(20px 12px 30px);
            background: #f1f1f1;
            font-size: 14px;
            color: @6;
        }
        .tencent {
            .mt(45px);
            .p(25px 0 25px 94px);
            background: #f1f1f1;
            font-size: 0;
            & > span {
                .dbi;
                .w(40px);
                .h(40px);
                .mr(15px);
                background: url(../../../static/images/q.png) center no-repeat;
                background-size: 40px;
                vertical-align: middle;
            }
            & > h3 {
                .dbi;
                font-size: 14px;
                font-weight: 700;
                color: @6;
                vertical-align: middle;
                cursor: text;
            }
        }
        .wechat {
            .mt(25px);
            .p(17px 55px);
            background: #f1f1f1;
            ul {
                clear: both;
                overflow: hidden;
            }
            li {
                .tac
            }
            li:first-child {
                float: left
            }
            li:last-child {
                float: right
            }
            a {
                .dbi;
                .w(75px);
                .h(75px);
                .img;
                cursor: text;
            }
            p {
                .mt(3px);
                font-size: 12px;
                color: @6;
                letter-spacing: 1px;
            }
        }
        .mt100 {
            .mt(50px)
        }
    }
</style>
<template>
    <div class="customer-service">
        <p>点击联系客服可以在线与Ebuy客服联系，若客服不在线，您也可以留言给我们，收到留言我们会及时回复。</p>
        <div class="tencent">
            <span></span>
            <h3>QQ群：241370629</h3>
        </div>
        <div class="wechat">
            <ul>
                <li>
                    <a>
                        <img :src="service">
                    </a>
                    <p>EBUY海淘服务号</p>
                </li>
                <li>
                    <a>
                        <img :src="subscribe">
                    </a>
                    <p>EBUY海淘订阅号</p>
                </li>
            </ul>
        </div>
        <div class="ebuy-pay-button mt100">
            <a href="javascript:void(0);" class="ebuy-go-pay" @click="onlineService">在线客服</a>
        </div>
    </div>
    <div class="empty-bg"></div>
</template>
<script>
    (function (m, ei, q, i, a, j, s) {
        m[a] = m[a] || function () {
                    (m[a].a = m[a].a || []).push(arguments)
                };
        j = ei.createElement(q),
                s = ei.getElementsByTagName(q)[0];
        j.async = true;
        j.charset = 'UTF-8';
        j.src = i + '?v=' + new Date().getUTCDate();
        s.parentNode.insertBefore(j, s);
    })(window, document, 'script', '//static.meiqia.com/dist/meiqia.js', '_MEIQIA');
    _MEIQIA('entId', 4737);

    // 在这里开启手动模式（必须紧跟美洽的嵌入代码）
    _MEIQIA('manualInit');
    _MEIQIA('withoutBtn');
    _MEIQIA('allSet', function () {
        _MEIQIA('showPanel');
    });

    module.exports = {
        data: function () {
            return {
                subscribe: require('static_file/images/subscribe.png'),
                service: require('static_file/images/service.png'),
            }
        },
        methods: {
            onlineService: function () {
                _MEIQIA('init');
            }
        }
    }
</script>