<style lang="less">
    @import (reference) "../../../static/css/base.less";
    .ebuy-search {
        .fix;
        width: 100%;
        max-width: 640px;
        padding: 8px 12px;
        box-sizing: border-box;
        z-index: 10001;
    }

    .ebuy-search-bar-cover {
        .abs;
        .op0;
        width: 100%;
        height: 54px;
        top: 0;
        left: 0;
        background: @f;
        border-bottom: 1px solid @e;
        box-sizing: border-box;
    }

    .ebuy-search-bar-box {
        .rel;
        border-radius: 20px;
        background: @f;
        font-size: 0;
        opacity: .8;
        border: 1px solid @6;
    }

    .ebuy-search-icon {
        .dbi;
        width: 16px;
        height: 16px;
        .m(0 3px 0 12px);
        background-image: url(../../../static/images/glass.png);
        background-size: contain;
        background-repeat: no-repeat;
        background-position: center;
        vertical-align: middle;
    }

    .ebuy-search-bar-input {
        height: 100%;
        .dbi;
        .w(80%);
        .p(9px 0);
        vertical-align: middle;
        overflow: hidden;
        & > input[type="text"] {
            border: 0;
            background: 0;
            .dbi;
            font-size: 14px;
            color: @6;
            line-height: 1.2em;
            height: 1.2em;
            .w(100%);
            vertical-align: middle;
        }
    }

    .search-details {
        background: @f;
        position: fixed;
        left: 0;
        top: 0;
        right: 0;
        bottom: 0;
        width: 100%;
        height: 100%;
        z-index: 20000;
        display: none;

        .fix-module {
            .fix;
            .w(100%);
            .h(48px);
            z-index: 10001;
            background: @f
        }
        .recently {
            .pt(48px);
        }
        .title {
            .rel;
            .flex;
            .h(48px);
            .p(9px 12px);
            border-bottom: 1px solid @e;
            box-sizing: border-box;
        }
        .cancel {
            .db;
            .w(43px);
            .h(30px);
            line-height: 30px;
            font-size: 12px;
            color: @9;
            .tac;
            border: 1px solid #e1e1e1;
            border-radius: 3px;
            box-sizing: border-box;
            vertical-align: middle;
        }
        .search-cont {
            .rel;
            flex: 1;
            .w(100%);
            .h(30px);
            line-height: 30px;
            .m(0 10px);
            overflow: hidden;
            & > input[type="text"] {
                .db;
                .abs;
                left: 0;
                top: 0;
                .w(100%);
                background: 0;
                line-height: 30px;
                .h(30px);
                .p(9px 30px 9px 12px);
                font-size: 12px;
                color: @9;
                border: 1px solid @6s;
                border-radius: 15px;
                box-sizing: border-box;
            }
            .del {
                .abs;
                right: 12px;
                top: 7px;
                .w(16px);
                .h(16px);
                line-height: 11px;
                font-size: 15px;
                color: @9;
                .tac;
                border: 1px solid @9;
                border-radius: 50%;
                box-sizing: border-box;
                cursor: pointer;
            }
        }
        .search {
            .db;
            .w(64px);
            .h(30px);
            line-height: 30px;
            font-size: 14px;
            color: @f;
            border-radius: 3px;
            background: @6s;
            .tac;
        }
        .progress {
            background: #fff;
            position: absolute;
            left: 1px;
            right: 1px;
            top: 1px;
            bottom: 1px;
            border-radius: 15px;
            box-sizing: border-box;
        }
        .mt-progress-progress {
            background: @6s !important;
        }
        .pos {
            .rel;
            .mt(9px);
            .p(0 12px 14px);
            border-bottom: 1px solid @e;
            box-sizing: border-box;
            .del-recent {
                .abs;
                right: 12px;
                top: 0;
                .w(14px);
                .h(16px);
                background: url(../../../static/images/del_recent.png) center no-repeat;
                background-size: 14px 16px;
            }
        }
        .spe {
            border-bottom: none;
        }
        .tit {
            font-size: 0;
            & > span {
                .dbi;
                .w(4px);
                .h(12px);
                background: @6s;
                border-radius: 2px;
                vertical-align: baseline;
            }
            & > h3 {
                .dbi;
                .pl(10px);
                font-size: 12px;
                color: @6;
            }
            & > span, & > h3 {
                vertical-align: middle;
            }
        }
        .rec-search {
            .mt(10px);
            clear: both;
            overflow: hidden;
        }
        .rec-search li {
            float: left;
            .mr(9px);
            .mb(9px);
            border-radius: 3px;
            border: 1px solid transparent;
            box-sizing: border-box;
        }
        .rec-search a {
            .db;
            max-width: 150px;
            font-size: 12px;
            color: @6;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
        }
        .spe a {
            .w(69px);
            .h(25px);
            line-height: 25px;
            .tac;
            background: @e;
            letter-spacing: 1px;
        }
        .spe ul li:first-child a{
            border: 1px solid @6s;
            border-radius: 3px;
            box-sizing: border-box;
        }
        .print-search-cont {
            .abs;
            top: 48px;
            .w(100%);
            .h(100%);
            background: @f;
            .pl(12px);
            li {
                border-bottom: 1px solid @e;
                box-sizing: border-box;
            }
            a {
                .db;
                .h(30px);
                line-height: 30px;
                font-size: 12px;
                color: @6;
            }
        }
    }

    .teach-show {
        display: none;
        .fix;
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
        .w(100%);
        .h(auto);
        overflow-y: scroll;
        z-index: 999999;
        & > img {
            .db;
            .w(100%)
        }
        .exit-img {
            .fix;
            .db;
            top: 20px;
            right: 20px;
            .w(40px);
            .h(40px);
            line-height: 38px;
            border-radius: 50%;
            .tac;
            background:#000;
            color: @f;
            opacity: .6;
            font-size: 22px;
            background: rgba(0,0,0,.6)
        }
    }
</style>
<template>
    <!-- search bar -->
    <div class="ebuy-search">
        <div class="ebuy-search-bar-cover"></div>
        <div class="ebuy-search-bar">
            <div class="ebuy-search-bar-box">
                <span class="ebuy-search-icon"></span>
                <div class="ebuy-search-bar-input">
                    <input type="text" readonly="readonly" autocomplete="off" id="index_newkeyword"
                           placeholder="请输入需要搜索的商品"
                           @click="toggle">
                </div>
            </div>
        </div>
    </div>
    <!-- / search bar -->

    <div class="search-details">
        <div class="fix-module">
            <div class="title">
                <a href="javascript:void(0);" class="cancel" @click="cancel">取消</a>
                <form onsubmit="return false" class="search-cont" autocomplete="off">
                    <input type="text" placeholder="请输入需要搜索的商品" name="query" v-model="query" v-focus-model="focused"
                           v-focus-auto
                           @keyup.enter="search">
                    <span class="del" @click="clear" v-show="query.length > 0">x</span>
                    <div class="progress" v-if="searching">
                        <mt-progress :value="progress" :bar-height="2"></mt-progress>
                    </div>
                </form>
                <a href="javascript:void(0);" class="search" @click="search">搜索</a>
            </div>
        </div>
        <div class="recently">
            <div class="pos" v-show="recent.length">
                <a href="javascript:void(0);" class="del-recent" @click="delRecent"></a>
                <div class="tit">
                    <span></span>
                    <h3>最近搜索</h3>
                </div>
                <ul class="rec-search">
                    <li v-for="word in recent">
                        <a href="javascript:void(0);" @click="quickSearch(word)">{{word}}</a>
                    </li>
                </ul>
            </div>
            <div class="pos spe">
                <div class="tit">
                    <span></span>
                    <h3>热搜</h3>
                </div>
                <ul class="rec-search">
                    <li>
                        <a href="javascript:void(0);" @click="teachShow">海淘教程</a>
                    </li>
                </ul>
            </div>
        </div>
        <!--click search input show-->
        <div class="print-search-cont" v-if="query.length > 100000">
            <ul>
                <!--第一级li为店铺搜索-->
                <li>
                    <a href="javascript:void(0);">搜索结果</a>
                </li>
                <!--第二类开始种类搜索-->
                <li>
                    <a href="javascript:void(0);">手机</a>
                </li>
                <li>
                    <a href="javascript:void(0);">手机</a>
                </li>
            </ul>
        </div>
    </div>
    <div class="teach-show" @click.stop="hideImg">
        <img :src="teach">
        <a href="javascript:void(0)" class="exit-img" @click.stop="hideImg">x</a>
    </div>
</template>
<script>
    var Vue = require('vue');

    var VueResource = require('vue-resource');
    Vue.use(VueResource);

    import {Indicator} from "mint-ui";
    import {Progress} from 'mint-ui';
    import * as VueFocus from 'vue-focus';

    Vue.component(Progress.name, Progress);

    $(window).on('scroll', function () {
        var position = window.pageYOffset;
        var opacity = position / 214; // 幻灯片的高度

        if (position >= 214) {
            $('.ebuy-search-bar-cover').css({opacity: 1});
        } else {
            $('.ebuy-search-bar-cover').css({opacity: 0});
        }
    });

    module.exports = {
        mixins: [VueFocus.mixin],
        data: function () {
            return {
                searching: false,
                query: '',
                progress: 0,
                focused: false,
                teach: require('static_file/images/teach.png'),
                recent: [],
            }
        },
        ready: function () {
            var recentSearch = localStorage.getItem('recent_search');

            if (recentSearch) {
                this.recent = JSON.parse(recentSearch);
            }
        },
        methods: {
            toggle: function () {
                $('.search-details').css('display', 'block');
                this.focused = true;
            },
            teachShow: function () {
                $('.teach-show').show();
            },
            hideImg: function () {
                $('.teach-show').hide();
            },
            cancel: function () {
                $('.search-details').css('display', 'none');

                this.focused = false;
            },
            clear: function () {
                this.query = ''
            },
            delRecent: function () {
                this.recent = [];

                localStorage.removeItem('recent_search');
            },
            search: function () {
                if (this.query.length <= 0) {
                    this.$alert('请输入搜索词');

                    return;
                }

                var regExp = new RegExp(/^http/);

                if (!regExp.test(this.query)) {
                    this.searchByTerm();
                } else {
                    this.searchByUrl();
                }
            },
            searchByTerm: function () {
                // term search

                this.recent.push(this.query);
                localStorage.setItem('recent_search', JSON.stringify(this.recent));

                this.quickSearch(this.query);
            },

            quickSearch: function (word) {
                window.location.href = '/search/q/' + encodeURIComponent(word);
            },

            searchByUrl: function () {
                // url search

                this.searching = true;
                var self = this;

                Vue.http({
                    url: window.$backendUrl + '/site/add',
                    data: {
                        url: this.query
                    },
                    emulateJSON: true,
                    method: 'POST',
                    headers: {},
                    beforeSend: function (request) {
                        Indicator.open({
                            spinnerType: 'snake'
                        });

                        setTimeout(function () {
                            var timer = setInterval(function () {
                                if (++self.progress == 100) {
                                    clearInterval(timer);
                                }
                            });

                        }, 1500);
                    }
                }).then(function (response) {

                    Indicator.close();
                    self.progress = 0;
                    self.searching = false;

                    if (response.data.status == 200) {
                        self.$alert('商品信息抓取成功');
                        window.$router.go({name: 'goods-detail', params: {goodsId: response.data.data.goodsId}});
                    } else {
                        self.$alert(response.data.data.msg);
                    }

                }, function (response) {

                    Indicator.close();
                    self.searching = false;
                    self.progress = 0;

                    self.$alert(response.data.data.msg);
                });
            }
        }
    }
</script>