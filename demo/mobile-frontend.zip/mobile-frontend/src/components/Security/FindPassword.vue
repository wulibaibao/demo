<style lang="less">
    @import (reference) '../../../static/css/base.less';
    .find-pwd-module {
        .sign-pos {
            .m(67px 16px 34px);
        }
        input[type="tel"], input[type="text"], input[type="password"] {
            .db;
            .w(100%);
            .h(20px);
            line-height: 20px;
            font-size: 14px;
            .p(10px 0);
            color: @9;
            border: none;
            background: transparent;
            border-bottom: 1px solid @d
        }
        input[type="text"] {
            .mt(23px)
        }
        .message-get {
            .flex;
            & > a {
                .db;
                .w(103px);
                .h(35px);
                .mt(9px);
                .ml(10px);
                line-height: 35px;
                .tac;
                font-size: 14px;
                color: @6;
                border: 1px solid @6s;
                border-radius: 2px
            }
        }
        input[type="password"] {
            .mt(23px)
        }
    }
</style>
<template>
    <form class="find-pwd-module" autocomplete="off" onsubmit="return false;">
        <div class="sign-pos">
            <input type="tel" v-model="data.mobile" placeholder="请输入您的手机号">
            <div class="message-get">
                <input type="text" v-model="data.mobileCode" placeholder="请输入短信验证码">
                <a href="javascript:void(0);" @click="sendMobileCode" v-if="!data.sent">获取验证码</a>
                <a href="javascript:void(0);" class="disabled" v-else>{{data.countdown}}秒后重发</a>
            </div>
            <input type="password" v-model="data.password" placeholder="请设置您的登录密码(6-32字符)">
        </div>
        <div class="ebuy-pay-button">
            <button class="ebuy-go-pay" @click="tryReset">确认重置</button>
        </div>
        <div class="empty-bg"></div>
    </form>
</template>
<script>
    import Service from '../../utils/service'
    import User from '../../utils/user'

    module.exports = {
        data: function () {
            return {
                data: {
                    sent: false,
                    countdown: 60
                }
            }
        },
        methods: {
            sendMobileCode: function () {
                var self = this;

                Service.sendFindPasswordMobileCode(this.data.mobile, function (response) {
                    self.$alert(response.data.message);
                }, function (response) {
                    self.$alert('请查收短信验证码');

                    self.data.sent = true;
                    self.data.countdown = 60;

                    var timer = setInterval(function cycle() {
                        self.data.countdown--;

                        if (self.data.countdown <= 0) {
                            clearInterval(timer);
                            self.data.sent = false;
                        }

                    }, 1000);
                })
            },
            tryReset: function () {
                var self = this;

                Service.resetPassword(this.data.mobile, this.data.password, this.data.mobileCode, function (response) {
                    self.$alert(response.data.message);
                }, function (response) {
                    self.$alert('密码已重置, 请登录');

                    window.$router.replace({name: 'login'})
                })
            },
        }
    }
</script>