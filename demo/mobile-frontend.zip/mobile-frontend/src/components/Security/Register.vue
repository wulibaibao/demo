<style lang="less">
    @import (reference) '../../../static/css/base.less';
    .sign-module {
        .sign-pos {
            .m(67px 16px 22px);
        }
        input[type="tel"], input[type="password"], input[type="text"] {
            .db;
            .w(100%);
            .h(20px);
            line-height: 20px;
            font-size: 14px;
            .p(10px 0);
            color: @9;
            border: none;
            background: transparent;
            border-bottom: 1px solid @d
        }
        input[type=checkbox] {
            .db;
            .trx(-1px);
        }
        input[type="text"], input[type="password"] {
            .mt(23px)
        }
        .message-get {
            .flex;
            & > input[type=text] {
                flex:1;
            }
            & > a {
                .db;
                .w(103px);
                .h(35px);
                .mt(9px);
                .ml(10px);
                line-height: 35px;
                .tac;
                font-size: 14px;
                color: @6;
                border: 1px solid @6s;
                border-radius: 2px;

                &.disabled {
                    border-color: @6;
                }
            }
        }
        .check-name {
            .m(0 1px 0 3px);
            font-size: 10px;
            color: @6;
        }
        .user-http {
            .db;
            font-size: 10px;
            color: #269df1;
        }
        .go-sign {
            .db;
            .mt(94px);
            font-size: 14px;
            color: @9;
            .tac;
        }
        .flex-con {
            .flex;
            .mt(10px);
            align-items: center
        }
    }
</style>
<template>
    <form class="sign-module" autocomplete="on" onsubmit="return false;">
        <div class="sign-pos">
            <input type="tel" v-model="data.mobile" placeholder="请输入您的手机号">
            <input type="password" v-model="data.password" placeholder="请设置您的登录密码(6-32字符)">
            <div class="message-get">
                <input type="text" v-model="data.mobileCode" placeholder="请输入短信验证码">
                <a href="javascript:void(0);" @click="sendMobileCode" v-if="!data.sent">获取验证码</a>
                <a href="javascript:void(0);" class="disabled" v-else>{{data.countdown}}秒后重发</a>

            </div>
            <div class="flex-con">
                <input type="checkbox" id="checkbox" checked>
                <label for="checkbox"><h5 class="check-name">我已阅读并同意</h5></label>
                <a href="javascript:void(0);" v-link="{path:'/user-rule'}" class="user-http">《EBUY海淘用户协议》</a>
            </div>
        </div>
        <div class="ebuy-pay-button">
            <button class="ebuy-go-pay" @click="tryRegister">注册</button>
        </div>
        <a href="javascript:void(0);" class="go-sign" v-link="{name: 'login'}">已有账号？去登录</a>
        <div class="empty-bg"></div>
    </form>
</template>
<script>
    import Service from '../../utils/service'
    import User from '../../utils/user'

    module.exports = {
        data: function () {
            return {
                data: {
                    sent: false,
                    countdown: 60
                }
            }
        },
        methods: {
            tryRegister: function () {
                var self = this;
                var openId = localStorage.getItem('openId');

                Service.registerUser(this.data.mobile, this.data.password, this.data.mobileCode, openId, function (response) {
                    self.$alert(response.data.message);
                }, function (response) {
                    self.$alert('注册成功');

                    User.login({
                        access_token: response.data.data.access_token
                    });

                    window.$router.go({name: 'home'})
                })
            },
            sendMobileCode: function () {
                var self = this;

                Service.sendRegisterMobileCode(this.data.mobile, function (response) {
                    self.$alert(response.data.message);
                }, function (response) {
                    self.$alert('请查收短信验证码');

                    self.data.sent = true;
                    self.data.countdown = 60;

                    var timer = setInterval(function cycle() {
                        self.data.countdown--;

                        if (self.data.countdown <= 0) {
                            clearInterval(timer);
                            self.data.sent = false;
                        }

                    }, 1000);
                })
            }
        }
    }
</script>