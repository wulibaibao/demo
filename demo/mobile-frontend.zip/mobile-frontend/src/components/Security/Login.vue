<style lang="less">
    @import (reference) '../../../static/css/base.less';
    .login-overly {
        .abs;
        background: #fff;
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
    }

    .normal-head {
        .w(60px);
        .h(60px);
        .m(44px auto);
        background: url(../../../static/images/normal_head.png) center no-repeat;
        background-size: 60px;
    }

    .ebuy-tel {
        .flex;
        .p(0 20px);
        .mb(21px);
        .w(100%);
        & > span {
            .db;
            .w(20px);
            .h(20px);
            background: url(../../../static/images/login_phone.png) center no-repeat;
            background-size: 20px;
        }
        input[type="text"] {
            .db;
            flex: 1;
            .w(100%);
            .h(20px);
            line-height: 20px;
            .ml(8px);
            .p(10px 0);
            font-size: 14px;
            color: @9;
            border: none;
            background: transparent;
            border-bottom: 1px solid @d;
            box-sizing: border-box
        }
    }

    .ebuy-pwd {
        .flex;
        .p(0 20px);
        .mb(44px);
        input[type="password"] {
            .db;
            flex: 1;
            .w(100%);
            .h(20px);
            line-height: 20px;
            .ml(8px);
            .p(10px 0);
            font-size: 14px;
            color: @9;
            border: none;
            background: transparent;
            border-bottom: 1px solid @d
        }
        & > span {
            .db;
            .w(20px);
            .h(20px);
            background: url(../../../static/images/login_password.png) center no-repeat;
            background-size: 17px 20px;
        }
    }

    .start-sign {
        .db;
        .mt(94px);
        font-size: 14px;
        color: @9;
        .tac;
    }

    .forget-pwd {
        .db;
        float: right;
        .m(0 16px);
        font-size: 12px;
        color: @9
    }

</style>
<template>
    <div class="login-overly" v-if="accessToken"></div>
    <div class="login-container">
        <div class="normal-head"></div>
        <form class="login-module" autocomplete="on" onsubmit="return false;">
            <div class="ebuy-tel">
                <span></span>
                <input type="text" v-model="data.mobile" placeholder="请输入手机号或用户名">
            </div>
            <div class="ebuy-pwd">
                <span></span>
                <input type="password" v-model="data.password" placeholder="请输入您的登录密码">
            </div>
            <div class="ebuy-pay-button">
                <button class="ebuy-go-pay" @click="tryLogin">登录</button>
            </div>
        </form>
        <a href="javascript:void(0);" class="forget-pwd" v-link="{name: 'find_password'}">忘记密码？</a>
        <a href="javascript:void(0);" class="start-sign" v-link="{name: 'register'}">没有账号？去注册</a>
        <div class="empty-bg"></div>
    </div>
    {{accessToken}}
</template>

<script>
    import User from '../../utils/user'
    import Service from '../../utils/service'
    import {Indicator} from "mint-ui"

    document.title = '用户登录';

    module.exports = {
        data: function () {
            return {
                data: {},
                accessToken: null,
                openId: null,
                goBack: null
            }
        },
        ready: function () {
            let self = this;

            this.accessToken = this.$route.query.access_token;
            this.openId = this.$route.query.open_id;
            this.goBack = this.$route.query.return || '/';

            // 如果是点击后退按钮到达这个界面
            if (User.isLogged()) {
                window.history.go(-2);
                return;
            }

            // 如果是微信登录
            if (this.accessToken) {
                Indicator.open();

                User.login({
                    access_token: this.accessToken
                });

                // 验证一遍
                Service.userInfo(function () {
                    User.logout();
                }, function (response) {
                    window.location.href = self.goBack;
                });
            }

            // 如果微信登录但没有绑定过
            if (this.openId) {
                localStorage.setItem('openId', this.openId);
            }
        },
        methods: {
            tryLogin: function () {
                var self = this;

                Service.loginByUsername(this.data.mobile, this.data.password, this.openId, function (response) {
                    self.$alert(response.data.message)
                }, function (response) {
                    User.login({
                        access_token: response.data.data.access_token
                    });

                    window.location.href = self.goBack;
                })
            }
        }
    }
</script>