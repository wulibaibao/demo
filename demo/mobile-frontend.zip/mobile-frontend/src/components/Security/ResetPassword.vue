<style lang="less">
	@import (reference) '../../../static/css/base.less';
	.reset-pwd-module {
		.sign-pos {
			.m(67px 16px 34px);
		}
		input[type="password"] {
			.db;
			.w(100%);
			.h(20px);
			line-height: 20px;
			font-size: 14px;
			.p(10px 0);
			color: @9;
			border: none;
			background: transparent;
			border-bottom: 1px solid @d
		}
		input[type="password"] {
			.mt(23px)
		}
	}
</style>
<template>
	<form class="reset-pwd-module" autocomplete="off" onsubmit="return false;">
		<div class="sign-pos">
			<input type="password" v-model="data.ebuy_reset_pwd" placeholder="请设置您的登录密码(6-32字符)">
			<input type="password" v-model="data.ebuy_reset_true_pwd" placeholder="确认新密码">
		</div>
		<div class="ebuy-pay-button">
			<button class="ebuy-go-pay">确认重置</button>
		</div>
		<div class="empty-bg"></div>
	</form>
</template>
<script>
	module.exports = {
		data:function() {
			return {
				data: {
					ebuy_reset_pwd:'',
					ebuy_reset_true_pwd:''
				}
			}
		}
	}
</script>