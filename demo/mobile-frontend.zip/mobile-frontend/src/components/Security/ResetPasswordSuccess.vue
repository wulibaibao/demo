<style lang="less">
@import (reference) '../../../static/css/base.less';
	.ok-img {
		.w(60px);
		.h(60px);
		.m(4px auto 10px);
		.tac;
		.img;
	}
	.reset-ok {
		p {
			.mb(44px);
			font-size: 16px;
			color: @9;
			.tac;
		}
		a {
			.db;
			.w(100%);
			.h(35px);
			line-height: 35px;
			border-radius: 3px;
			.tac;
			font-size: 16px;
			color: @6s;
			letter-spacing: 1px;
			background: @f;
			border: 1px solid @6s;
			&:hover{
				color: @6s!important;
			}
			&:focus{
				color: @6s!important;
				opacity: .8
			}
		}
	}
</style>
<template>
	<div class="empty-bg"></div>
	<div class="reset-ok">	
		<div class="ok-img">
			<img src="../../../static/images/reset_ok.png">
		</div>
		<p>密码重置成功</p>
		<div class="ebuy-pay-button">
			<button class="ebuy-go-pay">登录</button>
		</div>
		<div class="ebuy-pay-button">
			<a href="javascript:void(0);">先逛逛</a>
		</div>			
	</div>
</template>