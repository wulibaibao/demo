<style lang="less">
    @import (reference) '../../../static/css/base.less';
    .ebuy-worth-buy {
        .pb(5px);
        .special-zone {
            .h(53px);
            background: #f1f1f1
        }
    }

    .worth-buy-img {
        .w(120px);
        .h(120px);
        .img;
        .m(0 auto);
    }

    .worth-buy-zone {
        .rel;
        float: left;
        .w(50%);
        background: @f;
        border-radius: 5px;
        border: 2px solid @e;
        box-sizing: border-box;
    }

    .worth-buy-position {
        .m(9px 9px 10px);
        p {
            font-size: 12px;
            color: @3;
            border-bottom: 1px solid @d;
            height: 38px;
            line-height: 18px;
            .lh;
        }
        h5 {
            .db;
            text-align: left;
            .pb(8px);
            color: @6s;
            span {
                font-family: 'PingFangSC-Regular';
                font-size: 14px;
            }
            .pf {
                font-family: 'PingFangSC-Regular';
                font-size: 18px;
            }
        }
    }

    .worth-buy-where {
        .abs;
        bottom: 4px;
        font-size: 10px;
        color: @6
    }

    .worth-buy-block {
        .mb(5px);
        clear: both;
        overflow: hidden;
    }
    .unfind {
        .mt(60px);
        .flexcenter;
        &>img {
            .db;
            .w(80%)
        }
    }
</style>
<template>
    <ebuy-search></ebuy-search>
    <ebuy-top></ebuy-top>
    <ebuy-gohome></ebuy-gohome>
    <ebuy-chat></ebuy-chat>
    <div class="ebuy-worth-buy">
        <ebuy-slide v-if="slide.length>0" :slide="slide" v-show="showSlide"></ebuy-slide>
        <div v-if="slide.length==0" class="special-zone"></div>
        <div class="worth-buy-sth">
            <div class="worth-buy-block">
                <a href="javascript:void(0);" class="worth-buy-zone"
                   v-link="{ name: 'goods-detail', params: { goodsId: item.real_id }}" v-for="item in goods">
                    <div class="worth-buy-position">
                        <div class="worth-buy-img">
                            <img :src="item.img | thumb">
                        </div>
                        <p>{{ item.name }}</p>
                        <h4 class="worth-buy-where" v-if="item.seller">商家：{{ item.seller.server_num }}</h4>
                        <h5>{{{item.sell_price | priceFormatter}}}
                        </h5>
                    </div>
                </a>
            </div>
        </div>
        <span class="unfind" v-show="not_results"><img :src="unfind"></span>
        <infinite-loading :distance="distance" :on-infinite="getGoods"></infinite-loading>
    </div>
</template>
<script>
    import EbuySlide from '../Common/Swiper.vue'
    import EbuySearch from '../Common/SearchBar.vue'
    import EbuyGohome from '../Common/ReturnhomeBubble.vue'
    import EbuyTop from '../Common/GotopBubble.vue'
    import EbuyChat from '../Common/ChatBubble.vue'
    import Service from '../../utils/service'
    import InfiniteLoading from '../InfiniteLoading.vue'

    module.exports = {
        components: {
            EbuySlide,
            EbuySearch,
            EbuyTop,
            EbuyGohome,
            EbuyChat,
            InfiniteLoading
        },
        data: function () {
            return {
                not_results: false,
                slide: [],
                goods: [],
                busy: false,
                showSlide: false,
                page: 1,
                unfind: require('static_file/images/unfind.png')
            }
        },
        ready: function () {
            if (this.$route.params.categoryId != null) {
                this.getSlide();
                this.showSlide = true;
            }
        },
        methods: {
            getGoods(){
                var me = this;
                if (me.$route.params.categoryId != null) {
                    Service.getGoodsListByCategoryId(me.$route.params.categoryId, me.page, null, function (response) {
                        console.log('getGoodsListByCategoryId');
                        me.goods = me.goods.concat(response.data.data);

                        if (me.page >= response.data.meta.pagination.total_pages) {
                            me.$broadcast('$InfiniteLoading:noMore');
                        } else if (response.data.data.length == 0) {
                            me.$broadcast('$InfiniteLoading:noResults');
                        }

                        me.$broadcast('$InfiniteLoading:loaded');
                    });
                } else if (me.$route.name == 'commend-goods-list') {
                    Service.getRecommendGoods(me.page, null, function (response) {
                        console.log('getRecommendGoods');
                        me.goods = me.goods.concat(response.data.data);

                        if (me.page >= response.data.meta.pagination.total_pages) {
                            me.$broadcast('$InfiniteLoading:noMore');
                        } else if (response.data.data.length == 0) {
                            me.$broadcast('$InfiniteLoading:noResults');
                        }

                        me.$broadcast('$InfiniteLoading:loaded');
                    });
                } else if (me.$route.params.sellerId != null) {
                    Service.getGoodsListBySellerId(me.$route.params.sellerId, me.page, null, function (response) {
                        console.log('getGoodsListBySellerId');
                        me.goods = me.goods.concat(response.data.data);

                        if (me.page >= response.data.meta.pagination.total_pages) {
                            me.$broadcast('$InfiniteLoading:noMore');
                        } else if (response.data.data.length == 0) {
                            me.$broadcast('$InfiniteLoading:noResults');
                        }

                        me.$broadcast('$InfiniteLoading:loaded');
                    });
                } else if (me.$route.params.query != null) {
                    Service.search(decodeURIComponent(me.$route.params.query), me.page, null, function (response) {
                        console.log('search');
                        me.goods = me.goods.concat(response.data.data);

                        me.not_results = !response.data.data.length;

                        if (me.page >= response.data.meta.pagination.total_pages) {
                            me.$broadcast('$InfiniteLoading:noMore');
                        } else if (response.data.data.length == 0) {
                            me.$broadcast('$InfiniteLoading:noResults');
                        }

                        me.$broadcast('$InfiniteLoading:loaded');
                    });
                } else {
                    Service.getGoodsList(me.page, null, function (response) {
                        console.log('getGoodsList');
                        me.goods = me.goods.concat(response.data.data);

                        if (me.page >= response.data.meta.pagination.total_pages) {
                            me.$broadcast('$InfiniteLoading:noMore');
                        } else if (response.data.data.length == 0) {
                            me.$broadcast('$InfiniteLoading:noResults');
                        }

                        me.$broadcast('$InfiniteLoading:loaded');
                    });
                }

                me.page++;

            },
            getSlide(){
                var me = this;
                Service.getAdvertisementsByCategory(me.$route.params.categoryId, null, function (response) {
                    me.slide = response.data.data;
                });
            }
        }
    }
</script>