<style lang="less">
    @import (reference) '../../../static/css/base.less';
    .ebuy-goods-introduce {
        background: @f;
        .con {
            .rel;
            .p(9px 18px 12px);
            h3 {
                .h(48px);
                line-height: 24px;
                font-size: 14px;
                color: @3;
                border-top: 1px solid @e;
                overflow: hidden;
                word-break: break-all;
            }
            .where {
                .db;
                font-size: 12px;
                color: @9
            }
            .save {
                .dbi;
                font-size: 12px;
                color: @3;
                & > span {
                    .dbi;
                    .w(20px);
                    .h(20px);
                    .ml(4px);
                    background: url(../../../static/images/goods_collect.png) right no-repeat;
                    background-size: 20px;
                    vertical-align: text-bottom
                }
            }
            .cons {
                .db;
                text-align: left;
                a {
                    .abs;
                    right: 18px;
                    top: 56px;
                    font-size: 12px;
                    color: #00A2FF;
                    text-decoration: underline;
                }
                h4 {
                    color: @6s;
                    span {
                        font-family: 'PingFangSC-Regular';
                        font-size: 14px;
                    }
                    .pf {
                        font-family: 'PingFangSC-Regular';
                        font-size: 18px;
                    }
                }
                p {
                    color: @9;
                    font-size: 12px;
                }
            }
        }
    }

    .ebuy-goods-sku {
        .m(10px 0);
        .p(0 0 20px 0);
        background: #fff;
    }

    .ebuy-goods-rules {
        .pos {
            .flex;
            .p(16px 36px 16px 18px);
            align-items: center;
            border-bottom: 1px solid @e;
        }
        h6 {
            .w(31px);
            font-size: 12px;
            .mr(20px);
            line-height: 14px;
            color: @6;
            word-break: break-all;
        }
        .rule-select, .goods-img-show {
            .tac;
            line-height: 15px;
        }
        .goods-img-show {
            flex: 1;
            ul {
                .w(245px);
                max-width: 245px;
                .h(47px);
                overflow: hidden;
                clear: both;
                li {
                    float: left;
                    .mr(14px);
                    .mb(14px);
                    a {
                        .rel;
                        .db;
                        .w(40px);
                        .h(40px);
                        line-height: 47px;
                        .img;
                        font-size: 10px;
                        color: @9;
                        border: 1px solid @9;
                        box-sizing: border-box;
                        background-color: #fff;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        &.disabled {
                            border: 1px dashed @9;
                            background: #f1f1f1;
                        }
                        &.selected {
                            border-color: @6s;
                            span {
                                .abs;
                                .w(10px);
                                .h(10px);
                                right: 2px;
                                bottom: 2px;
                                background: url(../../../static/images/goods_selected.png) center no-repeat;
                                background-size: 10px;
                            }
                        }
                    }
                    &.type_text a {
                        .w(100px);
                        min-width: 40px;
                        height: 40px;
                        line-height: 40px;
                        padding: 0 8px;
                    }
                }
            }
        }
        .rule-select {
            .abs;
            .db;
            right: 36px;
            .w(22px);
            .h(47px);
            background: url(../../../static/images/goods_show_down.png) center no-repeat;
            background-size: 22px 8px;
        }
        .up {
            background: url(../../../static/images/goods_show_up.png) center no-repeat;
            background-size: 22px 8px;
        }
    }

    .ebuy-goods-num {
        .p(16px 18px 0);

        .position {
            .flex;
            h6 {
                .w(31px);
                .mr(21px);
                line-height: 40px;
                font-size: 12px;
                color: @6;
                text-align: left;
            }
        }
        .change-num {
            flex: 4;
            font-size: 0;
            & > a {
                float: left;
                .w(40px);
                .h(40px);
                line-height: 38px;
                font-size: 24px;
                border: 1px solid @9;
                .tac;
                box-sizing: border-box;
                &.disabled {
                    border: 1px solid @9;
                    background: #f1f1f1;
                    box-sizing: border-box;
                }
            }
            input[type=number] {
                float: left;
                .w(49px);
                .h(40px);
                font-size: 16px;
                line-height: 23px;
                .p(10px 0);
                border-color: @9;
                border-width: 1px 0;
                border-radius: 0;
                border-top: 1px solid @9;
                border-bottom: 1px solid @9;
                border-left: none;
                border-right: none;
                box-sizing: border-box;
                .tac;
            }
        }
    }

    .ebuy-show-details {
        background: @f;
        .pb(50px);
        ul.nav {
            .flex;
            border-bottom: 1px solid @e;
            box-sizing: border-box;
            li {
                flex: 1;
                .tac;
                &:first-child {
                    border-right: 2px solid @e;
                }
                &.active {
                    & > a {
                        border-bottom: 2px solid @6s;
                        color: @6s;
                        -webkit-transition: border-bottom 500ms ease-in 0ms, color 250ms ease-in 0ms;
                        -moz-transition: border-bottom 500ms ease-in 0ms, color 250ms ease-in 0ms;
                        -ms-transition: border-bottom 500ms ease-in 0ms, color 250ms ease-in 0ms;
                        -o-transition: border-bottom 500ms ease-in 0ms, color 250ms ease-in 0ms;
                        transition: border-bottom 500ms ease-in 0ms, color 250ms ease-in 0ms;
                    }
                }
                a {
                    .dbi;
                    .h(37px);
                    line-height: 37px;
                    .p(0 10px 7px);
                    font-size: 14px;
                    color: @6;
                }
            }
        }
        .description {
            line-height: 22px;
            font-size: 12px;
            color: @6;
            .img;
            .p(16px 18px 30px);
            & > .odd {
                font-size: 14px;
                color: @3;
            }
            & > .even {
                font-size: 12px;
                color: @6;
            }
        }
    }

    .ebuy-goods-button {
        .fix;
        left: 0;
        bottom: 0;
        .w(100%);
        background: @f;
        border-top: 1px solid #e1e1e1;
        z-index: 686;
        .pos {
            .p(7px 9px);
            .flex;
            & > a {
                .db;
            }
        }
        .cart-icon {
            flex: 1;
            background: url(../../../static/images/buycar_active.png) center no-repeat;
            background-size: 30px;
            .mr(8px);
        }
        .saves, .car {
            .h(35px);
            line-height: 35px;
            .tac;
            font-size: 16px;
            font-weight: 700
        }
        .saves {
            flex: 1;
            color: @6s;
            background: url(../../../static/images/goods_collect.png) center no-repeat;
            background-size: 30px;
            border-right: 1px solid @e;
            letter-spacing: 4px;
            box-sizing: border-box;

        }
        .saved {
            background: url(../../../static/images/collect.png) center no-repeat;
            background-size: 30px;
        }
        .car {
            flex: 3;
            color: @f;
            background: @6s;
            letter-spacing: 1px;
            border-radius: 3px;
            &.disabled {
                background: @e;
                color: @9;
            }
        }
    }

    .spec-overflow {
        overflow: hidden !important;
    }

    .spec-visible {
        overflow: visible !important;
    }

    .auto {
        .h(auto) !important;
    }

    .all-saled {
        /*display: none;*/
        .abs;
        right: 20px;
        top: 20px;
        .w(50px);
        .h(50px);
        line-height: 50px;
        font-size: 16px;
        background: #dddddd;
        color: @6;
        z-index: 333;
        .tac;
        border-radius: 50%;
        letter-spacing: 1px;
        cursor: pointer
    }
</style>

<template>
    <span class="all-saled" v-show="soldOut">售罄</span>
    <ebuy-slide v-if="slide.length>0" :slide="slide"></ebuy-slide>
    <ebuy-gohome></ebuy-gohome>
    <ebuy-chat></ebuy-chat>
    <div class="ebuy-goods-introduce">
        <div class="con">
            <h3>{{ goods.name }}</h3>
            <span class="where" v-if="goods.seller">{{ goods.seller.server_num }}</span>
            <div class="cons">
                <a :href="goods.direct_link" target="_blank">直达链接</a>
                <p>参考价￥<span>{{ goods.market_price }}</span></p>
                <h4>
                    <template v-if="goods.sell_price > 0"> {{{goods.sell_price | priceFormatter}}}</template>
                    <template v-else><span>￥</span><span>-</span></template>
                </h4>
            </div>
        </div>
    </div>
    <div class="ebuy-goods-sku">
        <div class="ebuy-goods-rules" v-for="goods_specs in goods.specifications">
            <div class="pos" id="attr_{{$index + 1}}">
                <h6>{{ goods.specificationNames[$key] || $key }}</h6>
                <div class="goods-img-show">
                    <ul id="spec_{{$index + 1}}">
                        <li v-for="spec in goods_specs" class="{{spec.type=='image'?'type_image':'type_text'}}">
                            <a href="javascript:void(0);"
                               @click="clickAttr"
                               choose_key="{{$parent.$index + 1}}"
                               attr_value="{{spec.value}}"
                               attr_action="{{spec.type=='image'?'choose_image':'choose_text'}}"
                               attr_id="{{spec.id}}"
                               class="">
                                <img v-if="spec.type == 'image'" :src="spec.image|thumb 92 92">
                                <template v-else>
                                    {{ spec.value }}
                                </template>
                                <span></span>
                            </a>
                        </li>
                    </ul>
                </div>
                <a href="javascript:void(0);" @click="showAllSpec($index + 1, $event)" class="rule-select"
                   v-bind:class="{'none': showDropdown($key, goods_specs)}"></a>
            </div>
        </div>

        <div class="ebuy-goods-num">
            <div class="position">
                <h6>数量</h6>
                <div class="change-num">
                    <a href="javascript:void(0);" @click="reduceNum"
                       v-bind:class="{'disabled': data.goods_num <= 1}">-</a>
                    <input type="number" v-model="data.goods_num" readonly>
                    <a href="javascript:void(0);" @click="addNum">+</a>
                </div>
            </div>
        </div>
    </div>

    <div class="ebuy-show-details">
        <ul class="nav">
            <li v-bind:class="{'active': tabActive == 'tab-container1'}">
                <a href="javascript:void(0);" @click="toggleTab('tab-container1')">商品信息</a>
            </li>
            <li v-bind:class="{'active': tabActive == 'tab-container2'}">
                <a href="javascript:void(0);" @click="toggleTab('tab-container2')">海淘公约</a>
            </li>
        </ul>
        <div class="cont">
            <mt-tab-container style="page-tabbar-tab-container" :active.sync="tabActive">
                <mt-tab-container-item id="tab-container1">
                    <div class="description">
                        <template v-if="goods.content">
                            {{{ goods.content }}}
                        </template>
                        <template v-else>
                            暂无商品介绍
                        </template>
                    </div>
                </mt-tab-container-item>
                <mt-tab-container-item id="tab-container2">
                    <div class="description">
                        <p class="odd">1.平台申明</p>
                        <p class="even">
                            EBUY海淘作为海淘代下单平台不直接出售任何商品，网站上所有商品信息均来自于国外购物网站或品牌官方商城；您在EBUY海淘下单即代表委托EBUY海淘在国外购物网站或品牌官方商城代为购买相应商品，EBUY海淘可能会根据实际情况取消订单，并不承担除全额退款以外的任何责任。</p>
                        <p class="odd">2.不得转售</p>
                        <p class="even">根据我国相关法律规定，海淘商品必须符合自用原则，不得再次进行销售；因此EBUY海淘有权拒绝可能为代购商家的用户服务。</p>
                        <p class="odd">3.描述差异</p>
                        <p class="even">因厂家会在没有任何提前通知的情况下更改产品包装、产地或产品附件，EBUY海淘不能确保您收到的货物与本站图片、产地、附件说明完全一致。</p>
                        <p class="odd">4.中文标签</p>
                        <p class="even">所有海淘商品均由海外发出，因此商品可能未加贴中文标签。如果有使用上的疑问，可以通过搜索引擎或翻译软件了解相关信息，也可以向EBUY海淘客服求助。</p>
                        <p class="odd">5.质量标准</p>
                        <p class="even">
                            通过委托EBUY海淘商品销售对象为当地消费者，商品适用的品质、健康、表示等项目标准均符合购买国的生产及销售标准；可能与中华人民共和国大陆地区标准有所不同，所以在使用过程中由产生的危害或是损失及其他风险，将由用户个人承担。</p>
                        <p class="odd">6.清关要求</p>
                        <p class="even">
                            委托EBUY海淘购买境外商品时，请您提供真实的收货人姓名，并配合提供海关清关所需的身份证信息进行个人物品入境申报，如因您未提供个人信息或提供的个人信息不准确等原因造成无法完成海关清关的，由此造成的损失等由您个人承担，EBUY海淘不承担任何责任。</p>
                        <p class="odd">7.收货时间</p>
                        <p class="even">
                            所有海淘商品均由海外发出，由于涉及海关清关问题，EBUY海淘不承诺具体到货时间，一般自商品从海外仓库发货后15-20天可以收到包裹；EBUY海淘不承担任何因海关清关导致的到手时间过长造成的任何损失。</p>
                        <p class="odd">8.商品售后</p>
                        <p class="even">鉴于跨境交易在出入境、海关申报纳税、物流、外汇等方面的复杂性，您委托EBUY海淘购买的境外商品不支持7天无理由退换货；
                            商品错发及质量问题除外（需提供质量技术监督部门检测报告；色差
                            、线头、气味、喜好、太小、细节瑕疵均不属于质量问题）。</p>
                        <p class="odd">9.通关关税</p>
                        <p class="even">依法纳税是每个公民的义务，海淘商品在清关过程中，商品会接受抽检，被抽检到并且符合海关纳税规定的商品需要缴纳相应的关税，缴纳关税后包裹才会放行。</p>
                        <p class="odd">10.用户承诺</p>
                        <p class="even">
                            本人承诺所购买商品是个人合理自用，现委托EBUY海淘代理申报，代缴税款等通关事宜；本人承认遵守《海关法》和中华人民共和国相关法律法规，保证所提供的身份信息和收货信息真实有效，无侵犯他人权益的行为，以上委托关系如实填写，本人愿意接受还管、检验检疫机构及其他监管部门的监管，并承担相应法律责任。</p>
                    </div>
                </mt-tab-container-item>
            </mt-tab-container>
        </div>
        <div class="ebuy-goods-button">
            <div class="pos">
                <a href="javascript:void(0);" v-bind:class="{ 'saved': isFav }" class="saves"
                   v-on:click="favGoods()"></a>
                <a v-link="{name:'cart'}" class="cart-icon"></a>
                <a href="javascript:void(0);" class="car" @click="joinCart"
                   v-bind:class="{'disabled': !data.sku || !goods.store_nums}">加入购物车</a>
            </div>
        </div>
    </div>
</template>

<script>
    import Vue from "vue"
    import User from '../../utils/user'
    import EbuySlide from '../Common/GoodsSwiper.vue'
    import EbuyGohome from '../Common/ReturnhomeBubble.vue'
    import EbuyChat from '../Common/ChatBubble.vue'
    import Service from '../../utils/service'
    import {Indicator} from "mint-ui"
    import {TabContainer, TabContainerItem} from 'mint-ui'
    import wx from 'weixin-js-sdk'

    var VueResource = require('vue-resource');
    Vue.use(VueResource);

    Vue.component(TabContainer.name, TabContainer);
    Vue.component(TabContainerItem.name, TabContainerItem);

    module.exports = {
        components: {
            EbuySlide,
            EbuyGohome,
            EbuyChat
        },
        data: function () {
            return {
                tabActive: 'tab-container1',
                slide: [],  // 轮播图
                curGoodsId: this.$route.params.goodsId, // 当前商品id
                goods: { // 当前商品数据 ====》 给出一些数据结构,避免出现错误警告信息
                    sell_price: 0
                },
                data: {
                    goods_num: '1',
                    sku: '',
                },
                soldOut: false,
                isFav: false,
                productId: 0,
                attr1: "",
                attr2: "",
                attr3: "",
                originalAttr1: "",
                productStockInfo: [], // 商品库存信息
                attr1CanClick: [], //  规格是否可点击
                attr2CanClick: [],
                attr3CanClick: [],
                attr1Info: [],
                attr2Info: [],
                attr3Info: [],
                hasAttr1: false,
                hasAttr2: false,
                hasAttr3: false
            }
        },
        ready: function () {
            this.getGoodsInfo();
        },
        methods: {
            showDropdown: function (key, goods_specs) {
                if (key == 'color' && goods_specs.length <= 4) {
                    return true;
                }

                return goods_specs.length <= 2;
            },
            joinCart: function () {
                if (!this.data.sku || !this.goods.store_nums) {
                    return;
                }

                let self = this;

                var parameters = {};
                parameters.sku = this.data.sku;
                parameters.productId = this.goods.id
                parameters.num = this.data.goods_num;
                parameters.selected = true;

                Service.addCart(parameters, function (response) {
                    self.$alert(response.data.message)
                }, function (response) {
                    self.$alert('已加入购物车');
                });
            },
            addNum: function () {
                this.data.goods_num++;
            },
            reduceNum: function () {
                if (this.data.goods_num >= 2) {
                    this.data.goods_num--;
                }
            },
            // 获取商品信息
            getGoodsInfo() {
                var self = this;
                var params = location.href.split('?')[1];

                Service.getGoodsInfo(self.curGoodsId, null, function (response) {
                    self.goods = response.data.data;
                    self.settingDefaults();
                    self.defaultsClick();

                    if (User.isLogged()) {
                        self.getFavStatus();
                    }
                },params)
            },
            // 配置商品信息
            settingDefaults() {

                document.title = this.goods.name;

                // 获取对应sku
                var curSku = this.goods.stock[this.curGoodsId].sku;
                var curSpecIds = curSku.split('_');

                curSpecIds.shift();

                //noinspection JSDuplicatedDeclaration
                for (var key in this.goods.stock) {
                    //noinspection JSUnfilteredForInLoop
                    this.productStockInfo[this.goods.stock[key].sku] = this.goods.stock[key].store_nums > 0 ? 1 : 0;
                }

                this.hasAttr1 = curSpecIds[0] != null || false;
                this.hasAttr2 = curSpecIds[1] != null || false;
                this.hasAttr3 = curSpecIds[2] != null || false;

                this.attr1 = curSpecIds[0] || '';
                this.attr2 = curSpecIds[1] || '';
                this.attr3 = curSpecIds[2] || '';
                this.originalAttr1 = this.attr1;

                this.attr1Info = [];
                this.attr2Info = [];
                this.attr3Info = [];

                var counter = 0;
                //noinspection JSDuplicatedDeclaration
                for (var key in this.goods.specifications) {
                    //noinspection JSUnfilteredForInLoop
                    for (var key2 in this.goods.specifications[key]) {

                        //noinspection JSUnfilteredForInLoop
                        let stock = this.goods.specifications[key][key2];

                        if (this.attr1 == stock.id) { // 当前幻灯片
                            this.slide = stock.pictures;
                        }

                        if (counter == 0) {
                            this.attr1Info.push(stock.id);
                        } else if (counter == 1) {
                            this.attr2Info.push(stock.id);
                        } else if (counter == 2) {
                            this.attr3Info.push(stock.id);
                        }
                    }

                    counter++;
                }
                if (this.isWechat()) {
                    this.initWeChatShare(); // 微信分享
                }
            },
            defaultsClick: function () {
                // 去点击
                var clickAttr1 = this.attr1;
                var clickAttr2 = this.attr2;
                var clickAttr3 = this.attr3;

                this.attr1 = '';
                this.attr2 = '';
                this.attr3 = '';

                setTimeout(function () {
                    console.log("clickAttr1:" + clickAttr1);
                    console.log("clickAttr2:" + clickAttr2);
                    console.log("clickAttr3:" + clickAttr3);

                    if (clickAttr1) {
                        $('#attr_1').find('[attr_id="' + clickAttr1 + '"]').trigger('click');
                    }

                    if (clickAttr2) {
                        $('#attr_2').find('[attr_id="' + clickAttr2 + '"]').trigger('click');
                    }

                    if (clickAttr3) {
                        $('#attr_3').find('[attr_id="' + clickAttr3 + '"]').trigger('click');
                    }
                }, 100); // 还没加载完呢..
            },
            favGoods() {
                $('.saves').toggleClass('saved');
                var me = this;
                if (me.isFav) {
                    // 取消收藏操作
                    Service.unFavGoods(me.goods.id, null, function (response) {
                        me.isFav = false;
                    });
                } else {
                    // 添加收藏操作
                    Service.favGoods(me.goods.id, null, function (response) {
                        me.isFav = true;
                    });
                }
            },
            getFavStatus() {
                var me = this;
                Service.getFavStatus(me.goods.id, null, function (response) {
                    if (response.data.data.is_fav == true) {
                        me.isFav = true;
                    } else {
                        me.isFav = false;
                    }
                });
            },
            // 显示隐藏的规格
            showAllSpec(key, e) {
                $('#spec_' + key).toggleClass('auto');
                $(e.target).toggleClass('up');
            },
            // 选择规格
            chooseAttr(key, value) {
                var attr1Array = this.attr1Info;
                var attr2Array = this.attr2Info;
                var attr3Array = this.attr3Info;

                this.data.sku = '';

                console.log('=============chooseAttr()===============')

                if (key == 1) {
                    this.attr1 = value;
                }
                if (key == 2) {
                    this.attr2 = value;
                }
                if (key == 3) {
                    this.attr3 = value;
                }
                if (value) {
                    if (this.attr1) {
                        attr1Array = new Array(this.attr1);
                    }
                    if (this.attr2) {
                        attr2Array = new Array(this.attr2);
                    }
                    if (this.attr3) {
                        attr3Array = new Array(this.attr3);
                    }

                    if (this.isAllClick()) {
                        console.log('click all!');

                        if (this.attr3) {
                            this.checkSkuStock(new Array(this.attr1), new Array(this.attr2), this.attr3Info);
                            this.checkSkuStock(this.attr1Info, new Array(this.attr2), new Array(this.attr3));
                            this.checkSkuStock(new Array(this.attr1), this.attr2Info, new Array(this.attr3));
                        } else {
                            if (this.attr2) {
                                this.checkSkuStock(new Array(this.attr1), this.attr2Info, this.attr3Info);
                                this.checkSkuStock(this.attr1Info, new Array(this.attr2), this.attr3Info);
                            } else {
                                this.checkSkuStock(this.attr1Info, this.attr2Info, this.attr3Info);
                            }
                        }
                    } else {
                        this.checkSkuStock(attr1Array, attr2Array, attr3Array);
                    }
                } else {
                    if (key == 1) {
                        $('#attr_2').find('[attr_id]').removeClass('disabled');
                        $('#attr_3').find('[attr_id]').removeClass('disabled');
                    }
                    if (key == 2) {
                        $('#attr_1').find('[attr_id]').removeClass('disabled');
                        $('#attr_3').find('[attr_id]').removeClass('disabled');
                    }
                    if (key == 3) {
                        $('#attr_1').find('[attr_id]').removeClass('disabled');
                        $('#attr_2').find('[attr_id]').removeClass('disabled');
                    }
                    if (this.attr1) {
                        attr1Array = new Array(this.attr1);
                    }
                    if (this.attr2) {
                        attr2Array = new Array(this.attr2);
                    }
                    if (this.attr3) {
                        attr3Array = new Array(this.attr3);
                    }
                    if (this.attr1 || this.attr2 || this.attr3) {
                        this.checkSkuStock(attr1Array, attr2Array, attr3Array);
                    } else {
                        $('#attr_1').find('[attr_id]').removeClass('disabled');
                        $('#attr_2').find('[attr_id]').removeClass('disabled');
                        $('#attr_3').find('[attr_id]').removeClass('disabled');
                    }
                }
                if (this.isAllClick(this.attr1, this.attr2, this.attr3)) {
                    this.checkStock(this.attr1, this.attr2, this.attr3);
                }
            },
            // 检查sku库存
            checkSkuStock: function (attr1Array, attr2Array, attr3Array) {
                console.log('=================checkSkuStock()==================');
                console.log(attr1Array);
                console.log(attr2Array);
                console.log(attr3Array);

                var checkAttrId = '';
                if (this.hasAttr1) {
                    for (var key1 in attr1Array) {
                        var checkAttr1 = attr1Array[key1];
                        if (this.hasAttr2) {
                            for (var key2 in attr2Array) {
                                var checkAttr2 = attr2Array[key2];
                                if (this.hasAttr3) {
                                    for (var key3 in attr3Array) {
                                        var checkAttr3 = attr3Array[key3];
                                        checkAttrId = this.goods.id + '_' + checkAttr1 + '_' + checkAttr2 + '_' + checkAttr3;
                                        this.checkSkuStockRes(checkAttrId, checkAttr1, checkAttr2, checkAttr3);
                                    }
                                } else {
                                    checkAttrId = this.goods.id + '_' + checkAttr1 + '_' + checkAttr2;
                                    this.checkSkuStockRes(checkAttrId, checkAttr1, checkAttr2, false);
                                }
                            }
                        } else {
                            checkAttrId = this.goods.id + '_' + checkAttr1;
                            this.checkSkuStockRes(checkAttrId, checkAttr1, false, false);
                        }
                    }
                }

                console.log('this.attr1CanClick:');
                console.log(this.attr1CanClick);
                console.log('this.attr2CanClick:');
                console.log(this.attr2CanClick);
                console.log('this.attr3CanClick:');
                console.log(this.attr3CanClick);

                if (this.attr1CanClick) {
                    for (var attrIdKey in this.attr1CanClick) {
                        attrIdKey = attrIdKey.replace('key', '');
                        $('#attr_1').find('[attr_id="' + attrIdKey + '"]').removeClass('disabled');
                    }
                }
                if (this.attr2CanClick) {
                    for (var attrIdKey in this.attr2CanClick) {
                        attrIdKey = attrIdKey.replace('key', '');
                        $('#attr_2').find('[attr_id="' + attrIdKey + '"]').removeClass('disabled');
                    }
                }
                if (this.attr3CanClick) {
                    for (var attrIdKey in this.attr3CanClick) {
                        attrIdKey = attrIdKey.replace('key', '');
                        $('#attr_3').find('[attr_id="' + attrIdKey + '"]').removeClass('disabled');
                    }
                }

                this.attr1CanClick = [];
                this.attr2CanClick = [];
                this.attr3CanClick = [];
            },
            // 检查库存
            checkSkuStockRes: function (checkAttrId, checkAttr1, checkAttr2, checkAttr3) {
                var hasStock = false;

                if (this.productStockInfo[checkAttrId]) {
                    this.soldOut = false;
                    hasStock = true;
                } else {
                    this.soldOut = true;
                }
//                console.log('====================checkSkuStockRes()======================');
//                console.log('checkAttrId:' + checkAttrId);
//                console.log('checkAttr1:' + checkAttr1);
//                console.log('checkAttr2:' + checkAttr2);
//                console.log('checkAttr3:' + checkAttr3);
//                console.log('hasStock:' + hasStock);

                if (this.hasAttr1) {
                    var checkAttr1Key = 'key' + checkAttr1;
                    if (!hasStock && this.attr1 != checkAttr1 && !this.attr1CanClick.checkAttr1Key) {
                        $('#attr_1').find('[attr_id="' + checkAttr1 + '"]').attr('class', 'disabled');
                    } else {
                        this.attr1CanClick[checkAttr1Key] = 1;
                    }
                }
                if (this.hasAttr2) {
                    var checkAttr2Key = 'key' + checkAttr2;
                    if (!hasStock && this.attr2 != checkAttr2 && !this.attr2CanClick.checkAttr2Key) {
                        $('#attr_2').find('[attr_id="' + checkAttr2 + '"]').attr('class', 'disabled');
                    } else {
                        this.attr2CanClick[checkAttr2Key] = 1;
                    }
                }
                if (this.hasAttr3) {
                    var checkAttr3Key = 'key' + checkAttr3;
                    if (!hasStock && this.attr3 != checkAttr3 && !this.attr3CanClick.checkAttr3Key) {
                        $('#attr_3').find('[attr_id="' + checkAttr3 + '"]').attr('class', 'disabled');
                    } else {
                        this.attr3CanClick[checkAttr3Key] = 1;
                    }
                }
            },
            // 判断是否选完所有规格
            isAllClick() {
                if (this.attr1 && this.attr2 && this.attr3) {
                    return true;
                }
                if (this.attr1 && this.attr2 && !this.hasAttr3) {
                    return true;
                }
                if (this.attr1 && !this.hasAttr2 && !this.hasAttr3) {
                    return true;
                }
            },
            // 所有规格选中后执行的事件
            checkStock(attr1, attr2, attr3) {
                var self = this;
                console.log('=================checkStock()==================');

                self.setSlide(attr1); // 幻灯片

                Vue.http({
                    url: window.$backendUrl + '/product/check',
                    data: {
                        attr1: attr1,
                        attr2: attr2,
                        attr3: attr3,
                        productId: this.goods.id
                    },
                    method: 'POST',
                    emulateJSON: true,
                    beforeSend: function (request) {
                        Indicator.open({text: '检查商品库存', spinnerType: 'snake'});
                    }
                }).then(function (response) {
                    Indicator.close();

                    self.data.sku = response.data.data.sku;
                    self.goods.sell_price = response.data.data.sell_price;
                    self.goods.store_nums = response.data.data.store_nums;

                    if (response.data.data.store_nums <= 0) {
                        self.soldOut = true;
                        self.$alert('所选商品规格无库存');
                    } else {
                        self.soldOut = false;
//                        self.$alert('同步国外商家价格完成');
                    }
                }, function (response) {
                    Indicator.close();
                });
            },
            // 设置幻灯片
            setSlide: function (colorId) {
                console.log('================setSlide()================');

                //noinspection JSDuplicatedDeclaration
                for (var key in this.goods.specifications) {
                    //noinspection JSUnfilteredForInLoop
                    for (var key2 in this.goods.specifications[key]) {

                        //noinspection JSUnfilteredForInLoop
                        let stock = this.goods.specifications[key][key2];

                        if (colorId == stock.id) {
                            this.slide = stock.pictures;
                        }
                    }
                }
            },
            // 规格点击事件入口
            clickAttr(e){
                let a = e.target;
                let self = a.tagName == 'A' ? $(a) : $(a).parent('a');
                let attrKey = self.attr('choose_key');
                let attrId = self.attr('attr_id');
                let attrText = self.attr('attr_value');
                let attrClass = self.attr('class');
                let attrAction = self.attr('attr_action');

                if (attrClass == 'disabled') {
                    return false;
                }

                if (attrClass == 'selected') {
                    attrId = '';
                    self.attr('class', '');
                }

                if (attrClass == '') {
                    $('#attr_' + attrKey).find('.selected').removeClass('selected');
                    self.attr('class', 'selected');
                }

                console.log('=======clickAttr()=======');
                console.log('attrKey: ' + attrKey);
                console.log('attrId: ' + attrId);

                this.chooseAttr(attrKey, attrId);
            },
            toggleTab: function (index) {
                this.tabActive = index;
            },
            isWechat: function () {
                var me = this,
                        wac = window.navigator.userAgent.toLowerCase();
                if (wac.match(/MicroMessenger/i) == 'micromessenger') {
                    return true;
                } else {
                    return false;
                }
            },
            initWeChatShare: function () {
                var self = this;
                var curUrl = location.href.split('#')[0];

                Service.getWechatJsConfig(encodeURIComponent(curUrl), null, function (res) {

                    var config = res.data.data;

                    wx.config({
                        debug: false,
                        appId: config.appId,
                        timestamp: config.timestamp,
                        nonceStr: config.nonceStr,
                        signature: config.signature,
                        jsApiList: config.jsApiList
                    });

                    wx.ready(function () {

                        wx.onMenuShareTimeline({
                            title: self.goods.name, // 分享标题
                            link: curUrl, // 分享链接
                            imgUrl: self.slide[0].url, // 分享图标
                            success: function () {
                                // 用户确认分享后执行的回调函数
                                self.$alert("分享成功 :)");
                            },
                            cancel: function () {
                                // 用户取消分享后执行的回调函数
                                self.$alert("为啥取消了 :(");
                            }
                        });

                        wx.onMenuShareAppMessage({
                            title: self.goods.name, // 分享标题
                            desc: '我在EBUY海淘看到一件不错的商品，快来剁手～', // 分享描述
                            link: curUrl, // 分享链接
                            imgUrl: self.slide[0].url, // 分享图标
                            type: '', // 分享类型,music、video或link，不填默认为link
                            dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
                            success: function () {
                                // 用户确认分享后执行的回调函数
                                self.$alert("分享成功 :)");
                            },
                            cancel: function () {
                                // 用户取消分享后执行的回调函数
                                self.$alert("为啥取消了 :(");
                            }
                        });

                        wx.onMenuShareQQ({
                            title: self.goods.name, // 分享标题
                            desc: '我在EBUY海淘看到一件不错的商品，快来剁手～', // 分享描述
                            link: curUrl, // 分享链接
                            imgUrl: self.slide[0].url, // 分享图标
                            success: function () {
                                // 用户确认分享后执行的回调函数
                                self.$alert("分享成功 :)");
                            },
                            cancel: function () {
                                // 用户取消分享后执行的回调函数
                                self.$alert("为啥取消了 :(");
                            }
                        });

                        wx.onMenuShareQZone({
                            title: self.goods.name, // 分享标题
                            desc: '我在EBUY海淘看到一件不错的商品，快来剁手～', // 分享描述
                            link: curUrl, // 分享链接
                            imgUrl: self.slide[0].url, // 分享图标
                            success: function () {
                                // 用户确认分享后执行的回调函数
                                self.$alert("分享成功 :)");
                            },
                            cancel: function () {
                                // 用户取消分享后执行的回调函数
                                self.$alert("为啥取消了 :(");
                            }
                        });

                    });

                    wx.error(function (res) {
                        self.$alert(res.data);
                    });


                });

            }
        }
    }
</script>