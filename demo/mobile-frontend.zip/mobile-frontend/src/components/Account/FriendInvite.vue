<style lang="less">
    @import (reference) '../../../static/css/base.less';

    .invite-bg {
        .abs;
        left: 0;
        top: 0;
        .w(100%);
        .h(100%);
        background: url(../../../static/images/invite_bg.png) left top no-repeat;
        background-size: cover;
        z-index: 11;
    }

    .invite-cont {
        .rel;
        z-index: 111;
    }

    .invite-tit {
        .w(68%);
        .p(74px 0 100px);
        .m(0 auto);
        background: url(../../../static/images/invite_tit.png) center no-repeat;
        background-size: contain;
    }

    .invite-intro {
        .w(80%);
        .h(179px);
        .m(0 auto 22px);
        background: url(../../../static/images/invite_intro.png) center no-repeat;
        background-size: contain;
    }

    .draw-gift {
        .db;
        .w(75%);
        .m(0 auto 28px);
        .hl(33px);
        color: @f;
        font-size: 16px;
        font-weight: 800;
        background-color: #FF537B;
        .tac;
        border-radius: 5px;
    }

    .invite-rule {
        .w(75%);
        .m(0 auto);
        text-align: left;
        h3 {
            .mb(18px);
        }
        h3, h4 {
            font-size: 12px;
            color: #0435AD;
        }
        h4 {
            line-height: 16px;
            .mb(12px);
        }
    }

    .floatlayer-pc {
        .fix;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        z-index: 11000;
        background: rgba(0, 0, 0, .5);
        .flexcenter;
        .ebuy-pc-tip {
            .rel;
            .w(80%);
            background: @f;
            border-radius: 2px;
            .tac;
            p {
                font-family: 'PingFangSC-Regular';
                font-size: 16px;
                line-height: 24px;
                .p(59px 30px 52px);
                font-weight: 700;
                color: @3;
            }
            .pc-but {
                .db;
                .w(62%);
                .m(0 auto 30px);
                .h(38px);
                line-height: 38px;
                font-size: 16px;
                color: @f;
                background-color: #D90707;
                font-weight: 800;
                border-radius: 3px;
            }
            .pc-exit {
                .abs;
                right: 0;
                top: 0;
                .w(24px);
                .h(24px);
                background: url(../../../static/images/pc_exit.png) center no-repeat;
                background-size: 16px;
            }
        }
    }

    .floatlayer-share {
        .fix;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        z-index: 11000;
        background: rgba(0, 0, 0, .9);
        .ebuy-share-tip {
            .rel;
            .w(100%);
            .tac;
            .invite-air {
                .abs;
                top: 85px;
                right: 5%;
                .w(187px);
                .h(118px);
                .m(0 auto);
                background: url(../../../static/images/invite_air.png) center no-repeat;
                background-size: contain;
            }
            h3 {
                .abs;
                top: 225px;
                right: 21%;
                font-size: 20px;
                color: @f;
            }
        }
    }

    @media only screen and (max-width: 320px) {
        .invite-bg {
            .h(660px) !important;
        }
    }

    @media only screen and (max-width: 384px) and (min-width: 384px) {
        .invite-bg {
            .h(683px) !important
        }
    }

    @media only screen and (max-width: 360px) and (min-width: 360px) {
        .invite-tit {
            .p(74px 0 85px)
        }

        .invite-bg {
            .h(640px) !important
        }
    }

    @media screen and (min-width: 414px) {
        .invite-tit {
            .p(74px 0 130px)
        }
    }

    @media screen and (max-width: 412px) and (min-width: 412px) {
        .invite-tit {
            .p(74px 0 115px)
        }

        .invite-bg {
            .h(732px) !important
        }
    }
</style>
<template>
    <img style="display:none" src="../../../static/images/logo.png">
    <div class="invite-bg"></div>
    <div class="invite-cont">
        <div class="invite-tit"></div>
        <div class="invite-intro"></div>
        <a href="javascript:void(0);" class="draw-gift" @click="showTip">立即分享</a>
        <div class="invite-rule">
            <h3>-邀请规则-</h3>
            <h4>1.好友注册成功后双方均获得10元运费券（2016年12月1日之前奖励加倍：20元）；</h4>
            <h4>2.邀请次数不限，每邀请成功一次即可获得一次运费劵；</h4>
            <h4>3.获得运费劵下单结算时即可使用，可抵同等金额的运费；</h4>
            <h4>4.邀请规则最终解释权归EBUY海淘所有。</h4>
        </div>
    </div>
    <div class="floatlayer-pc none">
        <div class="ebuy-pc-tip">
            <p>请使用浏览器自带分享功能或直接复制网址链接发送给好友！</p>
            <a href="javascript:void(0);" class="pc-but" @click="shareTip">确定</a>
            <a href="javascript:void(0);" class="pc-exit" @click="hideTip"></a>
        </div>
    </div>
    <div class="floatlayer-share none">
        <div class="ebuy-share-tip">
            <p class="invite-air"></p>
            <h3>使用微信直接分享给好友</h3>
        </div>
    </div>
</template>

<script>

    import Service from '../../utils/service';
    import wx from 'weixin-js-sdk';

    module.exports = {
        data: function () {
            return {
                user: {},
                url: ''
            }
        },
        ready: function () {
            document.title = '免代购费，EBUY海淘带你玩转黑色星期五！送你20元运费，还不来领？';
            // [1]判断是否登录
            this.isLogin();
            var _height = document.documentElement.clientHeight;
            jQuery('.invite-bg').css('height', _height);
        },
        methods: {
            getPar: function (par) {
                //获取当前URL
                var local_url = document.location.href;
                //获取要取得的get参数位置
                var get = local_url.indexOf(par + "=");
                if (get == -1) {
                    return false;
                }
                //截取字符串
                var get_par = local_url.slice(par.length + get + 1);
                //判断截取后的字符串是否还有其他get参数
                var nextPar = get_par.indexOf("&");
                if (nextPar != -1) {
                    get_par = get_par.slice(0, nextPar);
                }
                return get_par;
            },
            isLogin: function () {
                if (localStorage.getItem('access_token') != null) {
                    // [2]设置邀请码
                    this.setInviteCode();
                } else {
                    console.log(this.getPar('invite_code'));
                    localStorage.setItem('invitedCode', this.getPar('invite_code'));

                    if (this.getPar('invite_code') !== 'null' && this.getPar('invite_code') !== '' && this.getPar('invite_code') !== false) {
                        var exp = new Date();
                        exp.setTime(exp.getTime() + 7 * 24 * 60 * 60 * 1000);
                        document.cookie = "cps_source=" + this.getPar('invite_code') + ";expires=" + exp.toGMTString() + ";path=/";
                    }
                   
                    window.$router.go({name: 'account_invited'});
               }
            },
            setInviteCode: function () {

                var self = this;
                var inviteCode = localStorage.getItem('inviteCode');

                if (inviteCode == null) {

                    Service.userInfo(function (response) {
                        self.$alert(response.data);
                    }, function (response) {
                        self.user = response.data.data;
                        // [3]保存用户邀请码到本地
                        localStorage.setItem('inviteCode', self.user.invite_code);
                        inviteCode = self.user.invite_code;

                        self.url = '?invite_code=' + inviteCode;

                        // [4]判断是否是微信内
                        if (self.isWechat()) {
                            // [5]初始化微信分享组件
                            self.initWeChatShare();
                        } else {
                            // [6]设置带邀请码的邀请链接
                            window.history.replaceState({}, 0, self.url);
                        }
                    });

                } else {

                    self.url = '?invite_code=' + inviteCode;
                    if (self.isWechat()) {
                        self.initWeChatShare();
                    } else {
                        // [6]设置带邀请码的邀请链接
                        window.history.replaceState({}, 0, self.url);
                    }

                }


            },
            isWechat: function () {
                var me = this,
                        wac = window.navigator.userAgent.toLowerCase();
                if (wac.match(/MicroMessenger/i) == 'micromessenger') {
                    return true;
                } else {
                    return false;
                }
            },
            showTip: function () {
                if (this.isWechat() == true) {
                    jQuery('.floatlayer-share').removeClass('none');
                }
                else {
                    jQuery('.floatlayer-pc').removeClass('none');
                }
            },
            shareTip: function () {
                jQuery('.floatlayer-pc').addClass('none');
            },
            hideTip: function () {
                jQuery('.floatlayer-pc').addClass('none');
            },
            initWeChatShare: function () {  // 初始化微信分享组件

                var self = this;
                var curUrl = location.href.split('#')[0];
                var times = 0; //统计微信接口调用错误的次数

                function handleWx() {

                    Service.getWechatJsConfig(encodeURIComponent(curUrl), null, function (res) {

                        var config = res.data.data;

                        wx.config({
                            debug: false,
                            appId: config.appId,
                            timestamp: config.timestamp,
                            nonceStr: config.nonceStr,
                            signature: config.signature,
                            jsApiList: config.jsApiList
                        });

                        wx.error(function (res) {
                            console.log(res);
                        });
                        wx.ready(function () {

                            // [6]设置带邀请码的邀请链接
                            window.history.replaceState({}, 0, self.url);    // 初始化完毕之后再去改变url，否则会导致签名错误！

                            // [7]获取分享链接
                            curUrl = location.href.split('#')[0];

                            console.log("初始化微信分享成功");

                            wx.onMenuShareTimeline({
                                title: '免代购费，EBUY海淘带你玩转黑色星期五！送你20元运费，还不来领？', // 分享标题
                                link: curUrl, // 分享链接
                                imgUrl: 'http://m.laidoulaile.com/static/images/logo.png', // 分享图标
                                success: function () {
                                    // 用户确认分享后执行的回调函数
                                    self.$alert("分享成功 :)");
                                },
                                cancel: function () {
                                    // 用户取消分享后执行的回调函数
                                    self.$alert("为啥取消了 :(");
                                }
                            });

                            wx.onMenuShareAppMessage({
                                title: '免代购费，EBUY海淘带你玩转黑色星期五!', // 分享标题
                                desc: '送你20元运费，还不来领？', // 分享描述
                                link: curUrl, // 分享链接
                                imgUrl: 'http://m.laidoulaile.com/static/images/logo.png', // 分享图标
                                type: '', // 分享类型,music、video或link，不填默认为link
                                dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
                                success: function () {
                                    // 用户确认分享后执行的回调函数
                                    self.$alert("分享成功 :)");
                                },
                                cancel: function () {
                                    // 用户取消分享后执行的回调函数
                                    self.$alert("为啥取消了 :(");
                                }
                            });

                            wx.onMenuShareQQ({
                                title: '免代购费，EBUY海淘带你玩转黑色星期五!', // 分享标题
                                desc: '送你20元运费，还不来领？', // 分享描述
                                link: curUrl, // 分享链接
                                imgUrl: 'http://m.laidoulaile.com/static/images/logo.png', // 分享图标
                                success: function () {
                                    // 用户确认分享后执行的回调函数
                                    self.$alert("分享成功 :)");
                                },
                                cancel: function () {
                                    // 用户取消分享后执行的回调函数
                                    self.$alert("为啥取消了 :(");
                                }
                            });

                            wx.onMenuShareQZone({
                                title: '免代购费，EBUY海淘带你玩转黑色星期五!', // 分享标题
                                desc: '送你20元运费，还不来领？', // 分享描述
                                link: curUrl, // 分享链接
                                imgUrl: 'http://m.laidoulaile.com/static/images/logo.png', // 分享图标
                                success: function () {
                                    // 用户确认分享后执行的回调函数
                                    self.$alert("分享成功 :)");
                                },
                                cancel: function () {
                                    // 用户取消分享后执行的回调函数
                                    self.$alert("为啥取消了 :(");
                                }
                            });

                        });

                    });
                }

                handleWx();

            }
        }
    }
</script>