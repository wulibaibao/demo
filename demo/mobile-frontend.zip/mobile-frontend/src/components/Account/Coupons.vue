<style lang="less">
    @import (reference) '../../../static/css/base.less';

    .my-discount {
        .pb(50px);
        ul {
            .flex;
            border-bottom: 1px solid @e;
            box-sizing: border-box;
            li {
                flex: 1;
                .h(40px);
                line-height: 40px;
                .tac;
                a {
                    .db;
                    font-size: 14px;
                    color: @6;
                }
                &.on a {
                    color: @6s;
                    border-bottom: 1px solid @6s;
                    box-sizing: border-box;
                }
            }
        }
        .clear {
            overflow: hidden;
            clear: both
        }
        .get {
            float: right;
            .h(35px);
            line-height: 35px;
            .m(0 9px);
            .pr(26px);
            font-size: 12px;
            color: @6s;
            background: url(../../../static/images/how_get.png) right center no-repeat;
            background-size: 21px;
        }
        .con {
            .flex;
            .m(10px 9px 8px);
            border: 1px solid #DDDDDD;
            border-radius: 2px;
            box-sizing: border-box;
            & > p {
                .w(90px);
                .h(91px);
                line-height: 91px;
                .tac;
                font-size: 18px;
                color: @3;
                border-right: 1px dashed @d;
                box-sizing: border-box;
            }
            .cont {
                flex: 1;
                .rel;
                .mb(5px);
                & > p {
                    .m(8px 0 0 10px);
                    font-size: 8px;
                    color: @3;
                }
                .butt-status {
                    .abs;
                    top: 13px;
                    right: 10px;
                    .db;
                    .w(62px);
                    .h(62px);
                    line-height: 62px;
                    font-size: 14px;
                    color: @9;
                    .tac;
                    border: 1px solid @9;
                    border-radius: 50%;
                    box-sizing: border-box;
                }
                .on {
                    color: @f;
                    background: @6s;
                }
            }
        }
    }
</style>
<template>
    <div class="empty-bg"></div>
    <div class="my-discount">
        <ul>
            <li v-bind:class="{'on': type == 0}"  @click="changType(0)"><a href="javascript:void(0);">全部</a></li>
            <li v-bind:class="{'on': type == 1}"  @click="changType(1)"><a href="javascript:void(0);">未使用</a></li>
            <li v-bind:class="{'on': type == 2}"  @click="changType(2)"><a href="javascript:void(0);">已使用</a></li>
            <li v-bind:class="{'on': type == 3}"  @click="changType(3)"><a href="javascript:void(0);">已过期</a></li>
        </ul>
        <div class="con" v-for="coupon in coupons">
            <p>{{ coupon.value }}元</p>
            <div class="cont">
                <p>{{ coupon.name }}</p>
                <p>编号:{{ coupon.card_name }}</p>
                <p>{{ coupon.deliveries|toChange }}</p>
                <p>有效期至：<span>{{ coupon.start_time|dateformt_ymd }}</span> ~
                    <span>{{ coupon.end_time|dateformt_ymd }}</span></p>
				<span class="butt-status">
						{{ coupon|coupon_status }}
				</span>
            </div>
        </div>
        <infinite-loading :distance="distance" :on-infinite="getcouponsList"></infinite-loading>


    </div>
</template>
<script>
	import Vue from "vue"
	import Service from '../../utils/service';
	import InfiniteLoading from '../InfiniteLoading.vue'
    var deliveries='';
	module.exports = {
		components: {
            InfiniteLoading
        },
		data: function () {
            return {
                coupons: [],        //运费劵列表
                deliveries: [],     //配送方式列表
                type:0,             //type=0 表示查出所有 1 表示查出已使用 2 表示 查出已使用 3 表示查出已过期
                page: 1,
                pagesize:10,
            }
        },
        ready: function () {
            this.getDeliveries();
        },
        methods: {
            getcouponsList: function () {
                var me = this;
                Service.getcouponsList(me.type,me.page,me.pagesize, function (response) {
                    me.$alert(response.data.message)
                }, function (response) {
                    me.coupons = me.coupons.concat(response.data.data);
                    if (me.page >= response.data.meta.pagination.total_pages) {
                        me.$broadcast('$InfiniteLoading:noMore');
                    } else if (response.data.data.length == 0) {
                        me.$broadcast('$InfiniteLoading:noResults');
                    }
                    me.$broadcast('$InfiniteLoading:loaded');
                    me.page++;
                })
            },
            changType:function(type){
                var me=this;
                me.type=type;
                me.coupons=[];
                me.page=1;
                this.getcouponsList();

            },
            getDeliveries:function(){
                var me=this;
                Service.getDeliveries(null, function (response) {
                    me.deliveries = response.data.data;
                    deliveries=response.data.data;
                })
            },

        }
	}
	//日期至显示具体的年月日
	Vue.filter('dateformt_ymd',function(value){
		var str=value.replace(/-/g,"/");
		var date = new Date(str );
		var year=date.getFullYear();
		var month=parseInt(date.getMonth())+1;
		var day=date.getDate()
		return year+"-"+month+"-"+day;
	});
	//显示运费劵的具体状态
	Vue.filter('coupon_status',function(value){
		var currSeconds=new Date().getTime();
		var status='';
		if(value.is_userd==1){
			status="已使用";
		}else if(value.is_close==1){
			status='已禁用'
		}else if(value.is_close==2){
			status='临时锁定';
		}else{
			var startTime=value.start_time.replace(/-/g,"/");
			var startSeconds = new Date(startTime ).getTime();
			var endTime=value.end_time.replace(/-/g,"/");
			var endSeconds = new Date(endTime ).getTime();
			if(currSeconds>endSeconds){
				status='已过期';
			}else{
				status='可以使用';
			}
		}
		return status;
	});
	Vue.filter('toChange',function(value){
		var str=value.replace(/\"|\[|\]/g,"");
		var arr=str.split(',');
		if(arr.length==0){
		    return '';
		}
		var result=[];
		for(var i in deliveries){
		console.log(deliveries[i]);
            for(var j=0;j<arr.length;j++){
                if(arr[j]==deliveries[i]['id']){
                    result.push(deliveries[i]['name'])
                }
            }
		}
		return result.join(',');
	});



</script>