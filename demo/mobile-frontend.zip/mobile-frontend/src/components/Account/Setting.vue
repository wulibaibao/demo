<style lang="less">
    @import (reference) '../../../static/css/base.less';
    .per-set {
        .con {
            .ml(16px);
            & > a {
                .db;
                .w(100%);
                .h(44px);
                line-height: 44px;
                .pl(32px);
                font-size: 16px;
                color: @3;
                border-bottom: 1px solid @e;
                &:first-child {
                    background: url(../../../static/images/normal_problems.png) left center no-repeat;
                    background-size: 20px;
                }
                &:nth-child(2) {
                    background: url(../../../static/images/change_pwd.png) left center no-repeat;
                    background-size: 20px;
                }
                &:last-child {
                    background: url(../../../static/images/exit_login.png) left center no-repeat;
                    background-size: 20px;
                }
            }
        }
    }
</style>
<template>
    <div class="per-set">
        <div class="empty-bg"></div>
        <div class="con">
            <a href="javascript:void(0);" v-link="{name: 'help'}">常见问题</a>
            <a href="javascript:void(0);" v-link="{name: 'setting_password'}">修改密码</a>
            <a href="javascript:void(0);" @click="logout">退出登录</a>
        </div>
    </div>
</template>
<script>
    import User from '../../utils/user'
    import Service from '../../utils/service'

    var logoutHandler = function (response) {
        User.logout();

        window.$router.go({name: 'home'})
    };

    module.exports = {
        components: {},
        methods: {
            logout: function () {

                if (window.confirm('确认退出登录?')) {
                    Service.logout(logoutHandler, logoutHandler)
                }
            }
        }
    }
</script>