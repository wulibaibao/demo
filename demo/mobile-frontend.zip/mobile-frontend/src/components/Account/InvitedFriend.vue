<style lang="less">
    @import (reference) '../../../static/css/base.less';

    .invited-bg {
        .abs;
        left: 0;
        top: 0;
        .w(100%);
        .h(100%);
        background: url(../../../static/images/invited_bg.png) left top no-repeat;
        background-size: cover;
        z-index: 11;
    }

    .invited-logo {
        .abs;
        top: 40px;
        .w(100%);
        .h(44px);
        background: url(../../../static/images/invited_logo.png) center no-repeat;
        background-size: 151px 44px;
        z-index: 12;
    }

    .invited-cont {
        .rel;
        z-index: 111;
        .pt(144px)
    }

    .invited-intro {
        .w(88%);
        .h(150px);
        .m(0 auto 44px);
        background: url(../../../static/images/invited_intro.png) center no-repeat;
        background-size: contain;
    }

    .exclusive-holiday {
        .w(75%);
        .h(91px);
        .m(0 auto 15px);
        background: url(../../../static/images/exclusive.png) center no-repeat;
        background-size: contain;
    }

    .get-coupon {
        .db;
        .w(75%);
        .h(33px) !important;
        .m(0 auto 15px);
        font-size: 12px;
        color: @9;
        .p(6px);
        border-radius: 3px;
        &:focus {
            border-color: #f3596d !important;
        }
    }

    .draw-get {
        .db;
        .w(75%);
        .m(0 auto 28px);
        .hl(33px);
        color: @f;
        font-size: 16px;
        font-weight: 800;
        background-color: #000;
        .tac;
        border-radius: 5px;
    }

    .invited-tip {
        font-size: 12px;
        color: @9;
        .tac;
    }

    .floatlayer-freight-coupon {
        .fix;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        z-index: 11000;
        background: rgba(0, 0, 0, .8);
        .flexcenter;
        .ebuy-freight-tip {
            .rel;
            .w(90%);
            background: @f;
            border-radius: 2px;
            .tac;
            h3 {
                font-family: 'PingFangSC-Regular';
                .p(25px 0);
                font-size: 16px;
                color: @6;
                .tac;
            }
            .auth-code {
                .w(65%);
                .m(0 auto);
                text-align: left;
                font-size: 0;
                .col {
                    .dbi;
                    .w(59%);
                    vertical-align: middle;
                    .mr(5%);
                    .code-inp {
                        .dbi;
                        .w(100%);
                        .h(33px) !important;
                        font-size: 12px;
                        color: @9;
                        .p(6px);
                        vertical-align: middle;
                        border-radius: 3px;
                        &:focus {
                            border-color: #f3596d !important;
                        }
                    }
                }
                .cor {
                    .dbi;
                    .w(35%);
                    .hl(33px);
                    vertical-align: middle;
                    background-color: #000;
                    font-size: 13px;
                    color: @f;
                    .tac;
                    border-radius: 3px;
                }
            }
            .set-pswd {
                .db;
                .w(65%);
                .m(12px auto 17px);
                .h(33px) !important;
                font-size: 12px;
                color: @9;
                .p(6px);
                border-radius: 3px;
                &:focus {
                    border-color: #f3596d !important;
                }
            }
            .invited-but {
                .db;
                .w(65%);
                .m(0 auto 30px);
                .h(33px);
                line-height: 33px;
                font-size: 16px;
                color: @f;
                background-color: #D90707;
                font-weight: 800;
                border-radius: 3px;
            }
        }
    }

    .floatlayer-win {
        .fix;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        z-index: 11000;
        background: rgba(0, 0, 0, .8);
        .flexcenter;
        .ebuy-win-tip {
            .rel;
            .w(90%);
            background: @f;
            border-radius: 2px;
            .tac;
            h3 {
                font-size: 20px;
                color: #D90707;
                .p(55px 0 35px);
                .tac;
            }
            .win-exit {
                .abs;
                right: 0;
                top: 0;
                .w(24px);
                .h(24px);
                background: url(../../../static/images/pc_exit.png) center no-repeat;
                background-size: 16px;
            }
            .return-home {
                .db;
                .w(65%);
                .m(0 auto 17px);
                .hl(33px);
                background-color: @f;
                border: 1px solid #000;
                .bbox;
                font-size: 16px;
                color: #000;
                .tac;
            }
            .share-friends {
                .db;
                .w(65%);
                .m(0 auto 47px);
                .hl(33px);
                background-color: #D90707;
                font-size: 16px;
                color: @f;
                .tac;
            }
        }
    }

    .floatlayer-share {
        .fix;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        z-index: 11000;
        background: rgba(0, 0, 0, .8);
        .ebuy-share-tip {
            .rel;
            .w(100%);
            .tac;
            .invite-air {
                .abs;
                top: 85px;
                right: 5%;
                .w(187px);
                .h(118px);
                .m(0 auto);
                background: url(../../../static/images/invite_air.png) center no-repeat;
                background-size: contain;
            }
            h3 {
                .abs;
                top: 225px;
                right: 21%;
                font-size: 20px;
                color: @f;
            }
        }
    }

    .floatlayer-pc {
        .fix;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        z-index: 11000;
        background: rgba(0, 0, 0, .5);
        .flexcenter;
        .ebuy-pc-tip {
            .rel;
            .w(90%);
            background: @f;
            border-radius: 2px;
            .tac;
            p {
                font-family: 'PingFangSC-Regular';
                font-size: 16px;
                line-height: 24px;
                .p(59px 30px 52px);
                font-weight: 700;
                color: @3;
            }
            .pc-but {
                .db;
                .w(62%);
                .m(0 auto 30px);
                .h(38px);
                line-height: 38px;
                font-size: 16px;
                color: @f;
                background-color: #D90707;
                font-weight: 800;
                border-radius: 3px;
            }
            .pc-exit {
                .abs;
                right: 0;
                top: 0;
                .w(24px);
                .h(24px);
                background: url(../../../static/images/pc_exit.png) center no-repeat;
                background-size: 16px;
            }
        }
    }

    .floatlayer-share {
        .fix;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        z-index: 11000;
        background: rgba(0, 0, 0, .9);
        .ebuy-share-tip {
            .rel;
            .w(100%);
            .tac;
            .invite-air {
                .abs;
                top: 85px;
                right: 5%;
                .w(187px);
                .h(118px);
                .m(0 auto);
                background: url(../../../static/images/invite_air.png) center no-repeat;
                background-size: contain;
            }
            h3 {
                .abs;
                top: 225px;
                right: 21%;
                font-size: 20px;
                color: @f;
            }
        }
    }

    @media only screen and (max-width: 320px) {
        .invited-bg {
            .h(660px) !important;
        }
    }

    @media only screen and (max-width: 384px) and (min-width: 384px) {
        .invited-bg {
            .h(683px) !important
        }
    }

    @media only screen and (max-width: 360px) and (min-width: 360px) {
        .invited-tit {
            .p(74px 0 85px)
        }

        .invited-bg {
            .h(640px) !important
        }
    }

    @media screen and (min-width: 414px) {
        .invited-tit {
            .p(74px 0 130px)
        }
    }

    @media screen and (max-width: 412px) and (min-width: 412px) {
        .invited-tit {
            .p(74px 0 115px)
        }

        .invited-bg {
            .h(732px) !important
        }
    }
	@import '../../../static/css/base.less';
	.invited-bg {
		.abs;
		left:0;
		top:0;
		.w(100%);
		.h(100%);
		background: url(../../../static/images/invited_bg.png) left top no-repeat;
		background-size: cover;
		z-index: 11;
	}
	.invited-logo {
		.abs;
		top: 40px;
		.w(100%);
		.h(44px);
		background: url(../../../static/images/invited_logo.png) center no-repeat;
		background-size: 151px 44px;
		z-index: 12;
	}
	.invited-cont {
		.rel;
		z-index: 111;
		.pt(144px)
	}
	.invited-intro {
		.w(88%);
		.h(150px);
		.m(0 auto 44px);
		background: url(../../../static/images/invited_intro.png) center no-repeat;
		background-size: contain;
	}
	.exclusive-holiday {
		.w(75%);
		.h(91px);
		.m(0 auto 15px);
		background: url(../../../static/images/exclusive.png) center no-repeat;
		background-size: contain;
	}
	.get-coupon {
		.db;
		.w(75%);
		.h(33px)!important;
		.m(0 auto 15px);
		font-size: 12px;
		color: @9;
		.p(6px);
		border-radius: 3px;
		&:focus {
			border-color: #f3596d!important;
		}
	}
	.draw-get {
		.db;
		.w(75%);
		.m(0 auto 28px);
		.hl(33px);
		color: @f;
		font-size: 16px;
		font-weight: 800;
		background-color: #000;
		.tac;
		border-radius: 5px;
	}
	.invited-tip {
		font-size: 12px;
		color: @9;
		.tac;
	}
	.floatlayer-freight-coupon {
		.fix;
		top: 0;
		right: 0;
		bottom: 0;
		left: 0;
		z-index: 11000;
		background: rgba(0,0,0,.8);
		.flexcenter;
		.ebuy-freight-tip {
			.rel;
			.w(90%);
			background:@f;
			border-radius: 2px;
			.tac;
			h3 {
				font-family: 'PingFangSC-Regular';
				.p(25px 0);
				font-size: 16px;
				color: @6;
				.tac;
			}
			.auth-code {
				.w(65%);
				.m(0 auto);
				text-align: left;
				font-size: 0;
				.col {
					.dbi;
					.w(59%);
					vertical-align: middle;
					.mr(5%);
					.code-inp {
						.dbi;
						.w(100%);
						.h(33px)!important;
						font-size: 12px;
						color: @9;
						.p(6px);
						vertical-align: middle;
						border-radius: 3px;
						&:focus {
							border-color: #f3596d!important;
						}
					}
				}
				.cor {
					.dbi;
					.w(35%);
					.hl(33px);
					vertical-align: middle;
					background-color: #000;
					font-size: 13px;
					color: @f;
					.tac;
					border-radius: 3px;
				}
			}
			.set-pswd {
				.db;
				.w(65%);
				.m(12px auto 17px);
				.h(33px)!important;
				font-size: 12px;
				color: @9;
				.p(6px);
				border-radius: 3px;
				&:focus {
					border-color: #f3596d!important;
				}
			}
			.invited-but {
				.db;
				.w(65%);
				.m(0 auto 30px);
				.h(33px);
				line-height: 33px;
				font-size: 16px;
				color: @f;
				background-color: #D90707;
				font-weight: 800;
				border-radius: 3px;
			}
		}
	}
	.floatlayer-win {
		.fix;
		top: 0;
		right: 0;
		bottom: 0;
		left: 0;
		z-index: 11000;
		background: rgba(0,0,0,.8);
		.flexcenter;
		.ebuy-win-tip {
			.rel;
			.w(90%);
			background:@f;
			border-radius: 2px;
			.tac;
			h3 {
				font-size: 20px;
				color: #D90707;
				.p(55px 0 35px);
				.tac;
			}
			.win-exit {
				.abs;
				right: 0;
				top: 0;
				.w(24px);
				.h(24px);
				background: url(../../../static/images/pc_exit.png) center no-repeat;
				background-size: 16px;
			}
			.return-home {
				.db;
				.w(65%);
				.m(0 auto 17px);
				.hl(33px);
				background-color:@f;
				border: 1px solid #000;
				.bbox;
				font-size: 16px;
				color: #000;
				.tac;
			}
			.share-friends {
				.db;
				.w(65%);
				.m(0 auto 47px);
				.hl(33px);
				background-color:#D90707;
				font-size: 16px;
				color: @f;
				.tac;
			}
		}
	}
	.floatlayer-pc {
		.fix;
		top: 0;
		right: 0;
		bottom: 0;
		left: 0;
		z-index: 11000;
		background: rgba(0,0,0,.5);
		.flexcenter;
		.ebuy-pc-tip {
			.rel;
			.w(90%);
			background:@f;
			border-radius: 2px;
			.tac;
			p {
				font-family: 'PingFangSC-Regular';
				font-size: 16px;
				line-height: 24px;
				.p(59px 30px 52px);
				font-weight: 700;
				color: @3;
			}
			.pc-but {
				.db;
				.w(62%);
				.m(0 auto 30px);
				.h(38px);
				line-height: 38px;
				font-size: 16px;
				color: @f;
				background-color: #D90707;
				font-weight: 800;
				border-radius: 3px;
			}
			.pc-exit {
				.abs;
				right: 0;
				top: 0;
				.w(24px);
				.h(24px);
				background: url(../../../static/images/pc_exit.png) center no-repeat;
				background-size: 16px;
			}
		}
	}
	.floatlayer-share {
		.fix;
		top: 0;
		right: 0;
		bottom: 0;
		left: 0;
		z-index: 11000;
		background: rgba(0,0,0,.8);
		.ebuy-share-tip {
			.rel;
			.w(100%);
			.tac;
			.invite-air {
				.abs;
				top: 85px;
				right: 5%;
				.w(187px);
				.h(118px);
				.m(0 auto);
				background: url(../../../static/images/invite_air.png) center no-repeat;
				background-size: contain;
			}
			h3 {
				.abs;
				top: 225px;
				right: 21%;
				font-size: 20px;
				color: @f;
			}
		}
	}
	@media only screen and (max-width: 320px) {
		.invited-bg {
			.h(660px)!important;
		}
	}
	@media only screen and (max-width: 384px) and (min-width: 384px) {
		.invited-bg {
			.h(683px)!important
		}
	}
	@media only screen and (max-width: 360px) and (min-width: 360px){
		.invited-tit {
			.p(74px 0 85px)
		}
		.invited-bg {
			.h(640px)!important
		}
	}
	@media screen and (min-width: 414px) {
		.invited-tit {
			.p(74px 0 130px)
		}
	}
	@media screen and (max-width: 412px) and (min-width: 412px){
		.invited-tit {
			.p(74px 0 115px)
		}
		.invited-bg {
			.h(732px)!important
		}
	}
</style>
<template>
    <ebuy-gohome></ebuy-gohome>
    <div class="invited-bg"></div>
    <div class="invited-logo"></div>
    <div class="invited-cont">
        <div class="invited-intro"></div>
        <p class="exclusive-holiday"></p>
        <input type="text" placeholder="请输入手机号领取优惠券" v-model="data.mobile" class="get-coupon" autocomplete="off">
        <a href="javascript:void(0);" class="draw-get" @click="sendMobileCode">立即领取</a>
        <h3 class="invited-tip">领取成功后，下单即可用券抵用等额国际运费。</h3>
    </div>
    <div class="floatlayer-freight-coupon none">
        <div class="ebuy-freight-tip">
            <h3>完成注册领取运费券</h3>
            <div class="auth-code">
                <div class="col">
                    <input type="text" placeholder="请输入验证码" v-model="data.mobileCode" class="code-inp"
                           autocomplete="off">
                </div>
                <a href="javascript:void(0);" class="cor" @click="sendMobileCode" v-if="!data.sent">获取验证码</a>
                <a href="javascript:void(0);" class="cor disabled" class="disabled" v-else>{{data.countdown}}秒后重发</a>

            </div>
            <input type="password" placeholder="设置登录密码（6-32字符）" v-model="data.password" maxlength="32" class="set-pswd"
                   autocomplete="off">
            <a href="javascript:void(0);" class="invited-but" @click="tryRegister">立即领取</a>
        </div>
    </div>
    <div class="floatlayer-win none">
        <div class="ebuy-win-tip">
            <a href="javascript:void(0);" class="win-exit" @click="winExit"></a>
            <h3>恭喜您领取成功！</h3>
            <a href="javascript:void(0);" class="return-home" v-link="{ name: 'home' }">返回首页</a>
            <a href="javascript:void(0);" class="share-friends" v-link="{ name: 'account_invite' }">分享给朋友领券</a>
        </div>
    </div>
</template>
<script>

    import Service from '../../utils/service'
    import User from '../../utils/user'
    import wx from 'weixin-js-sdk'
    import EbuyGohome from '../Common/ReturnhomeBubble.vue'

    module.exports = {
        components: {
            EbuyGohome
        },
        data: function () {
            return {
                data: {
                    sent: false,
                    countdown: 60,
                    invitedCode: '',
                }
            }
        },
        ready: function () {
            document.title = '邀请有奖';
            var _height = document.documentElement.clientHeight;
            jQuery('.invited-bg').css('height', _height);
            if (this.isWechat()) {
                this.initWeChatShare();
            }
        },
        methods: {
            showWin: function () {
                this.sendMobileCode();
                $('.floatlayer-freight-coupon').removeClass('none');
            },
            shareWin: function () {
                $('.floatlayer-freight-coupon').addClass('none');
                $('.floatlayer-win').removeClass('none');
            },
            hideTip: function () {
                $('.floatlayer-pc').addClass('none');
            },
            winExit: function () {
                $('.floatlayer-win').addClass('none');
            },
            isWechat: function () {
                var me = this,
                        wac = window.navigator.userAgent.toLowerCase();
                if (wac.match(/MicroMessenger/i) == 'micromessenger') {
                    return true;
                } else {
                    return false;
                }
            },
            shareFeds: function () {
                $('.floatlayer-win').addClass('none');
                if (this.isWechat() == true) {
                    $('.floatlayer-share').removeClass('none');
                }
                else {
                    $('.floatlayer-pc').removeClass('none');
                }
            },
            tryRegister: function () {
                var self = this;
                var openId = localStorage.getItem('openId');
                this.data.inviteCode = localStorage.getItem('invitedCode');

                Service.registerUserForInvite(this.data.mobile, this.data.password, this.data.mobileCode, this.data.inviteCode, openId, function (response) {
                    self.$alert(response.data.message);
                }, function (response) {

                    User.login({
                        access_token: response.data.data.access_token
                    });

                    self.shareWin();
                })
            },
            sendMobileCode: function () {
                var self = this;

                Service.sendRegisterMobileCode(this.data.mobile, function (response) {
                    self.$alert(response.data.message);
                }, function (response) {
                    self.showWin();
                    self.$alert('请查收短信验证码');
                    self.data.sent = true;
                    self.data.countdown = 60;

                    var timer = setInterval(function cycle() {
                        self.data.countdown--;

                        if (self.data.countdown <= 0) {
                            clearInterval(timer);
                            self.data.sent = false;
                        }

                    }, 1000);
                })
            },
            initWeChatShare: function () {
                var self = this;
                var curUrl = location.href.split('#')[0];

                Service.getWechatJsConfig(encodeURIComponent(curUrl), null, function (res) {

                    var config = res.data.data;

                    wx.config({
                        debug: false,
                        appId: config.appId,
                        timestamp: config.timestamp,
                        nonceStr: config.nonceStr,
                        signature: config.signature,
                        jsApiList: config.jsApiList
                    });

                    wx.ready(function () {

                        wx.onMenuShareTimeline({
                            title: '免代购费，EBUY海淘带你玩转黑色星期五！送你20元运费，还不来领？', // 分享标题
                            link: curUrl, // 分享链接
                            imgUrl: 'http://m.laidoulaile.com/static/images/logo.png', // 分享图标
                            success: function () {
                                // 用户确认分享后执行的回调函数
                                self.$alert("分享成功 :)");
                            },
                            cancel: function () {
                                // 用户取消分享后执行的回调函数
                                self.$alert("为啥取消了 :(");
                            }
                        });

                        wx.onMenuShareAppMessage({
                            title: '免代购费，EBUY海淘带你玩转黑色星期五!', // 分享标题
                            desc: '送你20元运费，还不来领？', // 分享描述
                            link: curUrl, // 分享链接
                            imgUrl: 'http://m.laidoulaile.com/static/images/logo.png', // 分享图标
                            type: '', // 分享类型,music、video或link，不填默认为link
                            dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
                            success: function () {
                                // 用户确认分享后执行的回调函数
                                self.$alert("分享成功 :)");
                            },
                            cancel: function () {
                                // 用户取消分享后执行的回调函数
                                self.$alert("为啥取消了 :(");
                            }
                        });

                        wx.onMenuShareQQ({
                            title: '免代购费，EBUY海淘带你玩转黑色星期五!', // 分享标题
                            desc: '送你20元运费，还不来领？', // 分享描述
                            link: curUrl, // 分享链接
                            imgUrl: 'http://m.laidoulaile.com/static/images/logo.png', // 分享图标
                            success: function () {
                                // 用户确认分享后执行的回调函数
                                self.$alert("分享成功 :)");
                            },
                            cancel: function () {
                                // 用户取消分享后执行的回调函数
                                self.$alert("为啥取消了 :(");
                            }
                        });

                        wx.onMenuShareQZone({
                            title: '免代购费，EBUY海淘带你玩转黑色星期五!', // 分享标题
                            desc: '送你20元运费，还不来领？', // 分享描述
                            link: curUrl, // 分享链接
                            imgUrl: 'http://m.laidoulaile.com/static/images/logo.png', // 分享图标
                            success: function () {
                                // 用户确认分享后执行的回调函数
                                self.$alert("分享成功 :)");
                            },
                            cancel: function () {
                                // 用户取消分享后执行的回调函数
                                self.$alert("为啥取消了 :(");
                            }
                        });

                    });

                    wx.error(function (res) {
//                        self.$alert(res.data);
                    });


                });

            }
        }
    }
</script>