<style lang="less">
	@import (reference) '../../../static/css/base.less';
	.bond-mobile {
		.w(91%);
		.m(0 auto);
		background-color: @f;
		.pt(130px);
		.bond-text {
			.db;
			.w(100%);
			.p(10px 0);
			border:none;
			border-bottom: 1px solid #ddd;
			font-size: 13px;
			color: #666;
			text-indent: 2px;
			.bbox;
		}
		.bond-code{font-size:0}
		.code-text {
			.dbi;
			.w(53%);
			.p(10px 0);
			border:none;
			border-bottom: 1px solid #ddd;
			font-size: 13px;
			color: #666;
			text-indent: 2px;
			.bbox;
		}
		.get-code {
			.dbi;
			.w(34%);
			.hl(35px);
			.m(10px 0 44px 4%);
			font-size: 13px;
			color: #999;
			border: 1px solid @6s;
			.bbox;
			.tac;
			border-radius: 3px
		}
		.bond-button {
			.db;
			.w(100%);
			.hl(35px);
			font-size: 16px;
			color: @f;
			.tac;
			border-radius: 3px;
			background-color: @6s;
		}
		.bond-intro {
			.mt(27px);
			font-size: 12px;
			color: #666;
			line-height: 21px;
			text-indent: 20px;
		}
	}
	.floatlayer-bond-win {
		.fix;
		top: 0;
		right: 0;
		bottom: 0;
		left: 0;
		z-index: 11000;
		background: rgba(0,0,0,.8);
		.flexcenter;
		.ebuy-win-tip {
			.rel;
			.w(90%);
			background:@f;
			border-radius: 2px;
			.tac;
			i {
				.db;
				.w(32px);
				.h(32px);
				.m(30px auto 10px);
				background: url(../../../static/images/bound_win.png) center no-repeat;
				background-size: 32px;
			}
			h3 {
				font-size: 15px;
				color: #333;
				.tac;
			}
			.return-home {
				.db;
				.w(65%);
				.m(38px auto 20px);
				.hl(35px);
				background-color:@6s;
				border-radius: 3px;
				.bbox;
				font-size: 16px;
				color: @f;
				.tac;
			}
		}
	}
</style>
<template>
	<div class="empty-bg"></div>
	<div class="bond-mobile">
		<input type="text" maxlength="11" placeholder="请输入您的手机号" class="bond-text" v-model="data.mobile">
		<div class="bond-code">
			<input type="text" maxlength="4" v-model="data.mobileCode" placeholder="请输入短信验证码" class="code-text">
			<a href="javascript:void(0);" class="get-code" @click="sendMobileCode" v-if="!data.sent">获取验证码</a>
			<a href="javascript:void(0);" class="get-code disabled" v-else>{{data.countdown}}秒后重发</a>
		</div>
		<a href="javascript:void(0);" class="bond-button" @click="tryBond">绑定</a>
		<p class="bond-intro">
			EBUY海淘已启用手机号登录功能，为了保护您的账户安全以及确保订单有任何问题时能够及时联系到您，邀请您立即绑定手机号，绑定成功之后即可使用手机号登录网站。
		</p>
	</div>
	<div class="floatlayer-bond-win none">
		<div class="ebuy-win-tip">
			<i></i>
			<h3>绑定成功</h3>
			<a href="javascript:void(0);" class="return-home" v-link="{ name: 'home' }">返回首页</a>
		</div>
	</div>
</template>
<script>
	import Service from '../../utils/service'
	import User from '../../utils/user'
	module.exports = {
		data: function() {
			return {
				data: {
					sent: false,
					countdown: 60,
					mobile: '',
					mobileCode: ''
				}
			}
		},
		methods: {
			tryBond: function () {
				var self = this;
				Service.bindMobile(this.data.mobile, this.data.mobileCode, function (response) {
					self.$alert(response.data.message);
				}, function (response) {
					self.$alert('绑定成功');
					window.history.go(-1);
				})
			},
			sendMobileCode: function () {
				var self = this;

				Service.sendBindMobileCode(this.data.mobile, function (response) {
					self.$alert(response.data.message);
				}, function (response) {
					self.$alert('请查收短信验证码');
					self.data.sent = true;
					self.data.countdown = 60;

					var timer = setInterval(function cycle() {
						self.data.countdown--;

						if (self.data.countdown <= 0) {
							clearInterval(timer);
							self.data.sent = false;
						}

					}, 1000);
				})
			},
		}
	}
</script>