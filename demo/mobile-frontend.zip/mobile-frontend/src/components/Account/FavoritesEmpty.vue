<style lang="less">
    @import (reference) '../../../static/css/base.less';
    .empty-cart {
        position: relative;
        z-index: 10000;
    }

    .empty-img {
        .w(114px);
        .h(114px);
        .img;
        .m(78px auto 10px)
    }

    .empty-h3 {
        .mb(44px);
        font-size: 16px;
        color: @9;
        .tac
    }

    .empty-gosky {
        font-family: 'PingFangSC-Regular';
        .db;
        .w(94%);
        .h(40px);
        .m(0 auto);
        line-height: 40px;
        font-size: 16px;
        background: @6s;
        border-radius: 2px;
        .tac;
        color: @f;
        letter-spacing: 1px
    }
</style>
<template>
    <div class="empty-cart">
        <div class="empty-bg"></div>
        <div class="empty-img">
            <img :src="collect_empty">
        </div>
        <h3 class="empty-h3">暂无收藏商品</h3>
        <a href="javascript:void(0);" class="empty-gosky" v-link="{path:'/category'}">马上逛逛</a>
    </div>
</template>
<script>
    import EbuyFooter from '../Common/Footer.vue'
    import EbuyChat from '../Common/ChatBubble.vue'
    import User from '../../utils/user'
    import Service from '../../utils/service';
    module.exports = {
        components: {
            EbuyChat
        },
        data: function () {
            return {
                collect_empty: require('static_file/images/empty_collect.png')
            }
        }

    }
</script>