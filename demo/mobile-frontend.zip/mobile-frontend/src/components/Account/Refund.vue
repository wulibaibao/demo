<style lang="less">
    @import (reference) '../../../static/css/base.less';
    .ref-rec {
        .pb(50px);
        h3 {
            .h(30px);
            line-height: 30px;
            .pl(9px);
            font-size: 14px;
            color: @3;
            background: #f1f1f1;
            span {
                .dbi;
                font-size: 12px;
            }
        }
        .cont {
            .rel;
            background: @f;
            .p(5px 9px 0);
            p {
                font-size: 14px;
                color: @6;
                span {
                    .dbi;
                    .ml(3px);
                }
            }
            .plan {
                border-bottom: 1px solid @e;
                box-sizing: border-box;
                .pb(21px);
            }
            h5 {
                .h(30px);
                line-height: 30px;
                font-size: 14px;
                color: @6s;
            }
            .money {
                .abs;
                right: 9px;
                bottom: 2px;
                color: @6s;
                .fh {
                    font-size: 14px;
                }
                .sum {
                    font-size: 18px;
                }
            }
        }
        .more {
            .db;
            .mt(25px);
            .p(5px 0);
            font-size: 12px;
            color: @9;
            .tac;
        }
    }
</style>
<template>
    <refund-empty></refund-empty>
    <div class="ref-rec">
        <div class="col" v-for="refund in refund_list"><!--v-for-->         
            <h3>订单号：<span>{{refund.order_no}}</span></h3>
            <div class="cont">
                <p class="time">申请时间：<span>{{refund.time}}</span></p>
                <p class="cause">退款原因：<span>{{refund.content}}</span></p>
                <p class="cause">备注：<span>{{refund.dispose_idea}}</span></p>

                <h5 v-if="refund.pay_status == 0">等待审核</h5><h5 v-if="refund.pay_status == 0" @click="cancelRefund(refund.id)">取消</h5>
                <h5 v-if="refund.pay_status == 1">退款失败</h5>
                <h5 v-if="refund.pay_status == 2 || refund.pay_status == 3">退款成功</h5>
                <p class="money"><span class="fh">￥</span><span class="sum">{{refund.amount}}</span></p>
            </div>
        </div>
        <a href="javascript:void(0);" class="more" @click="fetchRefundList()">查看更多</a>
    </div>
</template>
<script>

    var Vue = require('vue');

    import EbuyFooter from '../Common/Footer.vue'
    import User from '../../utils/user'
    import Service from '../../utils/service'
    import RefundEmpty from '../Common/Refund_empty.vue'

    import {Popup} from 'mint-ui';

    Vue.component(Popup.name, Popup);

    module.exports = {
        data:function() {
            return {
                refund_list:[],
                page:1
            }
        },
        components: {
            RefundEmpty,
        },
        ready: function () {
            this.fetchRefundList();
        },
        methods: {
            fetchRefundList: function () {
                var self = this;

                Service.refundList(self.page, function (response) {
                    self.$alert(response.data.message)
                }, function (response) {
                    if(response.data.data.length == 0){
                        $(".more").hide()
                        if(self.page == 1){
                            $('.empty-refund').css('display', 'block');
                        }
                        return;
                    }
                    for(var i in response.data.data){
                        self.refund_list.push(response.data.data[i])
                    }
                    self.page++;
                })
            },            
            cancelRefund: function (refund_id) {
                var self = this;

                if (confirm("是否取消退款申请?")) {
                    Service.cancelRefund(refund_id, function (response) {
                        self.$alert(response.data.message)
                    }, function (response) {
                        self.page = 1;
                        self.refund_list = [];
                        self.fetchRefundList();
                    });
                }
            },
        }
    }
</script>   