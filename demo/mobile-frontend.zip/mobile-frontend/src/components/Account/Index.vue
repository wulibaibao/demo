<style lang="less">
    @import (reference) '../../../static/css/base.less';

    .ebuy-personal-introduce {
        background: url(../../../static/images/personal_bg.png) center no-repeat;
        background-size: cover;
        .tac;
        .head-settings {
            .rel;
            .db;
            width: 64px;
            height: 64px;
            .m(0 auto 16px);
            .img;
            top: 20px;
            border-radius: 50%;
            img {
                border-radius: 50%;
            }
            input[type=file] {
                .abs;
                .w(100%);
                .h(100%);
                opacity: 0;
                background: none;
                left: 0;
                top: 0;
            }
        }
        p {
            font-family: 'PingFangSC-Regular';
            .p(15px 0 28px);
            font-size: 14px;
            color: @f;
        }
        .invite-details {
            .rel;
            top: 25px;
            font-size: 0;
            span, a {
                .dbi;
                color: @f;
                font-size: 14px;
                .mr(5px);
            }
            a {
                .w(37px);
                .h(20px);
                .ml(4px);
                line-height: 20px;
                border: 1px solid @6s;
                border-radius: 5px;
            }
        }
        .icon_vip{
            .abs;
            display: inline-block;
            background: url("../../../static/images/icon_vip.png") no-repeat;
            background-size: contain;
            width: 22px;
            height: 22px;
            .ml(7px);
            text-indent: -99999px;
            overflow: hidden;
        }
    }

    .ebuy-personal-nav {
        background: @f;
        ul {
            .flex;
            li {
                flex: 1;
                .tac;
                align-items: center;
                a {
                    .db;
                    .w(100%);
                    .p(13px 0 0);
                    & > .buycar_img, & > .menu_img, & > .adress_img {
                        .db;
                        .w(45px);
                        .h(45px);
                        .img;
                        .m(0 auto);
                    }
                    p {
                        font-family: 'PingFangSC-Regular';
                        .mt(8px);
                        padding-bottom: 13px;
                        font-size: 12px;
                        color: @6
                    }
                }
            }
        }
    }

    .ebuy-personal-sort {
        .mt(18px);
        ul {
            background: @f;
            li {
                .h(44px);
                line-height: 44px;
                &:first-child a p {
                    background: url(../../../static/images/personal_collect.png) left center no-repeat;
                    background-size: 20px;
                }
                &:last-child a p {
                    background: url(../../../static/images/personal_cheaps.png) left center no-repeat;
                    background-size: 20px;
                }
                &.cou a p {
                    background: url(../../../static/images/personal_cheap.png) left center no-repeat;
                    background-size: 20px;
                }
                &.ref a p {
                    background: url(../../../static/images/personal_refund.png) left center no-repeat;
                    background-size: 20px;
                }
                &.set a p {
                    background: url(../../../static/images/personal_settings.png) left center no-repeat;
                    background-size: 20px;
                    boder: none
                }
                &.bound a p {
                    background: url(../../../static/images/bound_mobile.png) left center no-repeat;
                    background-size: 20px;
                    boder: none
                }
                a {
                    .db;
                    p {
                        font-size: 14px;
                        color: @3;
                        .ml(3%);
                        padding-left: 32px;
                        border-bottom: 1px solid @e
                    }
                }
            }
        }
    }

    .floatlayer-bound-mobile {
        .fix;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        z-index: 10000001;
        background: rgba(0, 0, 0, .8);
        .flexcenter;
        .ebuy-win-tip {
            .rel;
            .w(90%);
            background: @f;
            border-radius: 2px;
            .tac;
            h3 {
                .m(20px 0);
                font-size: 15px;
                color: #333;
                .tac;
            }
            h4 {
                .p(0 4%);
                line-height: 20px;
                font-size: 12px;
                color: #333;
                text-indent: 20px;
                text-align: left;
            }
            .new-bond-mobile {
                .db;
                .w(65%);
                .m(30px auto 20px);
                .hl(35px);
                background-color: @6s;
                border-radius: 3px;
                .bbox;
                font-size: 16px;
                color: @f;
                .tac;
            }
            .next-time {
                .db;
                .w(65%);
                .m(0 auto 20px);
                .hl(35px);
                background-color: @f;
                font-size: 12px;
                color: #999;
                .tac;
            }
        }
    }
</style>
<template>
    <!--绑定手机号弹窗-->
    <div class="floatlayer-bound-mobile" v-show='showBindWindow'>
        <div class="ebuy-win-tip">
            <h3>绑定手机号</h3>
            <h4>EBUY海淘已启用手机号登录功能，为了保护您的账户安全以及确保订单有任何问题时能够及时联系到您，邀请您立即绑定手机号，绑定成功之后即可使用手机号登录网站。</h4>
            <a href="javascript:void(0);" class="new-bond-mobile" v-link="{ name: 'bound_mobile' }">绑定</a>
            <a href="javascript:void(0);" class="next-time" @click="closeBindPop">暂不绑定</a>
        </div>
    </div>
    <div class="ebuy-personal-introduce">
        <a href="javascript:void(0);" class="head-settings">
            <img :src="user.head_icon">
            <!--<input type="file" name="img" accept="image/jpeg,image/x-png">-->
        </a>
        <p class="rel">{{user.name}}<span v-show="user.group_id==1" class="icon_vip">VIP</span>

        </p>


        <!-- <div class="invite-details">
            <span>邀请码</span>
            <span>AAAAAAA</span>
            <a href="javascript:void(0);">拷贝</a>
        </div> -->
    </div>
    <nav class="ebuy-personal-nav">
        <ul>
            <li>
                <a href="javascript:void(0);" v-link="{ name: 'cart' }" class="personal_buycar">
                    <div class="buycar_img"><img :src="personal_buycar"></div>
                    <p>购物车</p></a>
            </li>
            <li>
                <a href="javascript:void(0);" v-link="{name: 'account_orders'}" class="personal_menu">
                    <div class="menu_img"><img :src="personal_menu"></div>
                    <p>我的订单</p></a>
            </li>
            <li>
                <a href="javascript:void(0);" v-link="{name: 'account_address'}" class="personal_address">
                    <div class="adress_img"><img :src="personal_adress"></div>
                    <p>收货地址</p></a>
            </li>
        </ul>
    </nav>
    <div class="ebuy-personal-sort">
        <ul>
            <li>
                <a href="javascript:void(0);" v-link="{name: 'account_favorites'}"><p>我的收藏</p></a>
            </li>
            <!--<li class="cou">-->
            <!--<a href="javascript:void(0);" v-link="{name: 'account_coupons'}"><p>优惠券</p></a>-->
            <!--</li>-->
            <li class="ref">
            <a href="javascript:void(0);" v-link="{name: 'account_refund'}"><p>退款申请</p></a>
            </li>
            <li class="cou">
                <a href="javascript:void(0);" v-link="{name:'account_coupons'}"><p>我的优惠券</p></a>
            </li>
            <li class="set">
                <a href="javascript:void(0);" v-link="{name:'setting'}"><p>个人设置</p></a>
            </li>
            <li class="bound" v-show="showBindMenu">
                <a href="javascript:void(0);" v-link="{name:'bound_mobile'}"><p>绑定手机</p></a>
            </li>
            <li>
                <a href="./account/invite" ><p>邀请有奖</p></a>
            </li>
        </ul>
    </div>
    <ebuy-chat></ebuy-chat>
    <ebuy-footer></ebuy-footer>
</template>
<script>
    import EbuyFooter from '../Common/Footer.vue'
    import EbuyChat from '../Common/ChatBubble.vue'
    import User from '../../utils/user'
    import Service from '../../utils/service'

    module.exports = {
        components: {
            EbuyFooter,
            EbuyChat
        },
        ready: function () {
            var self = this;
            Service.userInfo(function (response) {
                self.$alert(response.data.message);
            }, function (response) {
                self.user = response.data.data;
                // 保存用户邀请码到本地
                localStorage.setItem('inviteCode', self.user.invite_code);
                if (!self.user.mobile_bind) {
                    self.showBindMenu = true;
                    self.showBindWindow = (sessionStorage.getItem('showBindWindow') == 'false') ? false : true;
                } else {
                    self.showBindMenu = false;
                    self.showBindWindow = false;
                }
            });
        },
        methods: {
            isLogged() {
                var accessToken = localStorage.getItem('access_token');

                return accessToken ? true : false;
            },
            showBindPop(){
                if (this.isLogged()) {
                    this.getUserInfo();
                }
            },
            closeBindPop: function () {
                this.showBindWindow = false;
                sessionStorage.setItem('showBindWindow', false);
            }
        },
        data: function () {
            return {
                user: {
                    head_icon: require('static_file/images/head.png')
                },
                personal_buycar: require('static_file/images/personal_buycar.png'),
                personal_menu: require('static_file/images/personal_menu.png'),
                personal_adress: require('static_file/images/personal_adress.png'),
                personal_collect: require('static_file/images/personal_collect.png'),
                personal_cheap: require('static_file/images/personal_cheap.png'),
                personal_refund: require('static_file/images/personal_refund.png'),
                personal_settings: require('static_file/images/personal_settings.png'),
                showBindMenu: false,
                showBindWindow: false
            }
        }
    }
</script>