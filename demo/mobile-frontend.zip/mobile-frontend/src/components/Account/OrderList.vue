<style lang="less">
    @import (reference) '../../../static/css/base.less';

    .my-order {
        .pb(100px);
        ul {
            .flex;
            background: @f;
            li {
                flex: 1;
                .h(40px);
                line-height: 40px;
                .tac;
                a {
                    .db;
                    font-size: 14px;
                    color: @6
                }
                &.on a {
                    color: @6s;
                    border-bottom: 1px solid @6s;
                    box-sizing: border-box;
                }
            }
        }
        .title {
            .h(30px);
            line-height: 30px;
            .m(0 9px);
            background: #f1f1f1;
            h3 {
                float: left;
                font-size: 12px;
                color: @6;
                span {
                    .dbi;
                    .ml(3px);
                }
            }
            span {
                float: right;
                font-size: 12px;
                color: @6;
            }
        }
        .cont {
            background: @f;
            .p(10px 9px);
            .details {
                .rel;
                .flex;
                .mb(8px);
                border-bottom: 1px solid @e;
                box-sizing: border-box;
                .img {
                    .w(74px);
                    .h(74px);
                    .mr(17px);
                    border: 1px solid @e;
                    .img;
                    box-sizing: border-box;
                }
                .intro {
                    flex: 1;
                    h5 {
                        line-height: 18px;
                        font-size: 14px;
                        color: @3;
                        .lh
                    }
                    .rule {
                        font-size: 12px;
                        color: @6;
                        .p(5px 0 4px);
                        span {
                            .ml(3px);
                        }
                    }
                    .from {
                        .pb(10px);
                        font-size: 12px;
                        color: @6;
                    }
                    h4 {
                        .abs;
                        left: 214px;
                        bottom: 6px;
                        color: @6s;
                        font-size: 0;
                        span {
                            .dbi;
                            font-family: 'PingFangSC-Regular';
                            font-size: 14px;
                        }
                        .pf {
                            font-family: 'PingFangSC-Regular';
                            font-size: 18px;
                        }
                    }
                    .num {
                        .abs;
                        right: 9px;
                        bottom: 9px;
                        font-size: 12px;
                        color: @6;
                    }
                }
            }
            .all {
                .pl(21px);
                line-height: 18px;
                font-size: 10px;
                color: @6;
                border-bottom: 1px dashed @d;
                box-sizing: border-box;
                padding-bottom: 2px;
                .much {
                    .dbi;
                    .mr(4px);
                    font-size: 14px;
                    color: @6s;
                }
            }
            .button {
                clear: both;
                overflow: hidden;
                a {
                    float: right;
                    .db;
                    .w(75px);
                    .h(30px);
                    line-height: 30px;
                    .mt(10px);
                    .ml(5px);
                    .tac;
                    font-size: 14px;
                    color: @f;
                    background: @6s;
                    border-radius: 3px;
                    letter-spacing: 1px
                }
                .cancel {
                    .mr(21px);
                    background: #f1f1f1;
                    color: @6;
                }
            }
        }
    }
</style>
<template>
    <div class="my-order">
        <ul>
            <li v-bind:class="{'on': status == 0}" @click="status = 0"><a href="javascript:void(0);">全部</a></li>
            <li v-bind:class="{'on': status == 1}" @click="status = 1"><a href="javascript:void(0);">待付款</a></li>
            <li v-bind:class="{'on': status == 2}" @click="status = 2"><a href="javascript:void(0);">待发货</a></li>
            <li v-bind:class="{'on': status == 3}" @click="status = 3"><a href="javascript:void(0);">待收货</a></li>
            <li v-bind:class="{'on': status == 4}" @click="status = 4"><a href="javascript:void(0);">待评价</a></li>
        </ul>
        <div class="col" v-for="order in orders" v-if="showStatus(order.orderStatus)">
            <div class="title" v-link="{name: 'account_order_detail', params: {orderId: order.id}}">
                <h3>订单号：<span>{{order.order_no}}</span></h3>
                <span>{{order.orderStatusText}}</span><!--已完成，已发货，已取消-->
            </div>
            <div class="cont">
                <div class="details" v-for="goods in order.order_goods"
                     v-link="{name: 'account_order_detail', params: {orderId: order.id}}"><!--v-for-->
                    <div class="img">
                        <img :src="goods.stock.spec_arr | spec_array_img">
                    </div>
                    <div class="intro">
                        <h5>{{goods.goods.name}}</h5>
                        <p class="rule">{{{goods.stock.spec_arr | spec_array}}}
                        <p class="from">{{goods.goods.seller.server_num}}</p>
                        <h4>
                            {{{ goods.goods_price | priceFormatter}}}
                        </h4>
                        <p class="num">x<span>{{goods.goods_nums}}</span></p>
                    </div>
                </div>
                <p class="all">共<span class="many">{{goods_nums(order.order_goods)}}</span>件商品<span>合计：</span><span
                        class="much">￥{{order.order_amount}}</span>
                    <span>(</span>
                    <span>含运费 ￥{{order.delivery.first_price}}</span>
                    <span v-if="order.firm_type != 0">加固费 ￥{{ order.firm_type_fee }}</span>
                    <span v-if="order.if_insured == 1">保价费 ￥{{ order.insured }}</span>
                    <span>)</span>
                </p>
                <div class="button">
                    <span v-if="order.orderStatus == 2">
                        <a href="javascript:void(0);" class="butt" @click="pay(order)">支付</a>
                    </span>
                    <a href="javascript:void(0);" class="butt" @click="goPayExtra(item)"
                       v-if="order.online_recharge != [] && item.status == 0"
                       v-for="item in order.online_recharge">
                        <span v-if="item.type == 1">补运费</span>
                        <span v-if="item.type == 2">补税费</span>
                        <span v-if="item.type == 3">补差价</span>
                    </a>
                    <a href="javascript:void(0);" class="cancel" @click="cancelOrder(order)"
                       v-if=" order.orderStatus == 1 || order.orderStatus == 2">取消订单</a>
                    <a href="javascript:void(0);" class="cancel" @click="deleteOrder(order)"
                       v-if=" order.orderStatus == 5">删除订单</a>
                    <a href="javascript:void(0);" class="butt" @click="confirmOrder(order)"
                       v-if="order.orderStatus == 3">确认收货</a>
                    <a href="javascript:void(0);" class="butt" v-if="order.orderStatus == 9"
                       @click="applyRefund(order.id)" >申请退款</a><!--/ucenter/refunds_edit/order_id/$item[id]-->
                </div>
            </div>
        </div>

        <infinite-loading :distance="distance" :on-infinite="fetchOrders"></infinite-loading>

    </div>
</template>
<script>
    import EbuyFooter from '../Common/Footer.vue'
    import User from '../../utils/user'
    import Service from '../../utils/service';
    import InfiniteLoading from '../InfiniteLoading.vue'

    module.exports = {
        data: function () {
            return {
                status: 0,
                orders: [],
                payments: [],
                page: 1
            }
        },
        components: {
            InfiniteLoading
        },
        ready: function () {
        },
        methods: {
            pay: function (order) {
                Service.goPay(order.id);
            },
            goPayExtra: function (order) {
                if (order.type == 1)
                    window.$router.go({name: 'pay-freight', params: {id: order.id}});
                else if (order.type == 2)
                    window.$router.go({name: 'pay-tax', params: {id: order.id}});
                else if (order.type == 3)
                    window.$router.go({name: 'pay-price-diff', params: {id: order.id}});
            },
            fetchOrders: function () {
                var me = this;

                Service.getUserOrderList(me.page, function (response) {
                    me.$alert(response.data.message)
                }, function (response) {

                    me.orders = me.orders.concat(response.data.data);

                    if (me.page >= response.data.meta.pagination.total_pages) {
                        me.$broadcast('$InfiniteLoading:noMore');
                    } else if (response.data.data.length == 0) {
                        me.$broadcast('$InfiniteLoading:noResults');
                    }

                    me.$broadcast('$InfiniteLoading:loaded');

                    me.page++;

                })
            },
            fetchPayments: function () {
                var self = this;
                Service.getPayment(function (response) {
                    self.$alert(response.data.message)
                }, function (response) {
                    self.payments = response.data.payments;
                })
            },
            cancelOrder: function (order) {
                var self = this;
                if (confirm("取消订单?")) {
                    Service.cancelOrder(order.id, function (response) {
                        self.$alert(response.data.message)
                    }, function (response) {
                        self.fetchOrders();
                    });
                }
            },
            deleteOrder: function (order) {
                var self = this;
                if (confirm("删除订单?")) {
                    Service.deleteOrder(order.id, function (response) {
                        self.$alert(response.data.message)
                    }, function (response) {
                        self.$alert("删除成功");
                        self.fetchOrders();
                    });
                }
            },
            confirmOrder: function (order) {
                var self = this;
                if (confirm("确认收货?")) {
                    Service.confirmOrder(order.id, function (response) {
                        self.$alert(response.data.message)
                    }, function (response) {
                        self.fetchOrders();
                        //用户点击了确认收货后修改对应订单的状态
                        for(var i in self.orders){
                            if(self.orders[i].order_no==order.order_no){
                                self.orders[i].orderStatus=6;
                                self.orders[i].orderStatusText="已完成"
                            }
                        }
                    });
                }
            },
            goods_nums: function (goods) {
                var self = this;
                var num = 0;
                for (var i in goods) {
                    num += goods[i].goods_nums;
                }
                return num;
            },
            showStatus: function (orderStatus) {
                var self = this;

                switch (self.status) {
                    case 0://全部
                        return true;
                    case 1://等待付款
                        return orderStatus == 2 ? true : false;
                    case 2://带发货
                        return (orderStatus == 1 || orderStatus == 9) ? true : false;
                    case 3://待收货
                        return (orderStatus == 3 || orderStatus == 4 || orderStatus == 8 || orderStatus == 10) ? true : false;
                    case 4://待评价
                        return (orderStatus == 6) ? true : false;
                        return true;
                    default:
                        return false;
                }
            },
            applyRefund: function (order_id) {
                location.href="/account/refund/apply/" + order_id
                return;
            }
        }
    }
</script>