<style lang="less">
    @import (reference) '../../../static/css/base.less';

    .order-details {
        .title {
            .h(30px);
            line-height: 30px;
            .m(0 9px);
            h5 {
                .dbi;
                font-family: 'PingFangSC-Regular';
                font-size: 14px;
                color: @3;
            }
            span {
                float: right;
                .w(20px);
                .h(20px);
                .mt(5px);
                background: url(../../../static/images/order_down.png) center no-repeat;
                background-size: 20px;
                cursor: pointer;
            }
        }
        ul {
            border-bottom: 1px dashed @e;
            border-left: 1px solid #f1f1f1;
            box-sizing: border-box;
            .m(0 9px 0 18px);
            li {
                .rel;
                .flex;
                .p(15px 10px);
                align-items: center;
                &:last-child .icon {
                    background-color: @6s;
                }
                .icon {
                    .abs;
                    top: 41%;
                    left: -6px;
                    .w(10px);
                    .h(10px);
                    border-radius: 50%;
                    background-color: #ccc;
                }
                span, div {
                    .db;
                    font-size: 12px;
                    &:nth-child(2) {
                        .ml(15px);
                        .mr(10px);
                        width: 125px;
                        overflow: hidden;
                        white-space: nowrap;
                        text-overflow: ellipsis;
                    }
                    &:nth-child(3) {
                        flex: 1;
                        word-break: break-all
                    }
                }
            }
        }
        .order-status {
            background: @f;
            font-size: 0;
            .cons {
                .p(20px 17px);
                p {
                    font-size: 12px;
                    color: @6;
                    .mb(5px);
                    span {
                        .dbi;
                        .ml(4px);
                    }
                }
                a {
                    .dbi;
                    .w(150px);
                    .h(30px);
                    line-height: 30px;
                    .mt(20px);
                    .mr(10px);
                    font-size: 14px;
                    color: @f;
                    background: @6s;
                    border-radius: 2px;
                    .tac;
                }
            }
        }
        .infor {
            background: @f;
            .p(10px 0 10px 35px);
            p {
                .mb(5px);
                font-size: 12px;
                color: @3;
            }
        }
        .infors {
            background: @f;
            & > a {
                .flex;
                .m(0 9px);
                .p(8px 0);
                border-bottom: 1px solid @e;
                &:last-child {
                    border: none;
                }
            }
            .img-intro {
                .w(74px);
                .h(74px);
                .img;
                border: 1px solid @e;
                box-sizing: border-box;
            }
            .details-intro {
                .rel;
                flex: 1;
                .ml(18px);
                h3 {
                    font-size: 14px;
                    color: @3;
                    .lh;
                }
                h4 {
                    color: @6s;
                    span {
                        font-family: 'PingFangSC-Regular';
                        font-size: 14px;
                    }
                    .pf {
                        font-family: 'PingFangSC-Regular';
                        font-size: 18px;
                    }
                }
                & > p {
                    .db;
                    font-size: 12px;
                    color: @9;
                }
                .num {
                    .abs;
                    right: 9px;
                    bottom: 2px;
                }
            }
        }
    }

    .mint-popup {
        width: 100%;
        height: 100%;
        background-color: @f;
        overflow: auto !important;
    }
</style>
<template>
    <div class="order-details">
        <div class="title">
            <h5>订单状态</h5>
            <!-- <span></span> -->
        </div>
        <div class="order-status">
            <ul>
                <li v-for="(k, step) in order_step">
                    <span class="icon"></span>
                    <span>{{k}}</span>
                    <span>{{{step}}} <span style="color:#FF647C" v-if="step.split('运单号：')[1]"
                                           @click="viewDeliveryStatus(step.split('运单号：')[1])">->查询物流</span> </span>
                </li>
                <!-- <li><span>16-06-22</span><span>16:26</span><span>订单完成</span></li> -->
            </ul>
            <div class="cons">
                <p>订单号：<span>{{ order.order_no }}</span></p>
                <p>下单日期：<span>{{ order.create_time }}</span></p>
                <p>状态：<span>{{order.orderStatusText}}</span></p>

                <a href="javascript:void(0);" @click="cancelOrder(order)"
                   v-if=" order.orderStatus == 1 || order.orderStatus == 2">取消订单</a>

                <a href="javascript:void(0);" @click="confirmOrder(order)" v-if="order.orderStatus == 3">确认收货</a>

                <a href="javascript:void(0);" @click="applyRefund(order)" v-if="order.orderStatus == 9">申请退款</a>
                <!--{url:/ucenter/refunds_edit/order_id/$item[id]}-->

                <a href="javascript:void(0);" class="butt" @click="pay(order)" v-if="order.orderStatus == 2">立即付款</a>

                <a v-for="extraOrder in extraOrders" href="javascript:void(0);" class="butt"
                   @click="goPayExtra(extraOrder)" v-if="extraOrder.status == 0">
                    <span v-if="extraOrder.type == 1">补运费</span>
                    <span v-if="extraOrder.type == 2">补税费</span>
                    <span v-if="extraOrder.type == 3">补差价</span>
                    {{ '￥' + extraOrder.account }}
                </a>
                <!-- <a href="javascript:void(0);">确认收货</a> -->
            </div>
        </div>
        <div class="title">
            <h5>收件人信息</h5>
        </div>
        <div class="infor">
            <p>收货人：<span>{{ order.accept_name }}</span></p>
            <p>地址：<span>{{ order.address }}</span></p>
            <p>联系电话：<span>{{ order.mobile }}</span></p>
        </div>
        <div class="title">
            <h5>支付及配送方式</h5>
        </div>
        <div class="infor">
            <p>支付方式：<span>{{ order.payment.name }}</span></p>
            <p>增值服务费：￥<span>{{numToFix(order.removed_invoice_fee, order.firm_type_fee)}}</span></p>
            <p>国际运费：￥<span>{{numToFix(order.real_freight)}}</span></p>
            <p>境内运费：￥<span>{{numToFix(order.freight_fee_sum)}}</span></p>
            <p>快递单号：<span @click="viewDeliveryStatus(showDeliveryCode(order))">{{showDeliveryCode(order)}}</span></p>
        </div>
        <div class="title">
            <h5>商品清单</h5>
        </div>
        <div class="infors">
            <a href="javascript:void(0);" v-for="goods in order.order_goods">
                <div class="img-intro">
                    <img :src="goods.stock.spec_arr | spec_array_img">
                </div>
                <div class="details-intro">
                    <h3>{{goods.goods.name}}</h3>
                    <h4><span>￥</span><span class="pf">{{goods.goods_price}}</span></h4>
                    <p class="rule">{{{goods.stock.spec_arr | spec_array}}}
                    <p class="from">{{goods.goods.seller.server_num}}</p>
                    <p class="num">x<span>{{goods.goods_nums}}</span></p>
                </div>
            </a>
        </div>
        <div class="title">
            <h5>订单金额</h5>
        </div>
        <div class="infor">
            <p>商品金额：￥<span>{{order.payable_amount}}元</span></p>
            <p>运费：￥<span>{{order.payable_freight}}元</span></p>
            <p v-if="order.freight_fee_sum > 0">境内运费：￥<span>{{order.freight_fee_sum}}元</span></p>
            <p v-if="order.taxes > 0">税金：￥<span>{{order.taxes}}元</span></p>
            <p v-if="order.insured > 0">保价：<span>{{order.insured}}元</span></p>
            <p v-if="order.firm_type_fee > 0 || order.removed_invoice_fee > 0">增值服务费：￥<span>{{numToFix(order.firm_type_fee, order.removed_invoice_fee)}}元</span>
            </p>
            <p v-if="order.discount > 0">订单折扣或涨价：￥<span>{{order.discount}}元</span></p>
            <p v-if="order.promotions > 0">促销优惠金额：￥<span>{{order.promotions}}元</span></p>
            <p>订单支付金额：￥<span>{{order.order_amount}}元</span></p>
        </div>
        <mt-popup :visible.sync="popupVisible" position="right" modal="false">
            <div class="order-status">
                <ul>
                    <li v-for="status in order_deliver_status">
                        <span class="icon"></span>
                        {{{status}}}
                    </li>
                </ul>
                <div class="cons" style="text-align:center">
                    <a href="javascript:void(0);" class="butt" @click="closeDeliveryStatus()">关闭</a>
                </div>
            </div>
        </mt-popup>
    </div>
</template>
<script>

    var Vue = require('vue');

    import EbuyFooter from '../Common/Footer.vue'
    import User from '../../utils/user'
    import Service from '../../utils/service'

    import {Popup} from 'mint-ui';

    Vue.component(Popup.name, Popup);

    module.exports = {
        data: function () {
            return {
                order: {
                    payment: {}
                },
                order_step: [],
                order_deliver_status: [],
                extraOrders: [],
                popupVisible: false
            }
        },
        components: {},
        ready: function () {
            this.fetchOrderDetail(this.$route.params.orderId);
            this.fetchOrderStep(this.$route.params.orderId);
        },
        methods: {
            pay: function (order) {
                Service.goPay(order.id);
            },
            fetchOrderDetail: function (orderId) {
                var self = this;

                Service.getUserOrderInfo(orderId, function (response) {
                    self.$alert(response.data.message)
                }, function (response) {
                    console.log(response.data.data);

                    self.order = response.data.data;
                    self.extraOrders = response.data.data.online_recharge;
                })
            },
            fetchOrderStep: function (orderId) {
                var self = this;

                Service.getOrderStep(orderId, function (response) {
                    self.$alert(response.data.message)
                }, function (response) {
                    self.order_step = response.data.data;
                })
            },
            pay: function (order) {
                Service.goPay(order.id);
            },
            goPayExtra: function (order) {
                if (order.type == 1) {
                    window.$router.go({name: 'pay-freight', params: {id: order.id}});
                } else if(order.type== 2) {
                    window.$router.go({name: 'pay-tax', params: {id: order.id}});
                } else {
                    window.$router.go({name: 'pay-price-diff', params: {id: order.id}});
                }
            },
            cancelOrder: function (order) {
                var self = this;
                if (confirm("是否取消订单?")) {
                    Service.cancelOrder(order.id, function (response) {
                        self.$alert(response.data.message)
                    }, function (response) {
                        window.location.reload();
                    });
                }
            },
            confirmOrder: function (order) {
                var self = this;
                if (confirm("是否确认收货？")) {
                    Service.confirmOrder(order.id, function (response) {
                        self.$alert(response.data.message)
                    }, function (response) {
                        window.location.reload();
                    });
                }
            },
            applyRefund: function (order) {
                location.href="/account/refund/apply/" + order.id
                return;
            },
            numToFix: function (a, b = 0) {
                var r = Number(a) + Number(b)
                return r.toFixed(2);
            },
            showDeliveryCode: function (order) {
                var delivery_code = '';
                for (var i in order.order_goods) {
                    if (order.order_goods[i].delivery_doc) {
                        delivery_code = delivery_code + order.order_goods[i].delivery_doc.delivery_code + "";
                    } else {
                        delivery_code = '尚未发货';
                    }
                }
                return delivery_code;
            },
            viewDeliveryStatus: function (code) {
                var me = this;
                me.popupVisible = true;
                // 加载物流信息
                Service.getOrderDeliverStatus(me.order.id, code, null, function (response) {
                    me.order_deliver_status = response.data.data;
                });
            },
            closeDeliveryStatus: function () {
                this.popupVisible = false;
            }

        }
    }
</script>