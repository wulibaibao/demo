<style lang="less">
    @import (reference) '../../../static/css/base.less';

    .change-pwd-module {
        .sign-pos {
            .m(67px 16px 22px);
        }
        input[type="password"] {
            .db;
            .w(100%);
            .h(20px);
            .mt(23px);
            line-height: 20px;
            font-size: 14px;
            .p(10px 0);
            color: @9;
            border: none;
            background: transparent;
            border-bottom: 1px solid @d
        }
    }
</style>
<template>
    <form class="change-pwd-module" autocomplete="on" onsubmit="return false;">
        <div class="sign-pos">
            <input type="password" v-model="data.oldPassword" placeholder="请输入原密码">
            <input type="password" v-model="data.newPassword" placeholder="请设置您的新密码，6-32字符">
            <input type="password" v-model="data.newPassword2" placeholder="请再次确认新密码">
        </div>
        <div class="ebuy-pay-button">
            <button class="ebuy-go-pay" @click="editPassword">确认修改</button>
        </div>
    </form>
</template>
<script>
    import User from '../../utils/user'
    import Service from '../../utils/service'
    module.exports = {
        data: function () {
            return {
                data: {}
            }
        },
        methods: {
            editPassword: function () {
                var self = this;

                if (this.data.newPassword != this.data.newPassword2) {
                    self.$alert('两次密码输入不一致');

                    return;
                }

                Service.changePassword(this.data.oldPassword, this.data.newPassword, function (response) {
                    self.$alert(response.data.message)
                }, function (response) {
                    self.$alert('修改成功');

                    window.$router.replace(window.history.back())
                })
            }
        }
    }
</script>