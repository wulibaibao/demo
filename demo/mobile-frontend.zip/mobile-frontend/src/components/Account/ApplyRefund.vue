<style lang="less">
    @import (reference) '../../../static/css/base.less';
    .app-ref {
        background: @f;
        .pb(50px);
        label {
            font-size: 12px;
            .pl(20px);
            color: @3;
            background: url(../../../static/images/circle.png) left center no-repeat;
            background-size: 15px;
        }
        .label-chk {
            font-size: 14px;
            color: @6;
            background: url(../../../static/images/goods_selected.png) left center no-repeat;
            background-size: 16px;
            .p(2px 0 2px 24px);
        }
        .label-unchk {
            font-size: 14px;
            color: @6;
            background: url(../../../static/images/circle.png) left center no-repeat;
            background-size: 16px;
            .p(2px 0 2px 24px);
        }
        input[type=radio]{
            .none
        }
        &>h3 {
            .p(0 9px);
            background: #f1f1f1;
            .h(30px);
            line-height: 30px;
            font-size: 14px;
            color: @6;
        }
        .chs-ref {
            .m(10px 9px 5px);
            border-bottom: 1px solid @e;
            &>p {
                font-size: 14px;
                color: @3;
                .mb(15px);
            }
        }
        .jud-exp {
            .m(0 16px);
            font-size: 10px;
            color: @9;
        }
        .chs-which {
            .flex;
            .chs-cont {
                flex:1;
            }
        }
        .chs-cont {
            .cont-flex {
                .flex;
                .img {
                    .w(72px);
                    .h(72px);
                    .img;
                    .ml(12px);
                    .mr(15px);
                    border: 1px solid @e;
                    box-sizing: border-box;
                }
                .det {
                    .rel;
                    flex:1;
                    h4 {
                        color: @6s;
                        span {
                            font-family: 'PingFangSC-Regular';
                            font-size: 14px;
                        }
                        .pf {
                            font-family: 'PingFangSC-Regular';
                            font-size: 18px;
                        }
                    }
                    h5 {
                        .h(35px);
                        font-size: 14px;
                        color: @3;
                        overflow: hidden;
                    }
                    p {
                        font-size: 10px;
                        color: @6;
                    }
                    h6 {
                        .abs;
                        font-size: 12px;
                        color: @6;
                        bottom: 9px;
                        right: 9px;
                    }
                }
            }
        } 
        .ref-details {
            .m(6px 9px 44px);
            p {
                .p(4px 30px);
                font-size: 14px;
                color: @3;
                border-bottom: 1px dashed @e;
                span {
                    float: right;
                    font-size: 14px;
                    color: @6s;
                }
                .way {
                    color: @3;
                }
            }
        }
    }
</style>
<template>
    <div class="empty-bg"></div>
    <div class="app-ref">
        <h3>订单号：<span>{{order.order_no}}</span></h3>
        <div class="chs-ref">
            <p>选择退款商品：</p>
            <div class="chs-which" v-for="goods in order.order_goods">
                <div class="chs-pac" v-if="goods.is_send == 0">
                    <input type="radio" id="FF_{{goods.id}}" value="{{goods.id}}" v-model="refund.order_goods_id" v-if="">                  
                    <label for="FF_{{goods.id}}" id="chk_{{goods.id}}"
                           v-bind:class="{'label-chk': goods.selected == 1,'label-unchk': goods.selected != 1 }"
                           @click="calc_refund(goods)"></label>
                </div>
                <div class="chs-cont" v-if="goods.is_send == 0">
                    <div class="cont-flex">
                        <div class="img"><img :src="goods.stock.spec_arr | spec_array_img"></div>                       
                        <div class="det">
                            <h5>{{goods.selected}}</h5>
                            <!-- <h5>{{goods.goods.name}}</h5> -->
                            <p>{{goods.goods.seller.server_num}}</p>
                            <h4><span>￥</span><span class="pf">{{goods.goods_price}}</span><span>.</span><span>1</span></h4>
                            <h6>x{{goods.goods_nums}}</h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>  
        <div class="ref-details">
            <p>退款金额：<span>{{data.refund_amount}}</span></p>
            <!-- <p>退款方式：<span class="way"></span></p> -->
        </div>
        <div class="ref-details">
            <p>退款理由<span><select id="refund_content">
                <option value="手误买错了">手误买错了</option>
                <option value="我突然不想买了">我突然不想买了</option>
            </select></span></p>
        </div>
        <div class="ebuy-pay-button">
            <a href="javascript:void(0);" class="ebuy-go-pay" @click="applyRefund()">申请退款</a>
        </div>
        <p class="jud-exp">根据第三方支付相应规定，申请退款到账将会由一定延迟！</p>
    </div>
</template>
<script>

    var Vue = require('vue');

    import EbuyFooter from '../Common/Footer.vue'
    import User from '../../utils/user'
    import Service from '../../utils/service'

    import {Popup} from 'mint-ui';

    Vue.component(Popup.name, Popup);

    module.exports = {
        data:function() {
            return {
                data: {refund_amount:0,
                },
                order:{},
                order_goods:{},
            }
        },
        ready: function () {
            this.fetchOrderDetail(this.$route.params.orderId);
        },
        methods: {
            fetchOrderDetail: function (orderId) {
                var self = this;

                Service.getUserOrderInfo(orderId, function (response) {
                    self.$alert(response.data.message)
                }, function (response) {
                    self.order = response.data.data;
                    self.order_goods = response.data.data.order_goods;
                })
            },            
            applyRefund: function () {
                var self = this;
                var parameters = {order_id:self.order.id, order_goods_id:[], content:''}

                parameters.content = $("#refund_content").val();

                for (var i in self.order_goods) {
                    if(self.order_goods[i].selected == 1){
                        parameters.order_goods_id.push(self.order_goods[i].id)

                    }
                }

                if(parameters.order_goods_id.length == 0){
                    this.$alert('请选择要退款的商品 :)');
                    return;
                }

                Service.appleRefund(parameters, function (response) {
                    self.$alert(response.data.message)
                }, function (response) {
                    window.$router.go({name: 'account_refund', activeClass: 'alive', exact: true});
                });
            },
            calc_refund: function (goods) {
                console.log("goods.id"+goods.id)
                var self = this;
                var data = [];
                var refunded = 0;//正在/已退款金额
                var refund = 0;//本次申请退款金额
                var all_refund = 1;
                for (var i in self.order_goods) {
                    if(self.order_goods[i].is_send == 2 || self.order_goods[i].is_send == 3){
                        refunded += self.order_goods[i].goods_nums*self.order_goods[i].goods_price;
                        all_refund = 0;
                        continue;
                    }

                    if (self.order_goods[i].id == goods.id) {
                        if(self.order_goods[i].selected == 1){
                            self.order_goods[i].selected = 0
                            $("#chk_" + goods.id).attr("class", "label-unchk");
                        } else {
                            self.order_goods[i].selected = 1;
                            $("#chk_" + goods.id).attr("class", "label-chk");
                        }
                    }

                    if(self.order_goods[i].selected == 1){
                        refund += self.order_goods[i].goods_nums*self.order_goods[i].goods_price;
                    } else {
                        all_refund = 0;
                    }
                }
                if(all_refund == 1 && Number(refunded) == 0){
                    self.data.refund_amount = Number(self.order.order_amount).toFixed(2);
                } else {
                    self.data.refund_amount = Number(refund).toFixed(2);
                }
            },
        }
    }
</script>   