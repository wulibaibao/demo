<style lang="less">
    @import (reference) '../../../static/css/base.less';

    .my-collect {
        .pb(50px);
        .title {
            .h(30px);
            line-height: 30px;
            .m(0 9px);
            background: #f1f1f1;
            h3 {
                float: left;
                font-size: 14px;
                color: @6;
                span {
                    .dbi;
                    .ml(3px);
                }
            }
            span {
                float: right;
                font-size: 13px;
                color: @6;
            }
        }
        .cont {
            background: @f;
            .p(10px 9px);
            .details {
                .rel;
                .flex;
                border-bottom: 1px solid @e;
                box-sizing: border-box;
                .pb(10px);
                .img {
                    .rel;
                    .w(74px);
                    .h(74px);
                    .mr(15px);
                    border: 1px solid @e;
                    .img;
                    box-sizing: border-box;
                    .saled {
                        display:none;
                        .abs;
                        .flexcenter;
                        left: 0;
                        top: 0;
                        .w(100%);
                        .h(100%);
                        font-size: 18px;
                        color: @f;
                        background: rgba(0, 0, 0, .4);
                        letter-spacing: 3px
                    }
                }
                .intro {
                    flex: 1;
                    h5 {
                        .h(38px);
                        line-height: 18px;
                        font-size: 14px;
                        color: @3;
                        .lh;
                    }
                    .cheaper {
                        font-size: 12px;
                        color: @6s;
                        .pt(20px);
                        span {
                            .ml(3px);
                        }
                    }
                    h4 {
                        .abs;
                        right: 9px;
                        bottom: 6px;
                        color: @6s;
                        span {
                            font-family: 'PingFangSC-Regular';
                            font-size: 14px;
                        }
                        .pf {
                            font-family: 'PingFangSC-Regular';
                            font-size: 18px;
                        }
                    }
                }
            }
            .all {
                .pl(21px);
                .h(30px);
                line-height: 30px;
                font-size: 10px;
                color: @6;
                border-bottom: 1px dashed @9;
                box-sizing: border-box;
                .much {
                    .dbi;
                    .mr(4px);
                    font-size: 14px;
                    color: @6s;
                }
            }
            .button {
                clear: both;
                overflow: hidden;
                a {
                    float: right;
                    .db;
                    .w(21px);
                    .h(21px);
                    line-height: 30px;
                    .mt(10px);
                    .tac;
                    color: @f;
                    background: @6s;
                }
                .collect-img {
                    .mr(30px);
                    background: url(../../../static/images/collect.png) center no-repeat;
                    background-size: 21px;
                }
                .buycar-img {
                    background: url(../../../static/images/col_buycar.png) center no-repeat;
                    background-size: 21px;
                }
            }
        }
    }
</style>
<template>
    <div class="my-collect">
        <div class="col" v-for="item in favorites" v-if="item.goods">
            <div class="title">
                <h3>[{{ item.goods.seller.server_num}}]</h3>
                <span>收藏时间：{{ item.time }}</span><!--已完成，已发货，已取消-->
            </div>
            <div class="cont">
                <div class="details" v-link="{ name: 'goods-detail', params: { goodsId: item.goods.stock_id }}">
                    <!--v-for-->
                    <div class="img">
                        <img :src="item.goods.img | thumb">
                        <!--售罄弹窗-->
                        <p class="saled" v-show="!item.goods.store_nums">售罄</p>
                    </div>
                    <div class="intro">
                        <h5>{{ item.goods.name }}</h5>
                        <!--<p class="cheaper">比收藏时降价<span>1</span>元</p>-->
                        <h4>
                            {{{ item.goods.sell_price | priceFormatter }}}
                        </h4>
                    </div>
                </div>
                <div class="button">
                    <a href="javascript:void(0);" class="buycar-img" v-link="{ name: 'goods-detail', params: { goodsId: item.goods.stock_id }}"></a>
                    <a href="javascript:void(0);" class="collect-img" v-on:click="cancelFav(item)"></a>
                </div>
            </div>
        </div>
        <infinite-loading :distance="distance" :on-infinite="getFavorites"></infinite-loading>
    </div>
    <favorites-empty v-show="showEmpty"></favorites-empty>
</template>
<script>
    import Service from '../../utils/service'
    import InfiniteLoading from '../InfiniteLoading.vue'
    import FavoritesEmpty from './FavoritesEmpty.vue'

    module.exports = {
        components: {
            InfiniteLoading,
            FavoritesEmpty
        },
        data: function () {
            return {
                favorites: [],
                page: 1,
                showEmpty: false,
            }
        },
        ready: function () {

        },
        methods: {
            getFavorites(){
                var me = this;

                Service.getFavorites(me.page, null, function (response) {
                    me.favorites = me.favorites.concat(response.data.data);

                    me.showEmpty = !me.favorites.length;

                    if (me.page >= response.data.meta.pagination.total_pages) {
                        console.log("noMore");
                        me.$broadcast('$InfiniteLoading:noMore');
                    } else if (response.data.data.length == 0) {
                        me.$broadcast('$InfiniteLoading:noResults');
                    }

                    me.$broadcast('$InfiniteLoading:loaded');

                    me.page++;
                });


            },
            cancelFav(favorite) {
                var me = this;
                // 取消收藏操作
                Service.unFavGoods(favorite.goods.id, null, function (response) {
                    me.favorites.$remove(favorite);
                });
            }
        }
    }
</script>