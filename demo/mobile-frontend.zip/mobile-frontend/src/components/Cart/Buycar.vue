<style lang="less">
    @import (reference) '../../../static/css/base.less';
    .buy-car {
        .pb(50px);
        label, .label-chk {
            font-size: 14px;
            color: @6;
            background: url(../../../static/images/goods_selected.png) left center no-repeat;
            background-size: 16px;
            .p(2px 0 2px 24px);
        }
        .label-unchk {
            font-size: 14px;
            color: @6;
            background: url(../../../static/images/circle.png) left center no-repeat;
            background-size: 16px;
            .p(2px 0 2px 24px);
        }

        input[type="checkbox"] {
            .none
        }
        .pay-fixed {
            .fix;
            left: 0;
            bottom: 0;
            .w(100%);
            .h(49px);
            line-height: 49px;
            background: @f;
            font-size: 14px;
            color: @6;
            z-index: 1001;
            .left {
                float: left;
                .ml(9px);
            }
            .right {
                float: right;
                .tit {
                    float: left;
                    .mr(10px);
                    p {
                        line-height: 15px;
                        .mt(7px);
                    }
                }
                .pay {
                    float: right;
                    .db;
                    .w(80px);
                    .h(49px);
                    line-height: 49px;
                    .tac;
                    font-size: 15px;
                    color: @f;
                    background: @6s;
                    letter-spacing: 1px;
                    span {
                        font-size: 14px
                    }
                }
                .pay-not {
                    border: 1px solid @d;
                    background: #f1f1f1;
                    color: @9;
                    box-sizing: border-box
                }
            }
            .amount {
                font-size: 14px;
                color: @3;
                span {
                    color: @6s;
                }
            }
            .say {
                font-size: 12px;
                color: @9;
                text-align: right;
            }
        }
        .con {
            background: @f;
            .mb(9px);
        }
        .title {
            .h(30px);
            line-height: 30px;
            .m(0 9px);
            border-bottom: 1px solid @e;
            box-sizing: border-box;
            clear: both;
            overflow: hidden;
            .l {
                float: left;
            }
            .r {
                float: right;
                font-size: 12px;
                color: @6;
                a {
                    border-left: 1px solid @9;
                    .pl(10px);
                }
            }
        }
        .cont {
            .flex;
            .p(8px 0 10px);
            .m(0 9px);
            border-bottom: 1px solid #e1e1e1;
            box-sizing: border-box;
            & > .chec {
                .mt(15px);
            }
        }
        .img {
            .db;
            .w(74px);
            .h(74px);
            .img;
        }
        .col {
            .db;
            .rel;
            flex: 1;
            .pl(15px);
            h3 {
                .h(38px);
                line-height: 18px;
                font-size: 14px;
                color: @3;
                .lh;
            }
            .rule {
                font-size: 12px;
                color: @6;
                .m(5px 0 0);
                & > span {
                    .dbi;
                    .ml(2px);
                }
            }
            .price {
                font-size: 10px;
                color: @6;
            }
            h4 {
                color: @6s;
                span {
                    font-family: 'PingFangSC-Regular';
                    font-size: 14px;
                }
                .pf {
                    font-family: 'PingFangSC-Regular';
                    font-size: 18px;
                }
            }
            .num-show {
                .abs;
                right: 9px;
                bottom: -1px;
                font-size: 12px;
                color: @6;
            }
        }
        .cols {
            flex: 1;
            font-size: 0;
        }
        .edi {
            .dbi;
            .m(30px 25px 0 15px);
            font-size: 12px;
            color: @6;
        }
        .change-num {
            .dbi;
            font-size: 0;
            & > a {
                .dbi;
                .w(23px);
                .h(23px);
                line-height: 20px;
                font-size: 12px;
                border: 1px solid @6;
                border-radius: 50%;
                .tac;
                vertical-align: top;
            }
            input[type=text] {
                .dbi;
                .w(49px);
                .h(23px);
                .m(0 10px);
                font-size: 14px;
                line-height: 23px;
                .p(11px 0);
                .tac;
            }
        }
        .delete {
            float: right;
            .dbi;
            .w(50px);
            .h(84px);
            .mt(-8px);
            line-height: 84px;
            font-size: 14px;
            color: @f;
            .tac;
            background: @6s;
        }
        .print {
            .h(40px);
            line-height: 40px;
            .ml(23px);
            font-size: 10px;
            color: @9;
        }
        .all {
            .db;
            .rel;
            top: 0px;
            right: 9px;
            .p(8px 0);
            text-align: right;
            .num {
                font-size: 14px;
                color: @3;
                & > span {
                    color: @6s;
                }
            }
            .del {
                font-size: 12px;
                color: @6;
            }
        }
    }
</style>
<template>
    <cart-empty></cart-empty>
    <ebuy-chat></ebuy-chat>
    <div class="buy-car">
        <div class="con" v-for="seller in sellers">
            <div class="title" v-if="show_sellers[seller.id] == 1">
                <div class="l">
                    <input type="checkbox" id="checkbox1" v-model="Where">
                    <label for="checkbox"
                           v-bind:class="{'label-chk': seller.selected_all == 1,'label-unchk': seller.selected_all != 1 }"
                           @click="selectSeller(seller)">{{(seller.server_num)}}</label>
                </div>
                <div class="r">
                    <a href="javascript:void(0);" @click="sellerEdit(seller, 1)" v-if="edit_btn[seller.id] == 0">编辑</a>
                    <a href="javascript:void(0);" @click="sellerEdit(seller, 0)" v-if="edit_btn[seller.id] == 1">保存</a>
                </div>
            </div>
            <div class="cont" v-for="cart in carts" v-if="seller.id == cart.goods_info.seller_id">
                <!--同一个seller id  下的-->
                <div class="chec">
                    <input type="checkbox" id="checkbox2" v-model="Where">
                    <label for="checkbox"
                           v-bind:class="{'label-chk': cart.selected == 1,'label-unchk': cart.selected != 1 }"
                           @click="selectCart(cart)"></label>
                </div>
                <a href="javascript:void(0);" class="img"
                   v-link="{ name: 'goods-detail', params: { goodsId: cart.stockInfo.id }}">
                    <img :src="cart.stockInfo.specification_array | spec_array_img">
                </a>
                <!--未编辑状态-->
                <a href="javascript:void(0);" class="col" v-if="edit_btn[seller.id] == 0"
                   v-link="{ name: 'goods-detail', params: { goodsId: cart.stockInfo.id }}">
                    <h3>{{cart.goods_info.name}}</h3>
                    <p class="rule">{{{cart.stockInfo.specification_array | spec_array}}}</p>
                    <!-- <p class="price">参考价：￥<span>{{cart.stockInfo.market_price}}</span></p> -->
                    <h4><span>￥</span><span
                            class="pf">{{ cart.stockInfo.sell_price.toString().split('.')[0] }}</span><span>.</span><span>{{ cart.stockInfo.sell_price.toString().split('.')[1]}}</span>
                    </h4>
                    <span class="num-show">x{{cart.num}}</span>
                </a>
                <!--未编辑状态结束-->
                <!--编辑状态-->
                <div class="cols" v-if="edit_btn[seller.id] == 1">
                    <p class="edi">数量</p>
                    <div class="change-num">
                        <a href="javascript:void(0);" @click="reduceNum(cart.sku)">-</a>
                        <input type="text" id="num_{{cart.sku}}" value="{{cart.num}}">
                        <span class=""></span>
                        <a href="javascript:void(0);" @click="addNum(cart.sku)">+</a>
                    </div>
                    <a href="javascript:void(0);" class="delete" @click="destroyCart(cart)">删除</a>
                </div>
                <!--编辑状态结束-->
            </div>
            <div class="pri-con" v-if="show_sellers[seller.id] == 1">
                <p class="print" v-if="reachAmount(seller) > 0"><span v-if="seller.seller_sum">每单最低消费金额为￥{{seller.low_consume}}，需再购买￥{{reachAmount(seller)}}商品</span>
                </p>
                <div class="all">
                    <p class="num">合计：<span>￥{{sellerAmount(seller)}}</span></p>
                    <p class="del" v-if="seller.freight_fee">境内运费￥{{seller.freight_fee}}</p>
                </div>
            </div>
        </div>
        <div class="pay-fixed">
            <div class="left">
                <input type="checkbox" id="checkbox3" v-model="SelectAll">
                <label for="checkbox" id="checkbox4"
                       v-bind:class="{'label-chk': total_num > 0,'label-unchk': total_num == 0 }"
                       @click="selectAll(total_num)">全选</label>
            </div>
            <div class="right">
                <div class="tit">
                    <p class="amount">合计：<span>￥{{total_sum}}</span></p>
                    <p class="say">不含运费</p>
                </div>
                <a href="javascript:void(0);" @click="checkout()"
                   class="pay" v-if="can_order && can_delivery && total_num">结算(<span>{{total_num}}</span>)</a>
                <a href="javascript:void(0);" class="pay pay-not" @click="confirm_alert()"
                   v-if="!can_order || !can_delivery  || !total_num">结算(<span>{{total_num}}</span>)</a>
            </div>
        </div>
    </div>
</template>
<script>
    import EbuyFooter from '../Common/Footer.vue'
    import EbuyChat from '../Common/ChatBubble.vue'
    import CartEmpty from '../Cart/Buycar_empty.vue'
    import User from '../../utils/user'
    import Service from '../../utils/service'

    var edit_btn = [];
    module.exports = {
        data: function () {
            return {
                total_sum: 0,
                total_num: 0,
                refresh_push: [],
                edit_btn: [],
                // Where:false,
                // SelectAll:false,
                // order_num:1, 
                can_order: 1,
                can_delivery: 1,
                status: 0,
                sellers: [],
                show_sellers: [],
                carts: []
            }
        },
        components: {
            CartEmpty,
            EbuyChat
        },
        ready: function () {
            this.fetchCart();
            // this.fetchSeller();
        },
        methods: {
            // fetchSeller: function (status = 0) {
            //     var self = this;
            //     console.log("total_num:"+self.total_num)
            //     self.status = status;

            //     Service.getSeller(Service.defaultFailureHandler, function (response) {
            //         self.sellers = response.data.sellers
            //     })
            // }, 
            fetchCart: function (status) {
                var self = this;
                self.status = status;
                Service.getUserCartList(Service.defaultFailureHandler, function (response) {

                    if (!response.data.data) {
                        $('.empty-cart').css('display', 'block');

                        return;
                    }

                    self.carts = response.data.data.cart.content.goods;
                    self.sellers = response.data.data.sellers;
                    self.can_order = response.data.data.can_order;
                    self.can_delivery = response.data.data.can_delivery;
                    self.total_num = response.data.data.total_num;
                    self.total_sum = response.data.data.total_sum;
                    self.show_sellers = [];
                    for (var i in self.carts) {
                        var seller_id = self.carts[i].goods_info.seller_id
                        for (var j in self.sellers) {
                            self.sellers[j].edit = 0;//init 
                            if (self.sellers[j].id == seller_id) {
                                self.show_sellers[seller_id] = 1;
                                if (self.edit_btn[seller_id] == undefined) self.edit_btn[seller_id] = 0;
                            }
                        }
                    }
                    if (!self.show_sellers.length) {
                        $('.empty-cart').css('display', 'block');
                    }
                })
            },
            selectCart: function (cartObj) {
                var self = this;
                var parameters = {};
                parameters.sku = cartObj.sku
                parameters.productId = cartObj.goods_id
                parameters.num = cartObj.num
                parameters.selected = cartObj.selected ? false : true;

                Service.selectCart(parameters, function (response) {
                    self.$alert(response.data.message)
                }, function (response) {
                    self.fetchCart();
                });
            },
            selectSeller: function (seller) {
                var self = this;
                var parameters = {}
                var data = [];

                for (var i in self.carts) {
                    if (seller.id == self.carts[i].goods_info.seller_id) {
                        var temp = {}
                        temp.productId = self.carts[i].goods_id
                        temp.sku = self.carts[i].sku
                        temp.num = self.carts[i].num
                        temp.selected = seller.selected_all ? false : true;
                        data.push(temp)
                    }
                }
                parameters.data = data;
                Service.selectSeller(parameters, function (response) {
                    self.$alert(response.data.message)
                }, function (response) {
                    self.fetchCart();
                });
            },
            selectAll: function (total_num) {
                var self = this;
                var parameters = {}
                var data = [];
                for (var s in self.sellers) {
                    for (var i in self.carts) {
                        if (self.sellers[s].id == self.carts[i].goods_info.seller_id) {
                            var temp = {}
                            temp.productId = self.carts[i].goods_id
                            temp.sku = self.carts[i].sku
                            temp.num = self.carts[i].num
                            temp.selected = total_num ? 0 : 1;
                            data.push(temp)
                        }
                    }
                }
                parameters.data = data;
                Service.selectSeller(parameters, function (response) {
                    self.$alert(response.data.message)
                }, function (response) {
                    self.fetchCart();
                });
            },
            sellerEdit: function (seller, edit) {
                var self = this;
                for (var i in self.sellers) {
                    if (seller.id == self.sellers[i].id) {
                        edit_btn = self.edit_btn;
                        self.edit_btn = [];
                        edit_btn[seller.id] = edit;
                        self.edit_btn = edit_btn;
                        // console.log(edit_btn)
                    }
                }
                //ajax update data
                console.log("edit:" + edit)
                if (edit == 0) {
                    var parameters = {}
                    var data = []
                    for (var i in self.carts) {
                        if (seller.id == self.carts[i].goods_info.seller_id) {
                            var temp = {}
                            temp.productId = self.carts[i].goods_id
                            temp.sku = self.carts[i].sku
                            temp.selected = self.carts[i].selected
                            temp.num = $("#num_" + self.carts[i].sku).val()
                            data.push(temp)
                        }
                    }

                    parameters.data = data;
                    console.log(data)
                    Service.selectSeller(parameters, function (response) {
                        self.$alert(response.data.message)
                    }, function (response) {
                        self.fetchCart();
                    });

                }
                console.log(self.edit_btn)
            },
            reachAmount: function (seller) {
                var self = this;
                var sell_price = seller['seller_sum'];
                var reach_price = seller.low_consume - sell_price;
                if (reach_price > 0) {
                    return Number(reach_price).toFixed(2);
                } else {
                    return 0;
                }
            },
            sellerAmount: function (seller) {
                var self = this;
                var sell_price = 0;
                for (var i in self.carts) {
                    if (self.carts[i].goods_info.seller_id == seller.id) {
                        if (self.carts[i].selected) {
                            sell_price += self.carts[i].stockInfo.sell_price * self.carts[i].num
                        }
                    }
                }
                sell_price = Number(sell_price)
                return sell_price.toFixed(2);
            },
            addNum: function (sku) {
                var num = $("#num_" + sku).val();
                $("#num_" + sku).val(++num);
            },
            reduceNum: function (sku) {
                var num = $("#num_" + sku).val();
                $("#num_" + sku).val(--num);
            },
            destroyCart: function (cart) {
                var self = this;
                if (confirm("删除?")) {
                    Service.destroyCart(cart.sku, function (response) {
                        self.$alert(response.data.message)
                    }, function (response) {
                        self.fetchCart();
                        return false;
                    });
                }
            },
            confirm_order: function (cart) {
                var self = this;
                if (confirm("删除?")) {
                    Service.destroyCart(cart.sku, function (response) {
                        self.$alert(response.data.message)
                    }, function (response) {
                        self.fetchCart();
                    });
                }
            },
            confirm_alert: function () {
                var self = this;
                if (!self.can_order) {
                    self.$alert("不满足最低消费金额")
                } else if (!self.can_delivery) {
                    self.$alert("不同来源商家的商品无法同时下单")
                } else if (!self.total_num) {
                    self.$alert("请选择商品")
                }

            },
            checkout: function () {
                localStorage.setItem('cache_confirm_order_tag', 0);
                window.$router.go({name: 'confirm-order', activeClass: 'alive', exact: true});
            }

        }

    }
</script>