<style lang="less">
    @import (reference) '../../../static/css/base.less';
    html {
        background: white;
    }
    .extra-details {
        .title {
            .h(30px);
            line-height: 30px;
            .m(0 9px);
            h5 {
                .dbi;
                font-family: 'PingFangSC-Regular';
                font-size: 14px;
                color: @3;
            }
            span {
                float: right;
                .w(20px);
                .h(20px);
                .mt(5px);
                background: url(../../../static/images/order_down.png) center no-repeat;
                background-size: 20px;
                cursor: pointer;
            }
        }
        ul {
            border-bottom: 1px dashed @e;
            border-left: 1px solid #f1f1f1;
            box-sizing: border-box;
            .m(0 9px 0 18px);
            li {
                .rel;
                .flex;
                .p(15px 10px);
                align-items: center;
                &:last-child .icon {
                    background-color: @6s;
                }
                .icon {
                    .abs;
                    top: 41%;
                    left: -6px;
                    .w(10px);
                    .h(10px);
                    border-radius: 50%;
                    background-color: #ccc;
                }
                span,div {
                    .db;
                    font-size: 12px;
                    &:nth-child(2) {
                        .ml(15px);
                        .mr(10px);
                        width: 125px;
                        overflow: hidden;
                        white-space: nowrap;
                        text-overflow: ellipsis;
                    }
                    &:nth-child(3) {
                        flex: 1;
                        word-break: break-all
                    }
                }
            }
        }
        .order-status {
            background: @f;
            font-size: 0;
            .cons {
                line-height: 30px;
                .p(20px 17px);
                p {
                    font-size: 14px;
                    color: @6;
                    .mb(5px);
                    span {
                        .dbi;
                        .ml(4px);
                    }
                }
                a {
                    .dbi;
                    .w(100%);
                    .h(40px);
                    line-height: 40px;
                    .mt(20px);
                    .mr(10px);
                    font-size: 15px;
                    color: @f;
                    background: @6s;
                    border-radius: 2px;
                    .tac;
                }
                .tip {
                    color: @9;
                    font-size:12px;
                }
            }
        }
        .infor {
            background: @f;
            .p(10px 0 10px 35px);
            p {
                .mb(5px);
                font-size: 12px;
                color: @3;
            }
        }
        .infors {
            background: @f;
            & > a {
                .flex;
                .m(0 9px);
                .p(8px 0);
                border-bottom: 1px solid @e;
                &:last-child {
                    border: none;
                }
            }
            .img-intro {
                .w(74px);
                .h(74px);
                .img;
                border: 1px solid @e;
                box-sizing: border-box;
            }
            .details-intro {
                .rel;
                flex: 1;
                .ml(18px);
                h3 {
                    .h(42px);
                    font-size: 14px;
                    color: @3;
                    .lh;
                }
                h4 {
                    .mt(13px);
                    color: @6s;
                    span {
                        font-family: 'PingFangSC-Regular';
                        font-size: 14px;
                    }
                    .pf {
                        font-family: 'PingFangSC-Regular';
                        font-size: 18px;
                    }
                }
                & > p {
                    .db;
                    font-size: 12px;
                    color: @9;
                }
                .num {
                    .abs;
                    right: 9px;
                    bottom: 2px;
                }
            }
        }
    }

</style>
<template>
    <ebuy-gohome></ebuy-gohome>
    <ebuy-chat></ebuy-chat>
    <div class="extra-details">
        <div class="order-status">
            <div class="cons">
                <p>订单号：<span>{{ order.order.order_no }}</span></p>
                <p>下单时间：<span>{{ order.order.create_time }}</span></p>
                <p>缴税原因：<span>被海关收税</span></p>
                <p>合计金额：<span>￥{{ order.account }}</span></p>
                <p>状态：<span>{{ (order.status ==1 ) ? '已支付 ('+ order.payment_name + ')' : '未支付' }}</span></p>

                <p class="tip" v-show="order.status == 0">说明:为了保证您正常收到包裹，请及时支付。</p>
                <a href="javascript:void(0);" class="butt" v-show="order.status == 0" @click="payExtra(order)">立即支付</a>
            </div>
        </div>
    </div>
</template>
<script>

    var Vue = require('vue');

    import EbuyFooter from '../Common/Footer.vue'
    import User from '../../utils/user'
    import Service from '../../utils/service'
    import EbuyGohome from '../Common/ReturnhomeBubble.vue'
    import EbuyChat from '../Common/ChatBubble.vue'

    module.exports = {
        data: function () {
            return {
                order: {
                    order : {
                        order_no : '',
                        create_time : ''
                    },
                    items : {
                        taxes : ''
                    },
                    account : '',
                    status : 1
                }
            }
        },
        components: {
            EbuyGohome,
            EbuyChat
        },
        ready: function () {
            this.fetchOrderDetail(this.$route.params.id);
        },
        methods: {
            fetchOrderDetail: function (orderId) {
                var self = this;

                Service.getExtraOrderInfo(orderId, function (response) {
                    self.$alert(response.data.message)
                }, function (response) {
                    self.order = response.data.data;
                })
            },
            payExtra: function (order) {
                Service.goExtraPay(order.id);
            }
        }
    }
</script>