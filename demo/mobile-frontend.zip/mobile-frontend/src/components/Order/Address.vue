<style lang="less">
    @import (reference) '../../../static/css/base.less';
    .rec-add-2 {
        .normalAddress {
            .db;
            font-size: 12px;
            .pl(20px);
            .mt(10px);
            color: @3;
            background: url(../../../static/images/circle.png) left center no-repeat;
            background-size: 15px;
            text-indent: -99999px;
            cursor: pointer;
        }
        .special-bg {
            background: url(../../../static/images/circle_selected.png) left center no-repeat;
            background-size: 15px;
        }
        input[type=radio] {
            .none
        }
        h3 {
            .pl(9px);
            .mb(5px);
            .h(30px);
            line-height: 30px;
            font-size: 14px;
            color: @3;
            background: @f;
        }
        .rec-cont {
            .mb(5px);
            li {
                background: @f;
                .p(10px 9px);
                .mb(9px);
                a {
                    .rel;
                    .flex;
                    z-index: 1;
                    h4 {
                        .dbi;
                        .w(150px);
                        font-size: 14px;
                        color: @3;
                        overflow: hidden;
                        white-space: nowrap;
                        text-overflow: ellipsis;
                    }
                    h5 {
                        float: right;
                        .db;
                        .w(87px);
                        font-size: 12px;
                        color: @6;
                        overflow: hidden;
                        white-space: nowrap;
                        text-overflow: ellipsis;
                    }
                    p {
                        font-size: 12px;
                        color: @6;
                        .mt(10px);
                        .pb(9px);
                    }
                    span {
                        .abs;
                        .db;
                        bottom: 0;
                        right: 9px;
                        font-size: 12px;
                        color: @6s;
                        cursor: pointer;
                    }
                    .flex-pos {
                        flex: 1;
                    }
                }
            }
        }
    }
</style>
<template>
    <div class="rec-add-2">
        <h3>常用地址列表</h3>
        <ul class="rec-cont">
            <li v-for="address in addresses"><!--v-for-->
                <a href="javascript:void(0);" @click="selectAddress(address)">
                    <div class="chs-pac">
                        <dt class="normalAddress" v-bind:class="{'special-bg': address.id == selectedAddressId }">null</dt>
                    </div>
                    <div class="flex-pos">
                        <h4>{{ address.accept_name }}</h4>
                        <h5>{{ address.mobile }}</h5>
                        <p>{{ address | address }}</p>
                    </div>
                </a>
            </li>
        </ul>
        <infinite-loading :distance="distance" :on-infinite="fetchAddressList"></infinite-loading>
        <div class="ebuy-pay-button">
            <a href="javascript:void(0);" class="ebuy-go-pay" @click="addAddress()"
               v-link="{name: 'account_address_add'}">添加新地址</a>
        </div>
    </div>
</template>
<script>
    import EbuyFooter from '../Common/Footer.vue'
    import User from '../../utils/user'
    import Service from '../../utils/service';
    import InfiniteLoading from '../InfiniteLoading.vue'

    module.exports = {
        components: {
            InfiniteLoading
        },
        data: function () {
            return {
                addresses: [],
                selectedAddressId: 0,
                page: 1
            }
        },
        ready: function () {
            this.selectedAddressId = localStorage.getItem('selectedAddressId');
        },
        methods: {
            fetchAddressList: function () {
                var me = this;
                Service.getUserAddressList(me.page,function (response) {
                    me.$alert(response.data.message)
                }, function (response) {
                    me.addresses = me.addresses.concat(response.data.data);

                    if (me.page >= response.data.meta.pagination.total_pages) {
                        me.$broadcast('$InfiniteLoading:noMore');
                    } else if (response.data.data.length == 0) {
                        me.$broadcast('$InfiniteLoading:noResults');
                    }

                    me.$broadcast('$InfiniteLoading:loaded');

                    me.page++;
                })
            },
            selectAddress: function (address) {
                var self = this;
                self.selectedAddressId = address.id;

                // 保存到storage
                localStorage.setItem('selectedAddress', JSON.stringify(address));
                localStorage.setItem('selectedAddressId', address.id);
                window.history.back();
            },
            addAddress: function () {
                window.$router.go({name: 'account_address_add'});
            }
        }
    }
</script>