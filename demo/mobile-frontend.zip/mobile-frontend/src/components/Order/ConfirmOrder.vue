<style lang="less">
    @import (reference)'../../../static/css/base.less';
    .ebuy-confirm-order {
        h5 {
            font-size: 14px;
            color: @6;
            .p(5px 0 5px 11px);
        }
        label {
            font-size: 12px;
            .p(3px 0 3px 20px);
            color: @3;
            background: url(../../../static/images/circle.png) left center no-repeat;
            background-size: 15px;
        }
        .label-chk {
            color: @6;
            background: url(../../../static/images/circle_selected.png) left center no-repeat;
            background-size: 15px;
            .p(3px 0 3px 20px);
        }
        .label-unchk {
            color: @6;
            background: url(../../../static/images/circle.png) left center no-repeat;
            background-size: 15px;
            .p(3px 0 3px 20px);
        }
        input[type=radio], input[type=checkbox] {
            .none
        }
    }

    .order-address {
        .db;
        background: @f;
    }

    .address-details {
        .flex;
        align-items: center;
        .col-left {
            flex: 6;
            .p(8px 8px 14px);
        }
        .col-right {
            flex: 1;
            .tac
        }
        h3, h4 {
            font-size: 14px;
            color: @3;
        }
        h3 {
            .dbi;
            .w(150px);
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
        }
        h4 {
            .db;
            float: right;
            .w(87px);
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
        }
        p {
            max-height: 36px;
            .mt(3px);
            font-size: 12px;
            color: @6;
            .lh;
        }
        .order-right-icon {
            .dbi;
            .w(10px);
            .h(21px);
            background: url(../../../static/images/order_right.png) center no-repeat;
            background-size: 10px 21px;
        }
    }

    .confirm-information {
        background: @f;
        .infor-con {
            .flex;
            .p(9px 11px 9px 17px);
            border-bottom: 1px solid @e;
            box-sizing: border-box;
            &:last-child {
                border: none
            }
        }
    }

    .infor-con-img {
        .w(65px);
        .h(65px);
        .img;
        .mr(9px);
    }

    .infor-con-details {
        flex: 1;
        h3 {
            .h(33px);
            font-size: 12px;
            color: @3;
            .lh;
        }
        .where-from {
            .db;
            font-size: 12px;
            color: @9
        }
        .goods-con {
            .db;
            font-size: 12px;
            color: @9;
            span {
                .db
            }
        }
        .goods-price {
            font-size: 13px;
            color: @6ss
        }
        .goods-num {
            .rel;
            bottom: 18px;
            float: right;
            font-size: 12px;
            color: @9
        }
    }

    .send-rule {
        background: @f;
        & > p {
            .p(3px 11px 10px);
            text-align: right;
            font-size: 10px;
            color: @9;
            cursor: default
        }
    }

    .send-position {
        .flex;
        .p(0 12px);
        align-items: center;
        border-bottom: 1px solid @e;
        box-sizing: border-box;
        .col-left {
            flex: 1;
            border-right: 1px solid @e;
            box-sizing: border-box;
            .send-explain {
                .abs;
                top: 4px;
                right: 8px;
                .w(15px);
                .h(15px);
                background: url(../../../static/images/send_explain.png) center no-repeat;
                background-size: 15px;
            }
        }
        .col-right {
            .w(73px);
            .ml(8px);
        }
    }

    .send-a {
        .rel;
        .m(9px 0 13px 0);
    }

    .protect-price {
        label {
            .pl(18px);
            font-size: 12px;
            color: @3;
            background: url(../../../static/images/square.png) left center no-repeat;
            background-size: 13px
        }
    }

    .on-bj > label {
        background: url(../../../static/images/square_selected.png) left center no-repeat;
        background-size: 13px
    }

    .confirm-title {
        .rel;
        h5 {
            .dbi;
        }
        & > a {
            .abs;
            .dbi;
            font-size: 12px;
            color: @9;
            top: 7px;
            right: 11px;
            .pl(19px);
            background: url(../../../static/images/send_explain.png) left center no-repeat;
            background-size: 15px;
            &:hover {
                color: @9
            }
        }
    }

    .add-service {
        background: @f;
    }

    .service-position {
        .flex;
        .p(10px 0);
        justify-content: space-around;
    }

    .ebuy-cheap-way {
        background: @f;
        .con-pos {
            .p(9px 0 10px 14px);
            span {
                .mr(10px)
            }
            .con:first-child {
                .mb(8px)
            }
        }
        .cheap-way-pos {
            .p(5px 0);
            .col {
                .p(2px 0 4px);
                label span {
                    &:nth-child(4) {
                        display: none;
                    }
                }
            }
            .no-use {
                label span {
                    color: @9;
                    &:nth-child(4) {
                        .dbi;
                    }
                }
            }
        }
        .cheap-way-but {
            font-size:0;
            input[type=text] {
                .dbi;
                .w(25%);
                .hl(28px);
                .mr(18px);
                .p(6px);
                color: #000;
                vertical-align: middle;
            }
            .use-coupon {
                .dbi;
                .w(12%);
                .hl(28px);
                border-radius: 5px;
                font-size: 12px;
                color: @f;
                background-color: @6s;
                vertical-align: middle;
                .tac;
                letter-spacing: 1px;
            }
        }
    }

    .ebuy-extra-say {
        background: @f;
        .con-pos {
            .p(9px 14px);
        }
        .ebuy-say {
            .w(100%);
            .p(6px);
            .h(55px);
            font-size: 12px;
            color: #000;
            white-space: pre-line;
            overflow: hidden;
            text-overflow: ellipsis;
            resize: none;
        }
        .det{
            .rel;
            label {
                .dbi;
                vertical-align: middle;
            }
            p {
                font-size: 12px;
                color: @6;
            }
            a {
                .dbi;
                .w(15px);
                .h(15px);
                vertical-align: middle;
                background: url(../../../static/images/send_explain.png) center no-repeat;
                background-size: 15px;
            }
            .float-tip {
                .abs;
                right: 0;
                top: 26px;
                .w(55%);
                border: 1px solid @3;
                .bbox;
                background-color: @f;
                .p(8px);
                border-radius: 3px;
                z-index: 111;
                p {
                    line-height: 22px;
                    font-size: 12px;
                    color: @6;
                }
            }
        }
    }

    .disabled {
        color: @9;
        background: #f1f1f1;
    }

    .ebuy-show-money {
        .rel;
        background: @f;
        .con-pos {
            .p(9px 14px);
            p {
                .mb(4px);
                font-size: 12px;
                color: @9
            }
            p:last-child {
                .mb(-4px);
                .pb(4px);
                border-bottom: 1px solid @e
            }
        }
        .show-all {
            .abs;
            right: 14px;
            bottom: 50px;
            color: @6s;
            .mb(4px);
            font-size: 12px;
            span {
                font-family: 'PingFangSC-Regular';
                font-size: 14px;
            }
            .pf {
                font-family: 'PingFangSC-Regular';
                font-size: 18px;
            }
        }
    }
</style>
<template>
    <div class="ebuy-confirm-order">
        <h5>选择收货地址</h5>
        <a href="javascript:void(0);" class="order-address" @click="selectAddress()">
            <div class="address-details">
                <div class="col-left">
                    <template v-if="data.defaultAddress.accept_name">
                        <h3>{{ data.defaultAddress.accept_name }}</h3>
                        <h4>{{ data.defaultAddress.mobile }}</h4>
                        <p>{{ data.defaultAddress | address }}</p>
                    </template>
                    <template v-else>
                        <p>选择地址</p>
                    </template>
                </div>
                <div class="col-right">
                    <span class="order-right-icon"></span>
                </div>
            </div>
        </a>
        <h5>确认商品信息</h5>
        <div class="confirm-information">
            <a href="javascript:void(0);" class="infor-con" v-for="item in data.goodsList"
               v-link="{ name: 'goods-detail', params: { goodsId: item.goods_info.real_id }}">
                <div class="infor-con-img">
                    <img :src="item.stockInfo.specification_array | spec_array_img">
                </div>
                <div class="infor-con-details">
                    <h3>{{ item.goods_info.name }}</h3>
                    <p class="where-from"><span>[</span>{{ item.goods_info.seller.server_num }}<span>]</span></p>
                    <div class="goods-con">
                        {{{item.stockInfo.specification_array | spec_array}}}
                    </div>
                    <h4 class="goods-price">{{{item.stockInfo.sell_price | priceFormatter}}}</h4>
                    <h6 class="goods-num"><span>x</span>{{ item.num }}</h6>
                </div>
            </a>
        </div>
        <h5>配送方式</h5>
        <div class="send-rule">
            <div class="send-position">
                <div class="col-left">
                    <div class="send-a" v-for="item in data.availableDeliveries">
                        <input type="radio" id="AA" value="{{ item.id }}" v-model="data.data.post_way">
                        <label for="AA" @click="selectDelivery(item)"
                               v-bind:class="{'label-chk': data.orderData.delivery_id == item.id}">{{ item.name }} {{
                            item.first_price }}元</label>
                        <a href="javascript:void(0);" class="send-explain"></a>
                    </div>
                    <span class="none">{{data.post_way}}</span>
                </div>
                <div class="col-right">
                    <div class="protect-price" v-bind:class="{'on-bj': data.orderData.insured == 1 }" v-show="data.tempInsuredAmount != 0">
                        <input type="checkbox" id="checkbox" v-model="data.data.checked">
                        <label for="checkbox" @click="selectInsured()">保价 {{ data.tempInsuredAmount}}元</label>
                        <span class="none">{{data.checked}}</span>
                    </div>
                </div>
            </div>
            <p>预收首重，超重需要补交运费，具体见运费说明！</p>
        </div>
        <div class="confirm-title">
            <h5>增值服务</h5>
            <a href="javascript:void(0);">服务说明</a>
        </div>
        <div class="add-service">
            <div class="service-position">
                <div class="col">
                    <input type="radio" id="add-none" value="3" v-model="data.service_sort" class="none">
                    <label for="add-none" @click="selectFirmType(0)"
                           v-bind:class="{'label-chk': data.orderData.firm_type == 0}">不加固</label>
                </div>
                <div class="col">
                    <input type="radio" id="add-normal" value="4" v-model="data.service_sort" class="none">
                    <label for="add-normal" @click="selectFirmType(1)"
                           v-bind:class="{'label-chk': data.orderData.firm_type == 1 }">普通加固 5元</label>
                </div>
                <div class="col">
                    <input type="radio" id="add-special" value="5" v-model="data.service_sort" class="none">
                    <label for="add-special" @click="selectFirmType(2)"
                           v-bind:class="{'label-chk': data.orderData.firm_type == 2 }">特殊加固 10元</label>
                </div>
                <span class="none">{{data.service_sort}}</span>
            </div>
        </div>
        <h5>订单备注</h5>
        <div class="ebuy-extra-say">
            <div class="con-pos">
                <textarea v-model="data.orderData.message" class="ebuy-say" placeholder="填写您的特殊要求或商家优惠码，例：美亚8折码ABCDEFG" rows="1"
                          maxlength="200" onchange="this.value=this.value.substring(0, 200)"
                          onkeydown="this.value=this.value.substring(0, 200)"
                          onkeyup="this.value=this.value.substring(0, 200)"></textarea>
                <div class="det">
                    <input type="radio" id="special_but" class="none" v-show="data.orderData.message !== ''">
                    <label for="special_but"  @click="remarkCheck()" v-show="data.orderData.message !== ''"
                           v-bind:class="{'label-chk': data.data.remark_check == 1}">
                        <p>优惠码无法使用时接受原价下单</p>
                    </label>
                    <a href="javascript:void(0);" @click="specialTip" v-show="data.orderData.message !== ''"></a>
                    <div class="float-tip none">
                        <p>若备注的优惠码可用，我们会在下单成功后三小时内将折扣差额自动退还到您的账户余额；若您不接受原价下单，折扣码不可用时，则为您取消订单并退款。</p>
                    </div>
                </div>
            </div>
        </div>
        <h5>选择优惠券</h5>
        <div class="ebuy-cheap-way" v-show="is_show_coupon==1">
            <div class="con-pos">
                <div class="cheap-way-pos" >
                    <!--当优惠券不可用时, class="col"添加class="no-use"-->
                    <div class="col" v-for="coupon in coupons">
                        <input type="radio" id="coupon_one" value="10" v-model="data.coupon_value" class="none">
                        <label for="coupon_one" @click="selectCoupon(coupon)" v-bind:class="{'label-chk': data.orderData.coupon_id == coupon.id }" >
                            <span>{{ coupon.name }}</span>
                            <span>编号:{{ coupon.card_name }}</span>
                            <span>优惠: ¥{{ coupon.value }}元</span>
                        </label>
                    </div>

                    <!--special-->
                    <div class="col">
                        <input type="radio" id="coupon_three" value="12" v-model="data.coupon_value" class="none" @click="notUseCoupon()" >
                        <label for="coupon_three" v-bind:class="{'label-chk': data.orderData.coupon_id == -1 }">不使用运费券</label>
                    </div>
                </div>
                <div class="cheap-way-but">
                    <input type="text" placeholder="" v-model="data.data.input_coupon" >
                    <a href="javascript:void(0);" class="use-coupon" @click="useInputCoupon()">使用</a>
                </div>
            </div>
        </div>
        <h5>订单结算</h5>
        <div class="ebuy-show-money">
            <div class="con-pos">
                <p>商品金额总计：<span>￥{{ data.amount.goodsGrossAmount.toFixed(2) }}</span></p>
                <p>国际运费：<span>￥{{ data.amount.carriage }}</span></p>
                <p>增值费：<span>￥{{ data.amount.appreciationAmount }}</span></p>
                <p>保价：<span>￥{{ data.amount.insuredAmount }}</span></p>
                <p>运费劵：-<span>￥{{ data.amount.couponAmount }}</span></p>
            </div>
            <div class="show-all">支付总金额：{{{ data.amount.totalAmount | priceFormatter}}}<span>元</span></div>
            <div class="ebuy-pay-button">
                <a href="javascript:void(0);" class="ebuy-go-pay" @click="confirmOrder()"
                   v-bind:class="{'disabled': data.orderData.delivery_id == 0 || data.orderData.address_id == 0 || !data.canPay }">去支付</a>
            </div>
        </div>
    </div>
</template>
<script>
    require('vue-validator');
    import User from '../../utils/user';
    import Service from '../../utils/service';

    module.exports = {
        data: function () {
            return {
                coupons: [],            //运费劵列表
                is_show_coupon:0,       //优惠券列表是否显示
                delivery:0,             //0 表示没有限制配送方式
                data: {
                    canPay: true,
                    data: {
                        post_way: '1',
                        checked: 'false',
                        service_sort: '3',
                        cheap_way: '6',
                        coupon_value: '10',
                        write_information: '',
                        input_coupon:'', //输入的运费劵码
                        remark_check:0,
                    },
                    appreciations: {
                        addNone: true,
                        addNormal: false,
                        addSpecial: false
                    },
                    orderData: {				//	订单提交表单数据
                        delivery_id: 0,		//	配送方式id
                        message: "",			//	订单附言
                        ticket: "",			//	优惠券
                        insured: 0,			//	是否保价
                        address_id: 0,		//	收货地址id
                        firm_type: 0,		//	加固类型
                        removed_invoice: 0,	//	是否取出小票
                        coupon_id: 0,    //  当前选中的运费劵
                        order_goods: []		//	订单商品 gid sku num
                    },
                    deliveries: [],			//	所有配送方式
                    availableDeliveries: [],//	所有可用配送方式
//                    addresses: [],			//	用户的所有收货地址
                    goodsList: [],			//	订单中商品列表
                    tempInsuredAmount: 0,
                    defaultAddress: {
                        province: {
                            area_name: ''
                        },
                        city: {
                            area_name: ''
                        },
                        area: {
                            area_name: ''
                        }
                    },			//	用户的默认收货地址
                    amount: {					//	费用信息
                        goodsGrossAmount: 0,		//	商品总价
                        carriage: 0,				//	国际运费
                        appreciationAmount: 0,	//	增值费
                        insuredAmount: 0,		//	报价费
                        discountCouponAmount: 0,	//	优惠金额
                        totalAmount: 0,			//	订单总金额
                        couponAmount:0          //运费劵金额
                    }
                }
            }
        },
        ready: function () {
            if (localStorage.getItem('cache_confirm_order_tag') != 1) {
                this.getAddresses();
                this.getOrderGoodsList();
            } else {
                console.log("read storage");
                let selectedAddress = localStorage.getItem('selectedAddress');
                this.data = JSON.parse(localStorage.getItem('cache_confirm_order'));
                this.data.defaultAddress = selectedAddress ? JSON.parse(selectedAddress) : {};
                this.data.orderData.address_id = this.data.defaultAddress.id;
            }
            //this.getcouponsList();

        },
        methods: {
            getAddresses: function () {
                var me = this;
                Service.getUserDefaultAddress(null, function (response) {
                    me.data.defaultAddress = response.data.data;
                    me.data.orderData.address_id = me.data.defaultAddress.id;
                });
            },
            getDeliveries: function () {
                var me = this;
                Service.getDeliveries(function (response) {

                }, function (response) {
                    me.data.deliveries = response.data.data;
                });
            },
            getOrderGoodsList: function () {
                var me = this;
                Service.getUserCartList(null, function (response) {
                    var goods = response.data.data.cart.content.goods;

                    for (var key in goods) {
                        if (goods[key].selected == 1) {
                            me.data.goodsList.push(goods[key]);
                            me.data.orderData.order_goods.push({
                                gid: goods[key].goods_id,
                                sku: key,
                                num: goods[key].num
                            });
                        }
                    }

                    if (me.data.goodsList.length == 0)
                        window.$router.go({name: 'home'});

                    me.initPrice();
                    me.getAvailableDeliveries();
                });
            },
            getAvailableDeliveries: function () {
                var me = this;

                var goodsIds = [];
                for (var key in me.data.goodsList) {
                    var temp = me.data.goodsList[key].goods_id;
                    goodsIds.push(temp);
                }
                Service.getAvailableDeliveries({goodsIds:goodsIds,orderPrice:me.data.amount.goodsGrossAmount}, null, function (response) {
                    me.data.availableDeliveries = response.data;
                    if (response.data.length < 1) {
                        me.data.canPay = false;
                    }
                })

            },
            initPrice: function () {
                var me = this;
                var goodsList = me.data.goodsList;
                for (var key = 0; key < goodsList.length; key++) { // 用 for in 在 iOS 设备下循环次数会 * 2
                    me.data.amount.goodsGrossAmount += parseFloat(goodsList[key].stockInfo.sell_price * goodsList[key].num);
                }

                this.updatePrice();
            },
            updatePrice: function () {
                var me = this;

                me.data.amount.totalAmount = (me.data.amount.goodsGrossAmount
                + me.data.amount.carriage
                + me.data.amount.appreciationAmount
                + me.data.amount.insuredAmount
                + me.data.amount.discountCouponAmount).toFixed(2)
                -me.data.amount.couponAmount;
            },
            selectDelivery: function (item) {
                this.data.orderData.delivery_id = item.id;
                this.data.amount.carriage = parseFloat(item.first_price);
                this.updatePrice();
                if (item.is_save_price == 1){
                    this.data.tempInsuredAmount = parseFloat(item.protect_price);
                }
                //这里根据查出对应的运费劵
                this.delivery=item.id;
                this.getOrderCouponsList();
                this.is_show_coupon=1;
            },
            selectFirmType: function (id) {
                this.data.orderData.firm_type = id;
                var price = 0;
                if (id == 1) {
                    price = 5;
                } else if (id == 2) {
                    price = 10;
                }
                this.data.amount.appreciationAmount = price;
                this.updatePrice();
            },
            remarkCheck: function () {
                if (this.data.data.remark_check == 0) {
                    this.data.data.remark_check = 1;
                } else {
                    this.data.data.remark_check = 0;
                    this.data.amount.insuredAmount = 0;
                }
            },
            selectInsured: function () {
                if (this.data.orderData.insured == 0) {
                    this.data.orderData.insured = 1;
                    this.data.amount.insuredAmount = this.data.tempInsuredAmount;
                } else {
                    this.data.orderData.insured = 0;
                    this.data.amount.insuredAmount = 0;
                }
                this.updatePrice();
            },
            selectAddress: function () {
                window.$router.go({name: 'order-address'});
                localStorage.setItem('selectedAddressId', this.data.defaultAddress.id);
                localStorage.setItem('cache_confirm_order_tag', 1);
                localStorage.setItem('cache_confirm_order', JSON.stringify(this.data));
            },
            confirmOrder: function () {
                var me = this;
                if (!me.data.canPay || me.data.orderData.delivery_id == 0 || me.data.orderData.address_id == 0) {
                    if (me.data.orderData.delivery_id == 0) {
                        me.$alert('请选择配送方式 ^_^');
                    }
                    if (me.data.orderData.address_id == 0) {
                        me.$alert('请设置一个收货地址 ^_^');
                    }
                    return;
                }
                console.log("confirmOrder");
                if (me.data.data.remark_check == 0 && me.data.orderData.message !== '') {
                    me.data.orderData.message += '(优惠码无法使用时不接受原价下单)';
                }
                Service.postOrder(me.data.orderData, function (response) {
                    me.$alert('服务器错误,订单提交失败 -_-#');
                }, function (response) {
                    // 清空缓存
                    localStorage.setItem('cache_confirm_order_tag', 0);
                    localStorage.setItem('cache_confirm_order', {});
                    me.$alert('订单提交成功 Y(^_^)Y');
                    Service.goPay(response.data.data.id);
                });
            },
            getOrderCouponsList: function () {

            //获取订单可用运费劵
                var me = this;
                me.coupons=[];
                Service.getOrderCouponsList(me.delivery, function (response) {
                    me.$alert(response.data.message)
                }, function (response) {
                    me.coupons = response.data.data;
                });
            },
            selectCoupon: function (coupon) {
                //选择对应的运费劵
                var me = this;
                me.data.orderData.coupon_id=coupon.id;
                me.data.amount.couponAmount=coupon.value;
                me.data.orderData.ticket=coupon.card_name;
                this.updatePrice();

            },
            useInputCoupon:function(){

                var me=this;
                var cardname=me.data.data.input_coupon;

                if(!cardname){
                    me.$alert('请输入运费劵 ^_^');
                }
                Service.getUseableCoupon(me.data.data.input_coupon,me.delivery, function (response) {
                    me.$alert(response.data.message)
                }, function (response) {
                    var data=response.data.data;
                    if(data.success){
                        var result=data.data.result
                        console.log(result);
                        me.coupons=me.coupons.concat(result);
                        me.data.amount.couponAmount=result.value;
                        me.data.orderData.coupon_id=result.id;
                        me.data.orderData.ticket=result.card_name;
                        me.updatePrice();
                    }else{
                        me.$alert(''+data.message+' ^_^');
                    }
                });
            },
            notUseCoupon:function(){
                var me=this;
                //不使用运费劵
                me.data.orderData.ticket='';
                me.data.amount.couponAmount=0;
                me.data.orderData.coupon_id=-1;
                this.updatePrice();
            },
            specialTip: function(){
                $('.float-tip').toggleClass('none');
            }
        }
    }
</script>