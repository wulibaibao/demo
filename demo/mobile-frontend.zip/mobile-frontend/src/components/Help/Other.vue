<style lang="less">
	@import (reference) '../../../static/css/base.less';
	.ord-pro {
		.pb(50px);
		&>a {
			.db;
			h6 {
				.h(44px);
				line-height: 44px;
				.pl(9px);
				font-size: 14px;
				color: @3;
				border-bottom: 1px solid @e;
				box-sizing: border-box;
			}
			.spe-bg {
						background: @6s;
						color: @f;
					}
			.relate-key {
				display: none;
				line-height: 20px;
				.p(5px 14px 17px 21px);
				font-size: 14px;
				color: @6;
				background: #f1f1f1;
			}
		}
	}
</style>
<template>
	<div class="ord-pro">
		<a v-for="con in cons" v-on:click.stop="slideAuto($event)" href="javascript:void(0);">
			<h6>{{ con.title }}</h6>
			<p class="relate-key">{{ con.content }}</p>
		</a>
	</div>
	<div class="empty-bg"></div>
</template>
<script>
	import zepto from 'webpack-zepto'
	module.exports = {
		components: {
		},
		methods: {
			slideAuto: function (e) {
				var el = e.currentTarget;
				$(el).children('h6').toggleClass('spe-bg');
				$(el).children(".relate-key").toggleClass('dbs');
			}
		},
		data:function(){
			return {
				cons : [
					{ title: '1.如何成为注册会员？为什么会注册失败？',content:'当您通过微信服务号进入微信商城时，已经通过微信登录ebuy商城，系统会提示您填写相关信息进行注册，注册成功后账号会与您的微信号绑定；已有账号用户可根据提示进行登录进行账号绑定；注册失败的原因可能是网络问题或输入信息有误，请确保您网络环境的通常以及输入信息的准确性。'},
					{ title: '2.我忘记登录密码了怎么办？',content: '你可以在登录页面点击找回密码按键，通过验证手机号进行重置密码操作。'},
					{ title: '3.支持哪些支付方式？',content: '目前微信商城仅支持微信支付，手机浏览器仅支持支付宝支付。'},
					{ title: '4.如何获得优惠券？优惠券无法使用怎么办？',content: '可以通过参加平台活动、注册时填写邀请码及晒单等途径获得优惠券；优惠券有相应的使用限制，例如某券仅限于美亚购物使用，请你仔细查看优惠券详情。'},
				]
			}
		}
	}
</script>