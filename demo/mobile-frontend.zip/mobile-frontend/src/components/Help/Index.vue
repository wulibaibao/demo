<style lang="less">
	@import (reference) '../../../static/css/base.less';
	.nor-pro {
		&>a {
			.db;
			.w(100%);
			.h(44px);
			line-height: 44px;
			.pl(41px);
			font-size: 16px;
			color: @6;
			border-bottom: 1px solid @e;
			box-sizing: border-box;
			&:first-child {
				background: url(../../../static/images/order_problem.png) 9px center no-repeat;
				background-size: 20px; 
			}
			&:nth-child(2) {
				background: url(../../../static/images/buy_problem.png) 9px center no-repeat;
				background-size: 20px; 
			}
			&:last-child {
				background: url(../../../static/images/other_problem.png) 9px center no-repeat;
				background-size: 20px; 
			}
		}
	}
</style>
<template>
	<div class="nor-pro">
		<a href="javascript:void(0);" v-link="{name: 'help_order'}">订单问题</a>
		<a href="javascript:void(0);" v-link="{name: 'help_shopping'}">购物问题</a>
		<a href="javascript:void(0);" v-link="{name: 'help_others'}">其他问题</a>
	</div>
	<div class="empty-bg"></div>
</template>
<script>
	module.exports = {
		components: {
		}
	}
</script>