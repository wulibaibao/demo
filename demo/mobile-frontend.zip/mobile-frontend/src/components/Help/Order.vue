<style lang="less">
	@import (reference) '../../../static/css/base.less';
	.ord-pro {
		.pb(50px);
		&>a {
			.db;
			h6 {
				min-height: 44px;
				line-height: 44px;
				.pl(9px);
				font-size: 14px;
				color: @3;
				border-bottom: 1px solid @e;
				box-sizing: border-box;
			}
			.spe-bg {
						background: @6s;
						color: @f;
					}
			.relate-key {
				line-height: 20px;
				display: none;
				.p(5px 14px 17px 21px);
				font-size: 14px;
				color: @6;
				background: #f1f1f1;
			}
		}
	}
</style>
<template>
	<div class="ord-pro">
		<a v-for="con in cons" v-on:click.stop="slideAuto($event)" href="javascript:void(0);">
			<h6>{{ con.title }}</h6>
			<p class="relate-key">{{ con.content }}</p>
		</a>
	</div>
	<div class="empty-bg"></div>
</template>
<script>
	import zepto from 'webpack-zepto'
	module.exports = {
		components: {
		},
		methods: {
			slideAuto: function (e) {
				var el = e.currentTarget;
				$(el).children('h6').toggleClass('spe-bg');
				$(el).children(".relate-key").toggleClass('dbs');
			}
		},
		data:function(){
			return {
				cons : [
					{ title: '1.Ebuy能保证按照我提交单时的价格为我购买商品吗？',content:'在您提交订单后我们都会尽快为您处理订单，但部分商品价格波动频繁，偶尔会出现我们为您处理订单时价格已经与您提交订单时不同的情况，此时客服会跟您联系并解决此问题。'},
					{ title: '2.海外商家的优惠码或者coupon能用吗？',content: '可以，如果您发现选购的商品使用商家无限制优惠码（公码）可以打折，请您在提交订单后联系客服改价，等客服改完价再支付。如果优惠码有限制则无法使用，比如美亚部分商品的coupon码，6PM的9折码等，原因是这些码每个帐号仅限用一次，无法为每个用户使用。'},
					{ title: '3.我可以取消订单么？假如尺码买错了，可以更改么？',content: '您提交订单并付款后，如果需要取消或修改订单，请及时联系客服。如我们尚未下单，可以取消和修改订单，如果已经下单，需要根据实际情况处理，如果是美亚订单可以尝试为您联系修改，但不保证能够修改成功；如果是6PM订单，则无法取消或修改。所以在您下单前请谨慎选择尺码。'},
					{ title: '4.为什么我付款后收到订单被取消的通知？',content: '您提交订单并付款后，我们的工作人员会及时处理订单，在国外网站为您下单。但是如果遇到商品价格上涨，库存不足等情况，我们会在后台为您取消订单，您支付的款项会按原路径返回至您的资金账户。'},
					{ title: '5.我提交订单后的会经历怎么样的物流流程？',content: '整个物流进度包含以下几个阶段：1.用户提交订单，我们的工作人员为您处理，一般需要10-30分钟。2.从成功下单到境外商家发货，可能需要2-4个工作日不等（不同商家发货速度不一致）。3.商家发货到达国外的转运仓库，5-7个工作日。4.在转运仓库内经历入库、清点、分拣到出仓，1-2个工作日。5.出仓上飞机到落地海关3-7个工作日（节假日海关不放行）；6.海关放行到用户收货，1-3个工作日。综上，当您提交订单成功之后，一般15-20个工作日内即可送达，当然，具体达到时间主要取决于海外商家的发货速度以及海关的清关速度（比如日本ems平均只需要5天哦），我们会尽快将宝贝送到您手中。具体物流信息可在“个人账户”—“订单详情”里进行查询。'},
				]
			}
		}
	}
</script>