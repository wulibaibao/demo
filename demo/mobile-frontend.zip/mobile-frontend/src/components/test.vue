<template>
<home-header></home-header>
  <div>
    <h2>TEst </h2>
    <div style="height:100px; border: 1px solid #f00">
      这是 test
    </div>
  </div>

</template>

<script type="text/javascript">
    
import header from './header.vue'
module.exports ={
  components: {
    HomeHeader:header
  },
  // route: {
  //       activate: function (transition) {
  //         console.log('hook-example activated!')
  //         transition.next()
  //       },
  //       deactivate: function (transition) {
  //         console.log('hook-example deactivated!')
  //         transition.next()
  //       }
  //   }
}

</script>