<style lang="less">
    @import (reference) '../../../static/css/base.less';
    .add_new_address {
        background: @f;
        .pb(50px);
        .address-cont {
            input[type="text"], input[type="tel"], select {
                .db;
                .w(100%);
                .h(44px);
                line-height: 44px;
                .p(0 19px);
                border-color: transparent;
                font-size: 14px;
                color: @9;
                border-bottom: 1px solid @e;
            }
            input[type="file"] {
                .abs;
                left: 0;
                top: 0;
                .w(100%);
                .h(100%);
                background: transparent;
                opacity: 0;
            }
            select {
                background: url(../../../static/images/select_down.png) 94% center no-repeat;
                background-size: 10px;
            }
        }
        .flex-s {
            clear: both;
            overflow: hidden;
        }
        .front, .back {
            .rel;
            float: left;
            .w(50%);
            .img;
            border: 1px solid @e;
            box-sizing: border-box;
            .p(5px 12px);
        }
        .sweat-tip {
            .m(5px 19px 44px);
            font-size: 10px;
            color: @9;
        }
        .disable_input{
            background:#efefef;
        }
    }
</style>
<template>
    <form autocomplete="off" class="add_new_address" onsubmit="return false;">
        <div class="address-cont">
            <input type="text" placeholder="收货人" v-model="form.accept_name" v-if="form.is_audit==1" readonly='readonly' class='disable_input'>
            <input type="text" placeholder="收货人" v-model="form.accept_name" v-else>
            <input type="tel" placeholder="联系方式" v-model="form.mobile">
            <select v-model="form.province" @change="handleProvince">
                <option value="null" selected>请选择省份</option>
                <option v-for="province in data.province" value="{{ province.area_id }}"><!--v-for-->
                    {{ province.area_name }}
                </option>
            </select>
            <select v-model="form.city" @change="handleCity" v-show="data.city.length > 0">
                <option value="null" selected>请选择城市</option>
                <option v-for="city in data.city" value="{{ city.area_id }}"><!--v-for-->
                    {{ city.area_name }}
                </option>
            </select>
            <select v-model="form.area" v-show="data.area.length > 0">
                <option value="null" selected>请选择地区</option>
                <option v-for="area in data.area" value="{{ area.area_id }}"><!--v-for-->
                    {{ area.area_name }}
                </option>
            </select>
            <input type="text" placeholder="街道地址" v-model="form.address">
            <input type="tel" placeholder="邮政编码" v-model="form.zip">
            <input type="text" placeholder="身份证号" v-model="form.id_card_number" v-if="form.is_audit==1" readonly="readonly" class="disable_input">
            <input type="text" placeholder="身份证号" v-model="form.id_card_number" v-else>
            <div class="flex-s" v-show="form.is_audit!=1">
                <a href="javascript:void(0);" class="front">
                    <img :src="data.id_card_front">
                    <input type="file" accept="image/*" @change="uploadIdFront">
                </a>
                <a href="javascript:void(0);" class="back">
                    <img :src="data.id_card_back">
                    <input type="file" accept="image/*" @change="uploadIdBack">
                </a>
            </div>
            <p class="sweat-tip" v-show="form.is_audit!=1">温馨提示：<span v-if="form.is_audit==2">{{ address.audit_reason }}</span><span v-else >因海关需要,请上传清晰可见的证件照片</span></p>
            <br/>
            <div class="ebuy-pay-button">
                <a href="javascript:void(0);" class="ebuy-go-pay" @click="saveAddress">保存地址</a>
            </div>
        </div>
    </form>
    <div class="empty-bg"></div>
</template>
<script>
    import EbuyFooter from '../Common/Footer.vue'
    import User from '../../utils/user'
    import Service from '../../utils/service';

    module.exports = {
        components: {},
        data: function () {
            return {
                address: {},
                data: {
                    province: [],
                    city: [],
                    area: [],
                    id_card_front: require('static_file/images/front.png'),
                    id_card_back: require('static_file/images/back.png')
                },
                form: {
                    accept_name: null,
                    province: null,
                    city: null,
                    area: null,
                    mobile: null,
                    address: null,
                    zip: null,
                    id_card_number: null,
                    id_card_front: null,
                    id_card_back: null,
                    is_audit: null,
                    audit_reason: null,
                }
            }
        },
        ready: function () {
            this.getAddress();
        },
        methods: {
            handleProvince: function () {
                this.data.city = [];
                this.data.area = [];

                var self = this;

                this.getCity(function () {
                    self.form.city = self.data.city.length ? 'null' : 0;
                    self.form.area = self.data.city.length ? 'null' : 0;
                });
            },
            handleCity: function () {
                this.data.area = [];
                var self = this;

                this.getArea(function () {
                    self.form.area = self.data.city.length ? 'null' : 0;
                });
            },
            defaultArea: function () {
                var self = this;

                if (self.form.city == null && self.form.area == null) {
                    self.getProvince();
                } else {
                    self.getProvince(function () {
                        self.getCity(function () {
                            self.getArea();
                        });
                    });
                }
            },
            getAddress: function () {
                let self = this;
                Service.getUserAddress(this.$route.params.id, function (response) {
                    self.$alert(response.data.message);
                }, function (response) {
                    let address = response.data.data;

                    self.address = address;

                    self.form.accept_name = address.accept_name;
                    self.form.mobile = address.mobile;
                    self.form.address = address.address;
                    self.form.zip = address.zip;
                    self.form.id_card_number = address.id_card_number;
                    self.form.province = address.province.area_id;
                    self.form.city = address.city != null ? address.city.area_id : null;
                    self.form.area = address.area != null ? address.area.area_id : null;
                    self.form.is_audit=address.is_audit;
                    self.form.audit_reason=address.audit_reason;
                    if (address.id_card_back) {
                        self.form.id_card_front = address.id_card_front;
                        self.data.id_card_front = address.id_card_front;
                    }

                    if (address.id_card_front) {
                        self.data.id_card_back = address.id_card_back;
                        self.form.id_card_back = address.id_card_back;
                    }

                    self.defaultArea();
                });
            },
            uploadIdFront: function (e) {
                e.preventDefault();

                var self = this;
                var image = e.target.files[0];
                var data = new FormData();
                data.append('file', image);

                Service.uploadId(data, function (response) {
                    self.$alert(response.data.message)
                }, function (response) {
                    self.form.id_card_front = response.data.data.url;
                    self.data.id_card_front = response.data.data.url;

                    self.$alert('上传成功')
                });
            },
            uploadIdBack: function (e) {
                e.preventDefault();

                var self = this;
                var image = e.target.files[0];
                var data = new FormData();
                data.append('file', image);

                Service.uploadId(data, function (response) {
                    self.$alert(response.data.message)
                }, function (response) {
                    self.form.id_card_back = response.data.data.url;
                    self.data.id_card_back = response.data.data.url;

                    self.$alert('上传成功')
                });
            },
            saveAddress: function () {
                var self = this;

                Service.editUserAddress(self.address.id, self.form, function (response) {
                    self.$alert(response.data.message)
                }, function (response) {
                    window.history.go(-1);

                    self.$alert('地址编辑成功');
                });
            },
            getProvince: function (callback) {
                var self = this;

                Service.getAreasList(0, function (response) {
                    self.$alert(response.data.message)
                }, function (response) {
                    self.data.province = response.data.data;
                    self.data.city = [];
                    self.data.area = [];
                    self.form.province = self.address.province.area_id;

                    if (typeof callback == 'function') {
                        callback();
                    }
                });
            },
            getCity: function (callback) {
                var self = this;

                Service.getAreasList(this.form.province, function (response) {
                    console.log(response);
                }, function (response) {
                    self.data.city = response.data.data;
                    self.data.area = [];
                    self.form.city = self.address.city != null ? self.address.city.area_id : null;;

                    if (typeof callback == 'function') {
                        callback();
                    }
                });
            },
            getArea: function (callback) {
                var self = this;

                Service.getAreasList(this.form.city, function (response) {
                    console.log(response);
                }, function (response) {
                    self.data.area = response.data.data;
                    self.form.area = self.address.area != null ? self.address.area.area_id : null;;
                    if (typeof callback == 'function') {
                        callback();
                    }
                });
            }
        }
    }
</script>