<style lang="less">
    @import (reference) '../../../static/css/base.less';
    .rec-add {
        .normalAddress {
            .db;
            font-size: 12px;
            .p(2px 0 2px 20px);
            .mt(10px);
            color: @3;
            background: url(../../../static/images/circle.png) left center no-repeat;
            background-size: 15px;
            cursor: pointer;
        }
        .special-bg {
            background: url(../../../static/images/circle_selected.png) left center no-repeat;
            background-size: 15px;
        }
        input[type=radio] {
            .none
        }
        h3 {
            .pl(9px);
            .mb(5px);
            .h(30px);
            line-height: 30px;
            font-size: 14px;
            color: @3;
            background: @f;
        }
        .rec-cont {
            .mb(5px);
            li {
                background: @f;
                .p(10px 9px);
                .mb(9px);
                a {
                    .rel;
                    .db;
                    z-index: 1;
                    h4 {
                        .db;
                        font-size: 14px;
                        color: @3;
                    }
                    h5 {
                        .abs;
                        top: 0;
                        right: 9px;
                        font-size: 12px;
                        color: @6;
                    }
                    p {
                        font-size: 12px;
                        color: @6;
                        .mt(10px);
                        .pb(9px);
                        border-bottom: 1px solid @e;
                        word-break: break-all;
                    }
                    span.del {
                        .abs;
                        .db;
                        bottom: 2px;
                        right: 9px;
                        font-size: 12px;
                        color: @6s;
                        cursor: pointer;
                    }
                    span.edit {
                        .abs;
                        .db;
                        bottom: 2px;
                        right: 45px;
                        font-size: 12px;
                        color: @6s;
                        cursor: pointer;
                    }
                    span.audit_status{
                        .abs;
                        .db;
                        bottom: 2px;
                        right: 85px;
                        font-size: 12px;
                        cursor: pointer;
                    }
                    span.green {
                        color: @7s;
                    }
                    span.red {
                        color: @6ss;
                    }
                }
            }
        }
    }
</style>
<template>
    <div class="rec-add">
        <h3>常用地址列表</h3>
        <ul class="rec-cont">
            <li v-for="address in addresses"><!--v-for-->
                <a href="javascript:void(0);">
                    <h4>{{ address.accept_name }}</h4>
                    <h5>{{ address.mobile }}</h5>
                    <p>{{ address | address }}
                    </p>
                    <div class="chs-pac">
                        <dt class="normalAddress" v-bind:class="{'special-bg': address.default == 1}"
                            @click="setDefault(address)">默认地址
                        </dt>
                    </div>
                    <span v-show='address.is_audit==0' class="audit_status">待上传</span>
                    <span v-show='address.is_audit==1' class="audit_status green">审核通过</span>
                    <span v-show='address.is_audit==2' class="audit_status red">审核未通过</span>
                    <span v-show='address.is_audit==3' class="audit_status">待审核</span>
                    <span class="edit" v-link="{name: 'account_address_edit', params: {id: address.id}}">编辑</span>
                    <span class="del" @click="delAddress(address)">删除</span>
                </a>
            </li>
        </ul>
        <infinite-loading :distance="distance" :on-infinite="fetchAddressList"></infinite-loading>
        <div class="ebuy-pay-button">
            <a href="javascript:void(0);" class="ebuy-go-pay" v-link="{name: 'account_address_add'}">添加新地址</a>
        </div>
    </div>
</template>
<script>
    import EbuyFooter from '../Common/Footer.vue'
    import User from '../../utils/user'
    import Service from '../../utils/service';
    import InfiniteLoading from '../InfiniteLoading.vue'

    module.exports = {
        components: {
            InfiniteLoading
        },
        data: function () {
            return {
                addresses: [],
                page: 1
            }
        },
        ready: function () {
        },
        methods: {
            fetchAddressList: function () {
                var me = this;

                Service.getUserAddressList(me.page, function (response) {
                    me.$alert(response.data.message)
                }, function (response) {

                    me.addresses = me.addresses.concat(response.data.data);

                    if (me.page >= response.data.meta.pagination.total_pages) {
                        me.$broadcast('$InfiniteLoading:noMore');
                    } else if (response.data.data.length == 0) {
                        me.$broadcast('$InfiniteLoading:noResults');
                    }
                    me.$broadcast('$InfiniteLoading:loaded');

                    me.page++;
                })
            },
            delAddress: function (address) {
                var self = this;

                Service.deleteUserAddress(address.id, function (response) {
                    self.$alert(response.data.message);
                }, function (response) {
                    self.$alert('删除成功');
                    self.addresses.$remove(address);
                });
            },
            setDefault: function (address) {
                var self = this;

                Service.setUserAddressAsDefault(address.id, function (response) {
                    self.$alert(response.data.message)
                }, function (response) {
                    self.$alert('设置成功');

                    var curAddress = address;

                    self.addresses.forEach(function (address) {
                        if (address.id == curAddress.id) {
                            address.default = 1;
                        } else {
                            address.default = 0;
                        }
                    });
                });
            }
        }
    }
</script>