<style lang="less">
    @import (reference) '../../../static/css/base.less';
    .add_new_address {
        background: @f;
        .pb(50px);
        .address-cont {
            input[type="text"], input[type="tel"], select {
                .db;
                .w(100%);
                .h(44px);
                line-height: 30px;
                .p(5px 0);
                border-color: transparent;
                font-size: 14px;
                color: @9;
                border-bottom: 1px solid @e;
                text-indent: 19px;
                vertical-align: top;
            }
            input[type="file"] {
                .abs;
                left: 0;
                top: 0;
                .w(100%);
                .h(100%);
                background: transparent;
                opacity: 0;
            }
            select {
                background: url(../../../static/images/select_down.png) 94% center no-repeat;
                background-size: 10px;
            }
        }
        .flex-s {
            clear: both;
            overflow: hidden;
        }
        .front, .back {
            .rel;
            float:left;
            .w(50%);
            .img;
            border: 1px solid @e;
            border-top: none;
            box-sizing: border-box;
            .p(5px 12px);
        }
        .sweat-tip {
            .m(5px 19px 44px);
            font-size: 12px;
            font-weight: 700;
            color: @9;
        }
    }
</style>
<template>
    <form autocomplete="off" class="add_new_address" onsubmit="return false;">
        <div class="address-cont">
            <input type="text" placeholder="收货人" v-model="form.accept_name">
            <input type="tel" placeholder="联系方式" v-model="form.mobile">
            <select v-model="form.province" @change="getCity">
                <option value="null" selected>请选择省份</option>
                <option v-for="province in data.province" value="{{ province.area_id }}"><!--v-for-->
                    {{ province.area_name }}
                </option>
            </select>
            <select v-model="form.city" @change="getArea" v-show="data.city.length > 0">
                <option value="null" selected>请选择城市</option>
                <option v-for="city in data.city" value="{{ city.area_id }}"><!--v-for-->
                    {{ city.area_name }}
                </option>
            </select>
            <select v-model="form.area" v-show="data.area.length > 0">
                <option value="null" selected>请选择地区</option>
                <option v-for="area in data.area" value="{{ area.area_id }}"><!--v-for-->
                    {{ area.area_name }}
                </option>
            </select>
            <input type="text" placeholder="街道地址" v-model="form.address">
            <input type="tel" placeholder="邮政编码" v-model="form.zip">
            <input type="text" placeholder="身份证号" v-model="form.id_card_number">
            <div class="flex-s">
                <a href="javascript:void(0);" class="front">
                    <img :src="data.id_card_front">
                    <input type="file" accept="image/*" @change="uploadIdFront">
                </a>
                <a href="javascript:void(0);" class="back">
                    <img :src="data.id_card_back">
                    <input type="file" accept="image/*" @change="uploadIdBack">
                </a>
            </div>
            <p class="sweat-tip">温馨提示：<span>因海关需要,请上传清晰可见的证件照片</span></p>
            <div class="ebuy-pay-button">
                <a href="javascript:void(0);" class="ebuy-go-pay" @click="saveAddress">保存地址</a>
            </div>
        </div>
    </form>
    <div class="empty-bg"></div>
</template>
<script>
    import EbuyFooter from '../Common/Footer.vue'
    import User from '../../utils/user'
    import Service from '../../utils/service';

    module.exports = {
        components: {},
        data: function () {
            return {
                data: {
                    province: [],
                    city: [],
                    area: [],
                    id_card_front: require('static_file/images/front.png'),
                    id_card_back: require('static_file/images/back.png')
                },
                form: {
                    province: null,
                    city: null,
                    area: null,
                    mobile: null,
                    address: null,
                    zip: null,
                    id_card_number: null,
                    id_card_front: null,
                    id_card_back: null,
                }
            }
        },
        ready: function () {
            this.getProvince();
        },
        methods: {
            uploadIdFront: function (e) {
                e.preventDefault();

                var self = this;
                var image = e.target.files[0];
                var data = new FormData();
                data.append('file', image);

                Service.uploadId(data, function (response) {
                    self.$alert(response.data.message)
                }, function (response) {
                    self.form.id_card_front = response.data.data.url;
                    self.data.id_card_front = response.data.data.url;

                    self.$alert('上传成功')
                });
            },
            uploadIdBack: function (e) {
                e.preventDefault();

                var self = this;
                var image = e.target.files[0];
                var data = new FormData();
                data.append('file', image);

                Service.uploadId(data, function (response) {
                    self.$alert(response.data.message)
                }, function (response) {
                    self.form.id_card_back = response.data.data.url;
                    self.data.id_card_back = response.data.data.url;

                    self.$alert('上传成功')
                });
            },
            saveAddress: function () {
                var self = this;

                Service.saveUserAddress(self.form, function (response) {
                    self.$alert(response.data.message)
                }, function (response) {
                    window.history.go(-1);

                    self.$alert('地址添加成功');
                });
            },
            getProvince: function () {
                var self = this;

                Service.getAreasList(0, function (response) {
                    self.$alert(response.data.message)
                }, function (response) {
                    self.data.province = response.data.data;
                    self.data.city = [];
                    self.data.area = [];
                    self.form.city = self.data.province.length ? 'null' : 0;
                    self.form.province = self.data.province.length ? 'null' : 0;
                    self.form.area = self.data.province.length ? 'null' : 0;
                });
            },
            getCity: function () {
                var self = this;

                Service.getAreasList(this.form.province, function (response) {
                    console.log(response);
                }, function (response) {
                    self.data.city = response.data.data;
                    self.data.area = [];
                    self.form.area = self.data.city.length ? 'null' : 0;
                    self.form.city = self.data.city.length ? 'null' : 0;
                });
            },
            getArea: function () {
                var self = this;

                Service.getAreasList(this.form.city, function (response) {
                    console.log(response);
                }, function (response) {
                    self.data.area = response.data.data;
                });
            }
        }
    }
</script>