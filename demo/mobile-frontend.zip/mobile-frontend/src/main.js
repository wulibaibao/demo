//初始化路由,初始化vue
import Vue from "vue";
import Root from "components/root.vue";
import configRouter from "./routes";
import accountRouter from "./routes/account";
import goodsRouter from "./routes/goods";
import cartRouter from "./routes/cart";
import securityRouter from "./routes/security";
import helpRouter from "./routes/help";
import addressRouter from "./routes/address";
import commonRouter from "./routes/common";
import orderRouter from "./routes/order";
import VueRouter from "vue-router";
import VueValidator from "vue-validator";
import VueAlert from "./plugins/vue-alert";
import config from "../config";
import User from "./utils/user";
Vue.use(VueRouter);
Vue.use(VueValidator);
Vue.use(VueAlert);
// 缩略图处理
Vue.filter('thumb', function (value, width = 200, height = 200) {

    if (!value) {
        return require('../static/images/default_thumb.png');
    }

    var transformed = [];
    transformed.push('//www.ebuy365.com/pic/thumb/img/');
    transformed.push(value.replace(/http:/g, '').replace(/\//g, '@_@'));
    transformed.push('/w/');
    transformed.push(width);
    transformed.push('/h/');
    transformed.push(height);

    return transformed.join('');
});

Vue.filter('priceFormatter', function (value) {

    let price = value || 0;
    let stringPriceArray = price.toString().split('.');
    let integer = stringPriceArray[0] || 0;
    let decimal = stringPriceArray[1] || 0;

    return `<span>￥</span><span class="pf">${integer}</span><span>.</span><span>${decimal}</span>`;
});

//specification的图片
Vue.filter('spec_array_img', function (value, width = 200, height = 200) {
    for (var i in value) {
        if (value[i].image != 'undefined') {
            return value[i].image;
        }
    }
});

Vue.filter('spec_array', function (value, width = 200, height = 200) {

    if (!value) {
        return '';
    }

    var str = '';//name, value, image
    for (var i = 0; i < value.length; i++) {
        if (value[i].name != 'undefined') {
            if (value[i].name == 'color') {
                var v_name = '颜色';
            } else if (value[i].name == 'size') {
                var v_name = '尺寸';
            } else if (value[i].name == 'style') {
                var v_name = '规格';
            } else {
                var v_name = value[i].name;
            }
            str += v_name + '：';
        }
        if (value[i].value != 'undefined') {
            str += value[i].value + ' ';
        }

        str += "\r\n<br>";
    }
    return str;
});

// 字符串截取
Vue.filter('substr', function (value, length = 10) {
    return value.substring(0, length) + "..."
});

// 收货地址显示
Vue.filter('address', function (value) {
    let province = value.province ? value.province.area_name : '';
    let city = value.city ? value.city.area_name : '';
    let area = value.area ? value.area.area_name : '';

    return province + city + area + value.address || '';
});

Vue.component('modal', {
    template: '#modal-template',
    props: {
        show: {
            type: Boolean,
            required: true,
            twoWay: true
        }
    }
});

// 创建一个路由器实例
// 创建实例时可以传入配置参数进行定制，为保持简单，这里使用默认配置
var router = new VueRouter({
    history: true
});

// 定义路由规则
configRouter(router);
accountRouter(router);
helpRouter(router);
addressRouter(router);
securityRouter(router);
goodsRouter(router);
cartRouter(router);
commonRouter(router);
orderRouter(router);

// 现在我们可以启动应用了！
// 路由器会创建一个 App 实例，并且挂载到选择符 #root 匹配的元素上。
// sync(store, router)
var App = Vue.extend(Root);

Vue.config.debug = true;
Vue.config.devtools = true;

router.start(App, '#root');

window.$apiUrl = config.apiUrl;//后台接口地址
window.$backendUrl = config.backendUrl;//后台接口地址,抓取什么、更新价格
window.$router = router;
window.$app = App;
window.getCookie = function (name) {
    var value = "; " + document.cookie;
    var parts = value.split("; " + name + "=");
    if (parts.length == 2)
        return parts.pop().split(";").shift();
};

router.beforeEach((transition) => {
    if (transition.to.auth && !User.isLogged()) {
        User.goLogin();
    } else {
        document.title = transition.to.title || '';
        transition.next();
    }
});