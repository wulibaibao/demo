/**
 * 接口服务
 *
 * @author Wenming Tang <wenming@cshome.com.com>
 */

var Http = require('./http');
var Api = require('./api');
import User from "./user";

var baseUrl = window.$apiUrl;

module.exports = {
    /**
     * 获取广告列表
     *
     * @param failureHandler
     * @param completion
     */
    getAdvertisements: function (failureHandler, completion) {
        let resource = Http.Resource.jsonResource('/advertisements', Http.Method.GET);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },

    getAdvertisementsByCategory: function (categoryId, failureHandler, completion) {
        let resource = Http.Resource.jsonResource('/advertisements/c/' + categoryId, Http.Method.GET);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },

    /**
     * 获取商品列表
     *
     * @param failureHandler
     * @param completion
     */
    getGoodsList: function (page, failureHandler, completion) {
        let resource = Http.Resource.jsonResource('/goods?page=' + page, Http.Method.GET);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },

    /**
     * 获取商品列表by category
     *
     * @param failureHandler
     * @param completion
     */
    getGoodsListByCategoryId: function (categoryId, page, failureHandler, completion) {
        let resource = Http.Resource.jsonResource('/goods/category/' + categoryId + '?page=' + page, Http.Method.GET);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },

    /**
     * 获取商品列表by seller
     *
     * @param failureHandler
     * @param completion
     */
    getGoodsListBySellerId: function (sellerId, page, failureHandler, completion) {
        let resource = Http.Resource.jsonResource('/goods/seller/' + sellerId + '?page=' + page, Http.Method.GET);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },

    /**
     * 获取热门商品列表
     *
     * @param failureHandler
     * @param completion
     */
    getHotGoods: function (page, failureHandler, completion) {
        let resource = Http.Resource.jsonResource('/goods/commend/hot?page=' + page, Http.Method.GET);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },

    /**
     * 获取推荐商品列表
     *
     * @param failureHandler
     * @param completion
     */
    getRecommendGoods: function (page, failureHandler, completion) {
        let resource = Http.Resource.jsonResource('/goods/commend/recommend?page=' + page, Http.Method.GET);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },

    /**
     * 搜索
     *
     * @param query
     * @param page
     * @param failureHandler
     * @param completion
     */
    search: function (query, page, failureHandler, completion) {
        let resource = Http.Resource.jsonResource('/search?keyWord=' + query + '&page=' + page, Http.Method.GET);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },


    /**
     * 获取商品详情
     *
     * @param failureHandler
     * @param completion
     */
    getGoodsInfo: function (id, failureHandler, completion, params = '') {
        let resource = Http.Resource.jsonResource('/goods/' + id + '?' + params, Http.Method.GET);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },

    /**
     * 用户登录
     *
     * @param username
     * @param password
     * @param openId
     * @param failureHandler
     * @param completion
     */
    loginByUsername: function (username, password, openId, failureHandler, completion) {
        let requestParameters = {
            mobile: username,
            password: password,
            open_id: openId,
        };

        let resource = Http.Resource.jsonResource('/user/login', Http.Method.POST, requestParameters);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },

    /**
     * 用户注册
     *
     * @param username
     * @param password
     * @param mobileCode
     * @param openId
     * @param failureHandler
     * @param completion
     */
    registerUser: function (username, password, mobileCode, openId, failureHandler, completion) {
        let requestParameters = {
            mobile: username,
            password: password,
            mobile_code: mobileCode,
            // invite_code: inviteCode,
            open_id: openId,
        };

        let resource = Http.Resource.jsonResource('/user/signup', Http.Method.POST, requestParameters);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },
    
    /**
     * 用户注册
     *
     * @param username
     * @param password
     * @param mobileCode
     * @param openId
     * @param failureHandler
     * @param completion
     */
    registerUserForInvite: function (username, password, mobileCode, inviteCode, openId, failureHandler, completion) {
        let requestParameters = {
            mobile: username,
            password: password,
            mobile_code: mobileCode,
            // invite_code: inviteCode,
            open_id: openId,
        };

        let resource = Http.Resource.jsonResource('/user/signup?invite_code=' + inviteCode, Http.Method.POST, requestParameters);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },

    /**
     * 用户退出登录
     *
     * @param failureHandler
     * @param completion
     */
    logout: function (failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/user/logout', Http.Method.GET);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },

    /**
     * 修改密码
     *
     * @param oldPassword
     * @param newPassword
     * @param failureHandler
     * @param completion
     */
    changePassword: function (oldPassword, newPassword, failureHandler, completion) {
        let requestParameters = {
            oldPassword: oldPassword,
            newPassword: newPassword
        };

        let resource = Http.Resource.authJsonResource('/settings/password', Http.Method.POST, requestParameters);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },

    /**
     * 发送注册验证码
     *
     * @param mobile
     * @param failureHandler
     * @param completion
     */
    sendRegisterMobileCode: function (mobile, failureHandler, completion) {
        let resource = Http.Resource.jsonResource('/user/signup/mobileCode', Http.Method.POST, {
            mobile: mobile
        });

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },

    /**
     * 发送找回密码验证码
     *
     * @param mobile
     * @param failureHandler
     * @param completion
     */
    sendFindPasswordMobileCode: function (mobile, failureHandler, completion) {
        let resource = Http.Resource.jsonResource('/reset/password/mobileCode', Http.Method.POST, {
            mobile: mobile
        });

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },

    /**
     * 重置密码
     *
     * @param username
     * @param password
     * @param mobileCode
     * @param failureHandler
     * @param completion
     */
    resetPassword: function (username, password, mobileCode, failureHandler, completion) {
        let requestParameters = {
            mobile: username,
            password: password,
            mobile_code: mobileCode,
        };

        let resource = Http.Resource.jsonResource('/reset/password', Http.Method.POST, requestParameters);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },


    /**
     * 获取当前登录用户信息
     *
     * @param failureHandler
     * @param completion
     */
    userInfo: function (failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/user', Http.Method.GET);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },


    /**
     * 获取用户地址信息
     *
     * @param id
     * @param failureHandler
     * @param completion
     */
    getUserAddress: function (id, failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/user/address/' + id, Http.Method.GET);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },

    /**
     * 获取默认地址信息
     *
     * @param id
     * @param failureHandler
     * @param completion
     */
    getUserDefaultAddress: function (failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/user/address/default', Http.Method.GET);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },

    /**
     * 修改用户地址信息
     *
     * @param id
     * @param failureHandler
     * @param parameters
     * @param completion
     */
    editUserAddress: function (id, parameters, failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/user/address/' + id, Http.Method.PUT, parameters);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },

    /**
     * 获取用户地址列表
     *
     * @param failureHandler
     * @param completion
     */
    getUserAddressList: function (page, failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/user/address' + '?page=' + page, Http.Method.GET);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },

    /**
     * 保存地址
     *
     * @param parameters
     * @param failureHandler
     * @param completion
     */
    saveUserAddress(parameters, failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/user/address', Http.Method.POST, parameters);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },

    /**
     * 删除用户地址
     *
     * @param addressId
     * @param failureHandler
     * @param completion
     */
    deleteUserAddress(addressId, failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/user/address/' + addressId, Http.Method.DELETE);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },

    /**
     * 设置地址为默认地址
     *
     * @param addressId
     * @param failureHandler
     * @param completion
     */
    setUserAddressAsDefault(addressId, failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/user/address/' + addressId + '/default', Http.Method.PUT);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },


    /**
     * 获取地区,身份列表
     *
     * @param parentId
     * @param failureHandler
     * @param completion
     */
    getAreasList(parentId = 0, failureHandler, completion) {
        let resource = Http.Resource.jsonResource('/areas/' + parentId, Http.Method.GET);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },

    /**
     * 上传身份证
     *
     * @param data
     * @param failureHandler
     * @param completion
     */
    uploadId(data, failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/user/address/uploadId', Http.Method.POST, data);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },

    /**
     * 获取用户订单列表
     *
     * @param failureHandler
     * @param completion
     */
    getUserOrderList: function (page, failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/user/order' + '?page=' + page, Http.Method.GET);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },

    /**
     * 获取用户订单详情
     *
     * @param orderId
     * @param failureHandler
     * @param completion
     */
    getUserOrderInfo: function (orderId, failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/user/order_detail/' + orderId, Http.Method.GET);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },
    /**
     * 获取用户订单发货流向
     *
     * @param orderId
     * @param failureHandler
     * @param completion
     */
    getOrderStep: function (orderId, failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/user/order_step/' + orderId, Http.Method.GET);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },


    /**
     * 获取用户订单物流状态
     *
     * @param orderId
     * @param deliverCode
     * @param failureHandler
     * @param completion
     */
    getOrderDeliverStatus: function (orderId, deliverCode, failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/order/' + orderId + '/' + deliverCode, Http.Method.GET);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },


    /**
     * 删除已取消的订单
     * @param orderId
     * @param failureHandler
     * @param completion
     */
    deleteOrder: function (orderId, failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/user/order/' + orderId, Http.Method.DELETE);
        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },

    /**
     * 收藏商品
     *
     * @param goodsId
     * @param failureHandler
     * @param completion
     */
    favGoods: function (goodsId, failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/goods/' + goodsId + '/favorite', Http.Method.POST);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },

    /**
     * 取消收藏商品
     *
     * @param goodsId
     * @param failureHandler
     * @param completion
     */
    unFavGoods: function (goodsId, failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/goods/' + goodsId + '/favorite', Http.Method.DELETE);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },

    /**
     * 获取收藏状态
     *
     * @param goodsId
     * @param failureHandler
     * @param completion
     */
    getFavStatus: function (goodsId, failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/goods/' + goodsId + '/favorite', Http.Method.GET);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },

    /**
     * 获取收藏的商品列表
     *
     * @param failureHandler
     * @param completion
     */
    getFavorites: function (page, failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/user/favorites' + '?page=' + page, Http.Method.GET);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },

    /**
     * 获取所有配送方式
     *
     * @param failureHandler
     * @param completion
     */
    getDeliveries: function (failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/deliveries', Http.Method.GET);
        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },

    /**
     * 获取订单商品所有可用配送方式交集
     *
     * @param data
     * @param failureHandler
     * @param completion
     */
    getAvailableDeliveries: function (data, failureHandler, completion) {
        let resource = Http.Resource.jsonResource('/deliveries/byGoodsIds', Http.Method.POST, {
            ids: data.goodsIds,
            order_price: data.orderPrice
        });
        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },

    /**
     * 提交订单
     *
     * @param data
     * @param failureHandler
     * @param completion
     */
    postOrder: function (data, failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/user/order', Http.Method.POST, data);
        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },
    /**
     * 修改订单
     *
     * @param data
     * @param failureHandler
     * @param completion
     */
    cancelOrder: function (order_id, failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/user/order/cancel/' + order_id, Http.Method.PUT);
        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },
    /**
     * 确认订单
     *
     * @param data
     * @param failureHandler
     * @param completion
     */
    confirmOrder: function (order_id, failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/user/order/confirm/' + order_id, Http.Method.PUT);
        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },
    /**
     * 购物车列表
     * @param failureHandler
     * @param completion
     */
    getUserCartList: function (failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/cart', Http.Method.GET);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },
    /**
     * 购物车选中
     *
     * @param parameters
     * @param failureHandler
     * @param completion
     */
    selectCart(parameters, failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/cart/', Http.Method.PUT, parameters);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },
    /**
     * 购物车选中
     *
     * @param parameters
     * @param failureHandler
     * @param completion
     */
    addCart(parameters, failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/cart/', Http.Method.POST, parameters);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },
    /**
     * 购物车商家选中
     *
     * @param parameters
     * @param failureHandler
     * @param completion
     */
    selectSeller(parameters, failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/cart/seller_select', Http.Method.PUT, parameters);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },
    /**
     * 购物车选中
     *
     * @param parameters
     * @param failureHandler
     * @param completion
     */
    getSeller(failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/seller/', Http.Method.GET);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },
    /**
     * 购物车删除
     *
     * @param sku
     * @param failureHandler
     * @param completion
     */
    destroyCart(sku, failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/cart/destroy/' + sku, Http.Method.DELETE);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },
    /**
     * 申请退款
     *
     * @param parameters
     * @param failureHandler
     * @param completion
     */
    appleRefund(parameters, failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/user/refund/', Http.Method.POST, parameters);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },
    /**
     * 退款列表
     *
     * @param page
     * @param failureHandler
     * @param completion
     */
    refundList(page, failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/user/refund/?page=' + page, Http.Method.GET);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },    
    /**
     * 取消申请
     *
     * @param refund_id
     * @param failureHandler
     * @param completion
     */
    cancelRefund: function (refund_id, failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/user/refund/cancel/' + refund_id, Http.Method.PUT);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },
    /**
     * 查看退款
     *
     * @param refund_id
     * @param failureHandler
     * @param completion
     */
    refundDetail(refund_id, failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/user/refund/' + refund_id, Http.Method.GET);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },
    /**
     * 支付列表
     *
     * @param parameters
     * @param failureHandler
     * @param completion
     */
    getPayment(failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/payment/', Http.Method.GET);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },

    /**
     * 支付
     * @param orderId
     */
    goPay: function (orderId) {
        window.location.href = baseUrl + "/pay/" + orderId + '?access_token=' + User.getAuthToken()
    },

    /**
     * 支付补运费等
     * @param orderId
     */
    goExtraPay: function (orderId) {
        window.location.href = baseUrl + "/pay/extra/" + orderId + '?access_token=' + User.getAuthToken()
    },

    /**
     * 获取附加订单详情
     * @param orderId
     * @param failureHandler
     * @param completion
     */
    getExtraOrderInfo: function (orderId, failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/user/order/extra/' + orderId, Http.Method.GET);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },

    /**
     * 获取活动专题详情
     *
     * @param failureHandler
     * @param completion
     */
    getActivityInfo: function (activityId, failureHandler, completion) {
        let resource = Http.Resource.jsonResource('/activities/' + activityId, Http.Method.GET);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },
    /**
     * 用户抽奖
     */
    getlotteryInfo: function (failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/lottery', Http.Method.GET);
        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },
    /**
     * 获取最近中奖的10个用户
     * @param completion
     */
    getwinnerlatestInfo: function (failureHandler, completion) {
        let resource = Http.Resource.jsonResource('/lottery/winner_latest', Http.Method.GET);
        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },
    /**
     * 添加实物中奖者信息
     * @param completion
     */
    addwinnerInfo: function (data, failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/lottery/add_winner_info', Http.Method.POST, data);
        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },
    /**
     * 获取用户的运费劵
     * type 类型
     * page  当前分页
     */
    getcouponsList: function (type, page, pagesize, failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/user/coupons?type=' + type + "&page=" + page + "&pagesize=" + pagesize, Http.Method.GET);
        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },
    /**
     *  订单可用优惠券列表
     * type 类型
     * page  当前分页
     */
    getOrderCouponsList: function (delivery, failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/user/orderCoupons?delivery=' + delivery, Http.Method.GET);
        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },
    /**
     *  订单可用优惠券列表
     * type 类型
     * page  当前分页
     */
    getUseableCoupon: function (cardname, delivery, failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/user/coupon/useable?delivery=' + delivery + "&cardname=" + cardname, Http.Method.GET);
        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },

    /**
     * 获取WeChat Js 配置信息
     *
     * @param failureHandler
     * @param completion
     */
    getWechatJsConfig: function (url, failureHandler, completion) {
        let resource = Http.Resource.jsonResource('/wechat/config?url=' + url, Http.Method.GET);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },
    /**
     * 获取黑5最新抽奖的10个用户
     */
    getRecentlyTenWinner: function (failureHandler, completion) {
        let resource = Http.Resource.jsonResource('/lotteries/1/latest', Http.Method.GET);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },
    /**
     * 获取用户抽奖的次数(黑5)
     * @param failureHandler
     * @param completion
     */
    getUserLotterChanceNum: function (failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/lotteries/1/chance', Http.Method.GET);
        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },
    /**
     * 用户抽奖(黑5)
     */
    getlotteryAct: function (failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/lotteries/1', Http.Method.POST);
        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },
    /**
     * 分享朋友圈
     */
    addchanceByShare: function (failureHandler, completion) {
        let resource = Http.Resource.authJsonResource('/lotteries/1/chance', Http.Method.POST);
        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },
    /**
     * 用户手机号绑定
     *
     * @param mobile
     * @param mobileCode
     * @param failureHandler
     * @param completion
     */
    bindMobile: function (mobile, mobileCode, failureHandler, completion) {
        let requestParameters = {
            mobile: mobile,
            mobile_code: mobileCode,
        };

        let resource = Http.Resource.authJsonResource('/user/mobile/bind', Http.Method.POST, requestParameters);

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    },
    /**
     * 发送绑定手机号验证码
     *
     * @param mobile
     * @param failureHandler
     * @param completion
     */
    sendBindMobileCode: function (mobile, failureHandler, completion) {
        let resource = Http.Resource.jsonResource('/user/bindMobile/mobileCode', Http.Method.POST, {
            mobile: mobile
        });

        Api.apiRequest(baseUrl, resource, failureHandler, completion);
    }
};