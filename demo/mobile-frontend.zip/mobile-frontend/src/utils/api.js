/**
 * API
 *
 * @author Wenming Tang <wenming@cshome.com.com>
 */

var Vue = require('vue');
import User from "./user";
import {Indicator} from "mint-ui";

var VueResource = require('vue-resource');
Vue.use(VueResource);

module.exports = {
    apiRequest: function (baseUrl, resource, failure, completion) {
        if (!baseUrl || !resource) {
            return;
        }
        let url;

        if (resource.path.indexOf('?') > 0)
            url = baseUrl + resource.path + '&t=' + Date.now();
        else
            url = baseUrl + resource.path + '?t=' + Date.now();

        Vue
            .http({
                url: url,
                data: resource.requestBody,
                method: resource.method,
                headers: resource.headers,
                beforeSend: function (request) {
                    Indicator.open({
                        spinnerType: 'snake'
                    });
                }
            })
            .then(function (response) {
                Indicator.close();

                completion(response);
            }, function (response) {
                Indicator.close();

                if (response.status == 401) {
                    User.logout(); // 可能是本地存储的 token 无效,删除掉
                    User.goLogin();

                } else if (response.status == 404) {
                    window.$router.go({name: 'not_found'})
                } else {
                    failure(response)
                }
            });
    }
};