var config = require('ROOT/config.js');
var api_prefix = "http://api.laidoulaile.com/";

module.exports = {
    // single_post_is_sending:false,
    errSysHandler:function(e){
        if (e.status==0) {
            net.showErr("没有网络!");
            return;
        }

        net.showErr(e.status+" 网络错误!");
    },
    errHandler:function(code){

        switch(code){
            case 'NoLoginException':
                // net.showErr("没有登录");
                console.log("没有登录");
                // window.$router.go('/estp/login');
                break;
            case 'ACCESS_DENIED':
                // net.showErr("没有访问权限!");
                console.log("没有访问权限!");
                break;
            case 'INVALID_PARAMS':
                // net.showErr("参数错误!");
                console.log("参数错误!");
                break;
            default:
                net.showErr("未知网络错误!");
                console.log("未知网络错误!");
                break;
        }
    },
    baseAjax:function(url,data,option){
        var defaultOption = {
            type:"GET",
            url:api_prefix+url,
            beforeSend: function(XMLHttpRequest) {
                XMLHttpRequest.setRequestHeader("apiRequestFrom","web");
            },

            data:data
            // error:function(XMLHttpRequest, textStatus, errorThrown){
            //     net.single_post_is_sending=false;
            // },
            // beforeSend:function (XMLHttpRequest) {
            //   net.single_post_is_sending=true;
            // },
        }

        var rOpt = $.extend(defaultOption,option)

        // var df = $.ajax(rOpt);
        var rDf = $.Deferred();

        $.ajax(rOpt).done(function(rsp){
            if (typeof rsp == "string") {
                return rDf.reject("服务器出错了.");
            }
            if (rsp.status.code!='ok') {
                net.errHandler(rsp.status.code);

                rDf.reject(rsp.status);
                return rDf;
            }

            rDf.resolve(rsp.result);
            // rDf.done(function(){alert('resolve')})
        })
        .fail(function(x){
            // console.log('fail......in net')
            // console.log(x)
            //不是200的返回
            rDf.reject(x.status);
            net.errSysHandler(x);
        })

        return rDf;
    },

    get:function(url,data){
        return net.baseAjax(url,data,{});
    },
    post:function(url,data){
        return net.baseAjax(url,data,{type:"POST"});
    },
    errPosition:function(){
        var e = $('.error');
        var offset = $('.header-con').height();
        var scrollTop = $(document).scrollTop();

        if (scrollTop>offset) {
            e.css('top',scrollTop);
        }else{
            e.css('top',offset);
        }
    },
    showErr:function(message){
        var str = net.getErr(message);
        var jqErr = $('.error');


        jqErr.find('.msg-content').text(str);
        net.errPosition();
        jqErr.removeClass('hide');

        var t = setInterval(function(){
            net.errPosition();
        },10)

        setTimeout(function(){
            jqErr.addClass('hide');
            clearInterval(t);
        },2500);

    },
    getErr:function(message){
        var str="";
        if($.isPlainObject(message)){
          for (var i in message){
            if (i == 'code') {
                continue;
            }
            if ($.isPlainObject(message[i])) {
                str += net.getErr(message[i])+" ";
                continue;
            }
            str+=message[i]+" ";
          }
        }
        else
        {
          str = message;
        }
        return str;
    }

};