/**
 * HTTP
 *
 * @author Wenming Tang <wenming@cshome.com.com>
 */

import User from "./user";

class Resource {
    constructor(path, method, requestBody, headers) {
        this.path = path;
        this.method = method;
        this.requestBody = requestBody;
        this.headers = headers;
    }

    description() {
        return 'Resource(path:(' + this.path + '), method:(' + this.method + '), requestBody:(' + this.requestBody + '), headers:(' + this.headers + '))';
    }
}

exports.Method = {
    POST: 'POST',
    GET: 'GET',
    PUT: 'PUT',
    DELETE: 'DELETE',
};

exports.Resource = {
    jsonResource: function (path, method, requestParameters) {
        return this.resource(null, path, method, requestParameters);
    },

    authJsonResource: function (path, method, requestParameters) {
        var token = User.getAuthToken();

        if (!token) {
            User.goLogin();
            return;
        }

        return this.resource(token, path, method, requestParameters);
    },

    resource: function (token, path, method, requestParameters) {
        var headers = {};

        if (token) {
            headers['Authorization'] = "Bearer " + token;
        }

        if (window.getCookie('cps_source') !== undefined)
            headers['EbuyCpsCookie'] = window.getCookie('cps_source');

        return new Resource(path, method, requestParameters, headers);
    }
};