export default {
    login(user) {

        if (typeof user != 'object') {
            return
        }

        localStorage.setItem('access_token', user.access_token);
    },

    goLogin() {
        console.log('goLogin');

        let ua = window.navigator.userAgent.toLowerCase();

        if (ua.match(/MicroMessenger/i) == 'micromessenger') {
            window.location.href = window.$apiUrl + '/user/login/wechat?return=' + window.location.pathname
        } else {
            // window.location.href = '/login?return=' + window.location.pathname;
            window.$router.replace({name: 'login', query: {'return': window.location.pathname}});
        }
    },

    logout() {
        localStorage.removeItem('access_token');
    },

    isLogged() {
        var accessToken = localStorage.getItem('access_token');

        return accessToken ? true : false;
    },

    checkAuth() {
        if (!this.isLogged()) {
            this.goLogin();
        }
    },

    getAuthToken() {
        return localStorage.getItem('access_token');
    },

    getAuthHeader() {
        return {
            'Authorization': 'Bearer ' + this.getAuthToken()
        }
    }
}