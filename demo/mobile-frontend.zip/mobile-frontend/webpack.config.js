var path = require('path');
var webpack = require('webpack');
var HtmlWebpackPlugin = require('html-webpack-plugin');
var ExtractTextPlugin = require("extract-text-webpack-plugin");
var autoprefixer = require('autoprefixer');
var isProduction = function () {
    return process.env.NODE_ENV === 'production';
};

var config = {
    autoprefixers: [
        'Android 2.3',
        'Android >= 4',
        'iOS >= 7'
    ],
};

var webpackConfigs = {
    entry: {
        app: ['./src/main.js'],
        lib: ['vue', 'vue-router', 'webpack-zepto','jquery']
    },
    output: {
        path: path.join(__dirname, "dist"),
        filename: "[name].min.js",
        chunkFilename: "[name].min.js?[hash]-[chunkhash]",
        publicPath: isProduction() ? "/" : "/dist/",
        // filename: 'index.js'
    },
    module: {
        loaders: [
            {
                test: /\.vue$/,
                loader: 'vue',
            },
            {
                test: /\.css$/,
                // loader: 'style!css'
                loader: isProduction()? ExtractTextPlugin.extract("style-loader", "css-loader") : 'style!css'
            },
            {
                test: /\.less$/,
                // loader: 'style!css!less'
                loader: isProduction() ? ExtractTextPlugin.extract("style-loader!css-loader!less-loader!") : 'style!css!less!'
            },
            {
                //图片文件使用 url-loader 来处理，小于8kb的直接转为base64
                test: /\.(png|jpg|jpeg|svg|gif)$/,
                loader: 'url-loader?limit=8000&name=[path][name].[ext]',
            },
            {
                //字体
                test: /\.(eot|svg|ttf|woff)\??.*$/,
                loader: 'file-loader?name=[path][name].[ext]',
            },
            {
                // use babel-loader for *.js files
                test: /\.js$/,
                loader: 'babel-loader',
                // important: exclude files in node_modules
                // otherwise it's going to be really slow!
                exclude: /node_modules/,
            },
        ]
    },
    // vue: {
    //     loaders: {
    //         css: ExtractTextPlugin.extract('vue-style-loader','css'),
    //         less: ExtractTextPlugin.extract('vue-style-loader', 'css!less')
    //     }
    // },
    babel: {
        presets: ['es2015'],
        plugins: ['transform-runtime']
    },
    // 服务器配置相关，自动刷新!
    devServer: {
        port: 8091,
        historyApiFallback: true,
        hot: false,
        inline: true,
        grogress: true
        // proxy: proxy
    },
    resolve: {
        // require时省略的扩展名，如：require('module') 不需要module.js
        extensions: ['', '.js', '.vue'],
        // 别名，可以直接使用别名来代表设定的路径以及其他
        alias: {
            filter: path.join(__dirname, './src/filters'),
            components: path.join(__dirname, './src/components'),
            utils: path.join(__dirname, './src/utils'),
            static_file: path.join(__dirname, './static'),
            ROOT: path.join(__dirname, ""),
            source: path.join(__dirname, "./src/source"),
            // vuex: path.join(__dirname, './src/vuex'),
        }
    },
    plugins: [

        new ExtractTextPlugin("css/[name].css?[hash]-[chunkhash]-[contenthash]-[name]", {
            disable: false,
            allChunks: true
        }),
        // new webpack.optimize.DedupePlugin(),
        new webpack.optimize.CommonsChunkPlugin({
            name: 'lib',
            chunks: ['app', 'lib'],
            minChunks: Infinity
        }),
        new webpack.ProvidePlugin({
            $: 'webpack-zepto',
            zepto: 'webpack-zepto',
            jQuery: 'jquery',
            "window.jQuery": "jquery"
        }),
        new webpack.DefinePlugin({
            'process.env': {
                'NODE_ENV': JSON.stringify(process.env.NODE_ENV)
            }
        })
    ]
};

if (isProduction()) {
    webpackConfigs.plugins.push(new HtmlWebpackPlugin({
        //根据模板插入css/js等生成最终HTML
        filename: 'index.html',    //生成的html存放路径，相对于 path
        template: path.join(__dirname, './build.html'),//html模板路径
        inject: true,    //允许插件修改哪些内容，包括head与body
        hash: true,    //为静态资源生成hash值
        minify: {    //压缩HTML文件
            removeComments: true,    //移除HTML中的注释
            collapseWhitespace: false    //删除空白符与换行符
        }
    }));

    webpackConfigs.plugins.push(new webpack.optimize.UglifyJsPlugin({
        compress: {
            warnings: !isProduction()
        }
    }));
}
else {
    webpackConfigs.devtool = 'source-map';
    webpackConfigs.debug = true;
}

module.exports = webpackConfigs;
