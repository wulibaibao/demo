ichartjs Library, workspace for version 1.2.1 development
===========================================================================
Licensed under the Apache License, Version 2.0 (the "License");
--------------------------------------------------
http://www.ichartjs.com
--------------------------------------------------
The branch master is develop branch.
The latest release version for use is : https://github.com/wanghetommy/ichartjs/tree/ichartjs1.2
--------------------------------------------------
Directory INFO 
<table>
<thead><tr>
  <th>directory</th><th>description</th>
</tr></thead>
<tbody>
  <tr>
    <th>dist</th>
    <td>
      contains the packed js files
    </td>
  </tr>
  <tr>
    <th>docs</th>
    <td>
      contains the ichartjs API docs
    </td>
  </tr>
  <tr>
    <th>minify</th>
    <td>
      contains the minify js files
    </td>
  </tr>
  <tr>
    <th>samples</th>
    <td>
     contains various demo
    </td>
  </tr>
  <tr>
    <th>src</th>
    <td>
     contains the general javascript source files for the ichartjs
    </td>
  </tr>
  <tr>
    <th>test</th>
    <td>
     contains the general javascript source files for test
    </td>
  </tr>
</tbody>
</table>



