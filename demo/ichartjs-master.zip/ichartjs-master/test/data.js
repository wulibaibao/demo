var data = [
        	{name : '广州',value : 4000,color:'#a56f8f'},
        	{name : '上海',value : 4200,color:'#0d6868'},
        	{name : '南昌',value : 3500,color:'#744774'},
        	{name : '哈尔滨',value : 3600,color:'#267daa'},
        	{name : '北京',value : 4150,color:'#67840e'}
    	];

var data2 = [
         	{
         		name : 'DPS01A',
         		value:[45,52,54,74,90,84],
         		color:'#1f7e92',
         		linewidth:1
         	},
         	{
         		name : 'DPS01B',
         		value:[60,80,105,125,108,120],
         		color:'#2b7f39',
         		linewidth:1
         	}
         ];

var data3 = [
         	{
     		name : '北京',
     		value:[8,12,14,20,26,28,30,26,28,20,16,10],
     		color:'#1f7e92'
     	}
     ];
var data4 = [
          	{
      		name : '北京',
      		value:[8,12,14,20,26,28,30,26,28,20,16,10],
      		color:'#1f7e92'
      	},
      	{
      		name : '上海',
      		value:[9,13,18,24,27,32,33,29,28,22,17,11],
      		color:'#1f7e92'
      	}
      ];	

var lineLabels =  ["一月","二月","三月","四月","五月","六月","七月","八月","九月","十月","十一月","十二月"];

var labels = ["一月","二月","三月","四月","五月","六月"];